<?php
class registerctr extends CI_Controller {








	public function register()
	{

		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			
			$postDatas = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password')
			);
             
		 	$isInserted = $this->db->insert('users ', $postDatas);
			if($isInserted !=false){
				echo 'Record added successfully.';
			}else{
				echo 'Error!!! Try again.';
			}
			redirect('login');

		}else{
			$this->load->view('register');
		}
	}

	public function login()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$email = $this->input->post('email');  
			$password = $this->input->post('password');  
				
			$this->db->select('users.*');
			$this->db->from('users');
			$this->db->where('email', $email);
			$this->db->where('password', $password);
			$user = $this->db->get()->row();

			if(!empty($user)){
				// $this->session->set_userdata($user);   //set into session
					// echo "Logged In successfully.";
					// $this->load->view('/home');  
					redirect('http://localhost/code/home');
			}else{
				echo "login user not found";
				$this->load->view('login');  
			}
		
				// $this->load->view('login');
		}
		else{
			$this->load->view('login');  
		}
	}


 }

 
   