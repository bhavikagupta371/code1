
    <section class="banner top" id="home" style="background-image:url(https://media.istockphoto.com/id/1244666940/photo/business-network-concept-human-resources-group-of-businesspeople-success-of-business.jpg?s=612x612&w=0&k=20&c=8RTPjo7dG-qjnfOb2qP8xsNM6APfE5RimxyaNXOwUL0=); background-repeat: no-repeat; height: 700px">
        <div class="texture">
        <div class="container">
           <div class="col-5 mb-12 mb-center banner-box">
               
               <div class="banner_line1">The great aim of education is not knowledge but action.</div>
               <div class="banner_brief_text">Education not only broadens the mind but adds the most important component for critical thought, depth.</div>
               <div    class="mb-center mb-12">
               <div class="button-1">
                   <a href="#">Login</a></div></div>          
           </div>
            <div class="col-7 mb-12 banner-image"  style="position:relative;"><!--<img src="image/banner2_image.png"  />--></div>
        </div>
            </div>
       <!--  <div class="col-12 banner-extra-div color-black-s-light">
 
    </div>-->
    </section>

    </div>
    <script type="text/javascript">
        thumb_slider({

            thumbs_to_show: 1,
            thumbs_to_move: 1,
            thumbs_width: 0,
            thumbs_count: 0,
            timeout: 10000,
            parent_id: "main_slider",
            container_class: "thumb_slider",
            thumb_class: "thumbs",
            spacing: 0,
            processing: false,
            hover: false,
            next_class: "next",
            prev_class: "prev",
            timer: setTimeout(function () { })

        });
    </script>
</body>
</html>