<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-11 07:11:49 --> Config Class Initialized
INFO - 2023-07-11 07:11:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:49 --> URI Class Initialized
INFO - 2023-07-11 07:11:49 --> Router Class Initialized
INFO - 2023-07-11 07:11:50 --> Output Class Initialized
INFO - 2023-07-11 07:11:50 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:50 --> Input Class Initialized
INFO - 2023-07-11 07:11:50 --> Language Class Initialized
INFO - 2023-07-11 07:11:50 --> Loader Class Initialized
INFO - 2023-07-11 07:11:51 --> Helper loaded: url_helper
INFO - 2023-07-11 07:11:51 --> Database Driver Class Initialized
INFO - 2023-07-11 07:11:52 --> Controller Class Initialized
INFO - 2023-07-11 07:11:52 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:11:52 --> Config Class Initialized
INFO - 2023-07-11 07:11:52 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:52 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
DEBUG - 2023-07-11 07:11:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:52 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:52 --> URI Class Initialized
INFO - 2023-07-11 07:11:52 --> Router Class Initialized
INFO - 2023-07-11 07:11:52 --> Output Class Initialized
INFO - 2023-07-11 07:11:52 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:52 --> Input Class Initialized
INFO - 2023-07-11 07:11:52 --> Language Class Initialized
INFO - 2023-07-11 07:11:52 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:11:52 --> Loader Class Initialized
INFO - 2023-07-11 07:11:52 --> Final output sent to browser
INFO - 2023-07-11 07:11:52 --> Helper loaded: url_helper
DEBUG - 2023-07-11 07:11:52 --> Total execution time: 3.7176
INFO - 2023-07-11 07:11:52 --> Database Driver Class Initialized
INFO - 2023-07-11 07:11:52 --> Controller Class Initialized
INFO - 2023-07-11 07:11:53 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:11:53 --> File loaded: C:\xampp\htdocs\code\application\views\/Student/listing.php
INFO - 2023-07-11 07:11:53 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:11:53 --> Final output sent to browser
DEBUG - 2023-07-11 07:11:53 --> Total execution time: 1.3469
INFO - 2023-07-11 07:11:54 --> Config Class Initialized
INFO - 2023-07-11 07:11:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:54 --> URI Class Initialized
INFO - 2023-07-11 07:11:54 --> Router Class Initialized
INFO - 2023-07-11 07:11:54 --> Output Class Initialized
INFO - 2023-07-11 07:11:54 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:54 --> Input Class Initialized
INFO - 2023-07-11 07:11:54 --> Language Class Initialized
ERROR - 2023-07-11 07:11:54 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:11:54 --> Config Class Initialized
INFO - 2023-07-11 07:11:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:54 --> URI Class Initialized
INFO - 2023-07-11 07:11:54 --> Router Class Initialized
INFO - 2023-07-11 07:11:54 --> Output Class Initialized
INFO - 2023-07-11 07:11:54 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:54 --> Input Class Initialized
INFO - 2023-07-11 07:11:54 --> Language Class Initialized
ERROR - 2023-07-11 07:11:54 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:11:54 --> Config Class Initialized
INFO - 2023-07-11 07:11:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:54 --> URI Class Initialized
INFO - 2023-07-11 07:11:54 --> Router Class Initialized
INFO - 2023-07-11 07:11:54 --> Output Class Initialized
INFO - 2023-07-11 07:11:54 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:54 --> Input Class Initialized
INFO - 2023-07-11 07:11:54 --> Language Class Initialized
ERROR - 2023-07-11 07:11:54 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:54 --> Config Class Initialized
INFO - 2023-07-11 07:11:54 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:54 --> Config Class Initialized
DEBUG - 2023-07-11 07:11:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:54 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:54 --> URI Class Initialized
DEBUG - 2023-07-11 07:11:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:54 --> Router Class Initialized
INFO - 2023-07-11 07:11:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:54 --> Config Class Initialized
INFO - 2023-07-11 07:11:54 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:54 --> URI Class Initialized
INFO - 2023-07-11 07:11:54 --> Output Class Initialized
INFO - 2023-07-11 07:11:54 --> Router Class Initialized
DEBUG - 2023-07-11 07:11:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:54 --> Security Class Initialized
INFO - 2023-07-11 07:11:54 --> URI Class Initialized
INFO - 2023-07-11 07:11:54 --> Output Class Initialized
INFO - 2023-07-11 07:11:54 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:54 --> Router Class Initialized
INFO - 2023-07-11 07:11:54 --> Input Class Initialized
DEBUG - 2023-07-11 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:54 --> Output Class Initialized
INFO - 2023-07-11 07:11:54 --> Input Class Initialized
INFO - 2023-07-11 07:11:54 --> Language Class Initialized
INFO - 2023-07-11 07:11:54 --> Language Class Initialized
INFO - 2023-07-11 07:11:54 --> Security Class Initialized
ERROR - 2023-07-11 07:11:54 --> 404 Page Not Found: Student/assest
ERROR - 2023-07-11 07:11:54 --> 404 Page Not Found: Student/assest
DEBUG - 2023-07-11 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:54 --> Input Class Initialized
INFO - 2023-07-11 07:11:54 --> Language Class Initialized
ERROR - 2023-07-11 07:11:54 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:55 --> Config Class Initialized
INFO - 2023-07-11 07:11:55 --> Config Class Initialized
INFO - 2023-07-11 07:11:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:55 --> Config Class Initialized
DEBUG - 2023-07-11 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:11:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:55 --> URI Class Initialized
INFO - 2023-07-11 07:11:55 --> URI Class Initialized
INFO - 2023-07-11 07:11:55 --> Router Class Initialized
INFO - 2023-07-11 07:11:55 --> Router Class Initialized
DEBUG - 2023-07-11 07:11:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:55 --> Output Class Initialized
INFO - 2023-07-11 07:11:55 --> Output Class Initialized
INFO - 2023-07-11 07:11:55 --> URI Class Initialized
INFO - 2023-07-11 07:11:55 --> Security Class Initialized
INFO - 2023-07-11 07:11:55 --> Security Class Initialized
INFO - 2023-07-11 07:11:55 --> Router Class Initialized
DEBUG - 2023-07-11 07:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:55 --> Input Class Initialized
INFO - 2023-07-11 07:11:55 --> Input Class Initialized
INFO - 2023-07-11 07:11:55 --> Output Class Initialized
INFO - 2023-07-11 07:11:55 --> Language Class Initialized
INFO - 2023-07-11 07:11:55 --> Language Class Initialized
INFO - 2023-07-11 07:11:55 --> Security Class Initialized
ERROR - 2023-07-11 07:11:55 --> 404 Page Not Found: Student/assest
ERROR - 2023-07-11 07:11:55 --> 404 Page Not Found: Student/assest
DEBUG - 2023-07-11 07:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:55 --> Input Class Initialized
INFO - 2023-07-11 07:11:55 --> Language Class Initialized
ERROR - 2023-07-11 07:11:55 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:56 --> Config Class Initialized
INFO - 2023-07-11 07:11:56 --> Config Class Initialized
INFO - 2023-07-11 07:11:56 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:56 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:11:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:56 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:56 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:56 --> URI Class Initialized
INFO - 2023-07-11 07:11:56 --> URI Class Initialized
INFO - 2023-07-11 07:11:56 --> Router Class Initialized
INFO - 2023-07-11 07:11:56 --> Router Class Initialized
INFO - 2023-07-11 07:11:56 --> Output Class Initialized
INFO - 2023-07-11 07:11:56 --> Output Class Initialized
INFO - 2023-07-11 07:11:56 --> Security Class Initialized
INFO - 2023-07-11 07:11:56 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:56 --> Input Class Initialized
INFO - 2023-07-11 07:11:56 --> Input Class Initialized
INFO - 2023-07-11 07:11:56 --> Language Class Initialized
INFO - 2023-07-11 07:11:56 --> Language Class Initialized
ERROR - 2023-07-11 07:11:56 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 07:11:56 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:56 --> Config Class Initialized
INFO - 2023-07-11 07:11:56 --> Config Class Initialized
INFO - 2023-07-11 07:11:56 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:56 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:11:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:56 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:56 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:56 --> URI Class Initialized
INFO - 2023-07-11 07:11:56 --> URI Class Initialized
INFO - 2023-07-11 07:11:56 --> Router Class Initialized
INFO - 2023-07-11 07:11:56 --> Router Class Initialized
INFO - 2023-07-11 07:11:56 --> Output Class Initialized
INFO - 2023-07-11 07:11:56 --> Output Class Initialized
INFO - 2023-07-11 07:11:56 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:56 --> Security Class Initialized
INFO - 2023-07-11 07:11:56 --> Input Class Initialized
INFO - 2023-07-11 07:11:56 --> Language Class Initialized
DEBUG - 2023-07-11 07:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:56 --> Input Class Initialized
ERROR - 2023-07-11 07:11:56 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:56 --> Language Class Initialized
ERROR - 2023-07-11 07:11:56 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:57 --> Config Class Initialized
INFO - 2023-07-11 07:11:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:57 --> Config Class Initialized
INFO - 2023-07-11 07:11:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:57 --> Config Class Initialized
INFO - 2023-07-11 07:11:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:11:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:57 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:11:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:57 --> URI Class Initialized
INFO - 2023-07-11 07:11:57 --> URI Class Initialized
INFO - 2023-07-11 07:11:57 --> URI Class Initialized
INFO - 2023-07-11 07:11:57 --> Router Class Initialized
INFO - 2023-07-11 07:11:57 --> Router Class Initialized
INFO - 2023-07-11 07:11:57 --> Router Class Initialized
INFO - 2023-07-11 07:11:57 --> Output Class Initialized
INFO - 2023-07-11 07:11:57 --> Output Class Initialized
INFO - 2023-07-11 07:11:57 --> Output Class Initialized
INFO - 2023-07-11 07:11:57 --> Security Class Initialized
INFO - 2023-07-11 07:11:57 --> Security Class Initialized
INFO - 2023-07-11 07:11:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:57 --> Input Class Initialized
INFO - 2023-07-11 07:11:57 --> Input Class Initialized
DEBUG - 2023-07-11 07:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:57 --> Input Class Initialized
INFO - 2023-07-11 07:11:57 --> Language Class Initialized
INFO - 2023-07-11 07:11:57 --> Language Class Initialized
INFO - 2023-07-11 07:11:57 --> Language Class Initialized
ERROR - 2023-07-11 07:11:57 --> 404 Page Not Found: Student/assest
ERROR - 2023-07-11 07:11:57 --> 404 Page Not Found: Student/assest
ERROR - 2023-07-11 07:11:57 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:57 --> Config Class Initialized
INFO - 2023-07-11 07:11:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:57 --> URI Class Initialized
INFO - 2023-07-11 07:11:57 --> Router Class Initialized
INFO - 2023-07-11 07:11:57 --> Output Class Initialized
INFO - 2023-07-11 07:11:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:57 --> Input Class Initialized
INFO - 2023-07-11 07:11:57 --> Language Class Initialized
ERROR - 2023-07-11 07:11:57 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:11:58 --> Config Class Initialized
INFO - 2023-07-11 07:11:58 --> Hooks Class Initialized
INFO - 2023-07-11 07:11:58 --> Config Class Initialized
INFO - 2023-07-11 07:11:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:58 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:11:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:58 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:58 --> URI Class Initialized
INFO - 2023-07-11 07:11:58 --> URI Class Initialized
INFO - 2023-07-11 07:11:58 --> Router Class Initialized
INFO - 2023-07-11 07:11:58 --> Router Class Initialized
INFO - 2023-07-11 07:11:58 --> Output Class Initialized
INFO - 2023-07-11 07:11:58 --> Output Class Initialized
INFO - 2023-07-11 07:11:58 --> Security Class Initialized
INFO - 2023-07-11 07:11:58 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:58 --> Input Class Initialized
DEBUG - 2023-07-11 07:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:58 --> Input Class Initialized
INFO - 2023-07-11 07:11:58 --> Language Class Initialized
INFO - 2023-07-11 07:11:58 --> Language Class Initialized
ERROR - 2023-07-11 07:11:58 --> 404 Page Not Found: Student/assest
ERROR - 2023-07-11 07:11:58 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:58 --> Config Class Initialized
INFO - 2023-07-11 07:11:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:58 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:58 --> URI Class Initialized
INFO - 2023-07-11 07:11:58 --> Router Class Initialized
INFO - 2023-07-11 07:11:58 --> Output Class Initialized
INFO - 2023-07-11 07:11:58 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:58 --> Input Class Initialized
INFO - 2023-07-11 07:11:58 --> Language Class Initialized
ERROR - 2023-07-11 07:11:58 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:59 --> Config Class Initialized
INFO - 2023-07-11 07:11:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:59 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:59 --> URI Class Initialized
INFO - 2023-07-11 07:11:59 --> Router Class Initialized
INFO - 2023-07-11 07:11:59 --> Output Class Initialized
INFO - 2023-07-11 07:11:59 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:59 --> Input Class Initialized
INFO - 2023-07-11 07:11:59 --> Language Class Initialized
ERROR - 2023-07-11 07:11:59 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:59 --> Config Class Initialized
INFO - 2023-07-11 07:11:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:59 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:59 --> URI Class Initialized
INFO - 2023-07-11 07:11:59 --> Router Class Initialized
INFO - 2023-07-11 07:11:59 --> Output Class Initialized
INFO - 2023-07-11 07:11:59 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:59 --> Input Class Initialized
INFO - 2023-07-11 07:11:59 --> Language Class Initialized
ERROR - 2023-07-11 07:11:59 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:59 --> Config Class Initialized
INFO - 2023-07-11 07:11:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:59 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:59 --> URI Class Initialized
INFO - 2023-07-11 07:11:59 --> Router Class Initialized
INFO - 2023-07-11 07:11:59 --> Output Class Initialized
INFO - 2023-07-11 07:11:59 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:59 --> Input Class Initialized
INFO - 2023-07-11 07:11:59 --> Language Class Initialized
ERROR - 2023-07-11 07:11:59 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:11:59 --> Config Class Initialized
INFO - 2023-07-11 07:11:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:59 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:59 --> URI Class Initialized
INFO - 2023-07-11 07:11:59 --> Router Class Initialized
INFO - 2023-07-11 07:11:59 --> Output Class Initialized
INFO - 2023-07-11 07:11:59 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:59 --> Input Class Initialized
INFO - 2023-07-11 07:11:59 --> Language Class Initialized
ERROR - 2023-07-11 07:11:59 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:11:59 --> Config Class Initialized
INFO - 2023-07-11 07:11:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:11:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:11:59 --> Utf8 Class Initialized
INFO - 2023-07-11 07:11:59 --> URI Class Initialized
INFO - 2023-07-11 07:11:59 --> Router Class Initialized
INFO - 2023-07-11 07:11:59 --> Output Class Initialized
INFO - 2023-07-11 07:11:59 --> Security Class Initialized
DEBUG - 2023-07-11 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:11:59 --> Input Class Initialized
INFO - 2023-07-11 07:11:59 --> Language Class Initialized
ERROR - 2023-07-11 07:11:59 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:15:15 --> Config Class Initialized
INFO - 2023-07-11 07:15:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:15 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:15 --> URI Class Initialized
INFO - 2023-07-11 07:15:15 --> Router Class Initialized
INFO - 2023-07-11 07:15:15 --> Output Class Initialized
INFO - 2023-07-11 07:15:15 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:15 --> Input Class Initialized
INFO - 2023-07-11 07:15:15 --> Language Class Initialized
INFO - 2023-07-11 07:15:15 --> Loader Class Initialized
INFO - 2023-07-11 07:15:15 --> Helper loaded: url_helper
INFO - 2023-07-11 07:15:15 --> Database Driver Class Initialized
INFO - 2023-07-11 07:15:15 --> Controller Class Initialized
INFO - 2023-07-11 07:15:15 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:15:15 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 07:15:15 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:15:15 --> Final output sent to browser
DEBUG - 2023-07-11 07:15:15 --> Total execution time: 0.0882
INFO - 2023-07-11 07:15:15 --> Config Class Initialized
INFO - 2023-07-11 07:15:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:15 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:15 --> URI Class Initialized
INFO - 2023-07-11 07:15:15 --> Router Class Initialized
INFO - 2023-07-11 07:15:15 --> Output Class Initialized
INFO - 2023-07-11 07:15:15 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:15 --> Input Class Initialized
INFO - 2023-07-11 07:15:15 --> Language Class Initialized
ERROR - 2023-07-11 07:15:15 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:15 --> Config Class Initialized
INFO - 2023-07-11 07:15:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:15 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:15 --> URI Class Initialized
INFO - 2023-07-11 07:15:15 --> Router Class Initialized
INFO - 2023-07-11 07:15:15 --> Output Class Initialized
INFO - 2023-07-11 07:15:15 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:15 --> Input Class Initialized
INFO - 2023-07-11 07:15:15 --> Language Class Initialized
ERROR - 2023-07-11 07:15:15 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:15 --> Config Class Initialized
INFO - 2023-07-11 07:15:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:15 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:15 --> URI Class Initialized
INFO - 2023-07-11 07:15:15 --> Router Class Initialized
INFO - 2023-07-11 07:15:15 --> Output Class Initialized
INFO - 2023-07-11 07:15:15 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:15 --> Input Class Initialized
INFO - 2023-07-11 07:15:15 --> Language Class Initialized
ERROR - 2023-07-11 07:15:15 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:15:17 --> Config Class Initialized
INFO - 2023-07-11 07:15:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:17 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:17 --> URI Class Initialized
INFO - 2023-07-11 07:15:17 --> Router Class Initialized
INFO - 2023-07-11 07:15:17 --> Output Class Initialized
INFO - 2023-07-11 07:15:17 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:17 --> Input Class Initialized
INFO - 2023-07-11 07:15:17 --> Language Class Initialized
INFO - 2023-07-11 07:15:17 --> Loader Class Initialized
INFO - 2023-07-11 07:15:17 --> Helper loaded: url_helper
INFO - 2023-07-11 07:15:17 --> Database Driver Class Initialized
INFO - 2023-07-11 07:15:17 --> Controller Class Initialized
INFO - 2023-07-11 07:15:17 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:15:17 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 07:15:17 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:15:17 --> Final output sent to browser
DEBUG - 2023-07-11 07:15:17 --> Total execution time: 0.1577
INFO - 2023-07-11 07:15:17 --> Config Class Initialized
INFO - 2023-07-11 07:15:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:17 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:17 --> URI Class Initialized
INFO - 2023-07-11 07:15:17 --> Router Class Initialized
INFO - 2023-07-11 07:15:17 --> Output Class Initialized
INFO - 2023-07-11 07:15:17 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:17 --> Input Class Initialized
INFO - 2023-07-11 07:15:17 --> Language Class Initialized
ERROR - 2023-07-11 07:15:17 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:17 --> Config Class Initialized
INFO - 2023-07-11 07:15:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:17 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:17 --> URI Class Initialized
INFO - 2023-07-11 07:15:17 --> Router Class Initialized
INFO - 2023-07-11 07:15:17 --> Output Class Initialized
INFO - 2023-07-11 07:15:17 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:17 --> Input Class Initialized
INFO - 2023-07-11 07:15:17 --> Language Class Initialized
ERROR - 2023-07-11 07:15:17 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:17 --> Config Class Initialized
INFO - 2023-07-11 07:15:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:17 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:17 --> URI Class Initialized
INFO - 2023-07-11 07:15:17 --> Router Class Initialized
INFO - 2023-07-11 07:15:17 --> Output Class Initialized
INFO - 2023-07-11 07:15:17 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:17 --> Input Class Initialized
INFO - 2023-07-11 07:15:17 --> Language Class Initialized
ERROR - 2023-07-11 07:15:17 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:17 --> Config Class Initialized
INFO - 2023-07-11 07:15:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:17 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:17 --> URI Class Initialized
INFO - 2023-07-11 07:15:17 --> Router Class Initialized
INFO - 2023-07-11 07:15:17 --> Output Class Initialized
INFO - 2023-07-11 07:15:17 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:17 --> Input Class Initialized
INFO - 2023-07-11 07:15:17 --> Language Class Initialized
ERROR - 2023-07-11 07:15:17 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:15:18 --> Config Class Initialized
INFO - 2023-07-11 07:15:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:18 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:18 --> URI Class Initialized
INFO - 2023-07-11 07:15:18 --> Router Class Initialized
INFO - 2023-07-11 07:15:18 --> Output Class Initialized
INFO - 2023-07-11 07:15:18 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:18 --> Input Class Initialized
INFO - 2023-07-11 07:15:18 --> Language Class Initialized
ERROR - 2023-07-11 07:15:18 --> 404 Page Not Found: About/index
INFO - 2023-07-11 07:15:26 --> Config Class Initialized
INFO - 2023-07-11 07:15:26 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:26 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:26 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:26 --> URI Class Initialized
INFO - 2023-07-11 07:15:26 --> Router Class Initialized
INFO - 2023-07-11 07:15:26 --> Output Class Initialized
INFO - 2023-07-11 07:15:26 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:26 --> Input Class Initialized
INFO - 2023-07-11 07:15:26 --> Language Class Initialized
INFO - 2023-07-11 07:15:26 --> Loader Class Initialized
INFO - 2023-07-11 07:15:26 --> Helper loaded: url_helper
INFO - 2023-07-11 07:15:26 --> Database Driver Class Initialized
INFO - 2023-07-11 07:15:26 --> Controller Class Initialized
INFO - 2023-07-11 07:15:26 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:15:26 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 07:15:26 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:15:26 --> Final output sent to browser
DEBUG - 2023-07-11 07:15:26 --> Total execution time: 0.0590
INFO - 2023-07-11 07:15:26 --> Config Class Initialized
INFO - 2023-07-11 07:15:26 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:26 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:26 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:26 --> URI Class Initialized
INFO - 2023-07-11 07:15:26 --> Router Class Initialized
INFO - 2023-07-11 07:15:26 --> Output Class Initialized
INFO - 2023-07-11 07:15:26 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:26 --> Input Class Initialized
INFO - 2023-07-11 07:15:26 --> Language Class Initialized
ERROR - 2023-07-11 07:15:26 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:26 --> Config Class Initialized
INFO - 2023-07-11 07:15:26 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:26 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:26 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:26 --> URI Class Initialized
INFO - 2023-07-11 07:15:26 --> Router Class Initialized
INFO - 2023-07-11 07:15:26 --> Output Class Initialized
INFO - 2023-07-11 07:15:26 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:26 --> Input Class Initialized
INFO - 2023-07-11 07:15:26 --> Language Class Initialized
ERROR - 2023-07-11 07:15:26 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:26 --> Config Class Initialized
INFO - 2023-07-11 07:15:26 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:26 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:26 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:26 --> URI Class Initialized
INFO - 2023-07-11 07:15:26 --> Router Class Initialized
INFO - 2023-07-11 07:15:26 --> Output Class Initialized
INFO - 2023-07-11 07:15:26 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:26 --> Input Class Initialized
INFO - 2023-07-11 07:15:26 --> Language Class Initialized
ERROR - 2023-07-11 07:15:26 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:15:28 --> Config Class Initialized
INFO - 2023-07-11 07:15:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:28 --> URI Class Initialized
INFO - 2023-07-11 07:15:28 --> Router Class Initialized
INFO - 2023-07-11 07:15:28 --> Output Class Initialized
INFO - 2023-07-11 07:15:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:28 --> Input Class Initialized
INFO - 2023-07-11 07:15:28 --> Language Class Initialized
INFO - 2023-07-11 07:15:28 --> Loader Class Initialized
INFO - 2023-07-11 07:15:28 --> Helper loaded: url_helper
INFO - 2023-07-11 07:15:28 --> Database Driver Class Initialized
INFO - 2023-07-11 07:15:28 --> Controller Class Initialized
INFO - 2023-07-11 07:15:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:15:28 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 07:15:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:15:28 --> Final output sent to browser
DEBUG - 2023-07-11 07:15:28 --> Total execution time: 0.1936
INFO - 2023-07-11 07:15:29 --> Config Class Initialized
INFO - 2023-07-11 07:15:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:29 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:29 --> URI Class Initialized
INFO - 2023-07-11 07:15:29 --> Router Class Initialized
INFO - 2023-07-11 07:15:29 --> Output Class Initialized
INFO - 2023-07-11 07:15:29 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:29 --> Input Class Initialized
INFO - 2023-07-11 07:15:29 --> Language Class Initialized
ERROR - 2023-07-11 07:15:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:15:29 --> Config Class Initialized
INFO - 2023-07-11 07:15:29 --> Hooks Class Initialized
INFO - 2023-07-11 07:15:29 --> Config Class Initialized
INFO - 2023-07-11 07:15:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:29 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:15:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:29 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:29 --> URI Class Initialized
INFO - 2023-07-11 07:15:29 --> URI Class Initialized
INFO - 2023-07-11 07:15:29 --> Router Class Initialized
INFO - 2023-07-11 07:15:29 --> Router Class Initialized
INFO - 2023-07-11 07:15:29 --> Output Class Initialized
INFO - 2023-07-11 07:15:29 --> Output Class Initialized
INFO - 2023-07-11 07:15:29 --> Security Class Initialized
INFO - 2023-07-11 07:15:29 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:29 --> Input Class Initialized
INFO - 2023-07-11 07:15:29 --> Language Class Initialized
DEBUG - 2023-07-11 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:29 --> Input Class Initialized
INFO - 2023-07-11 07:15:29 --> Language Class Initialized
ERROR - 2023-07-11 07:15:29 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 07:15:29 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 07:15:29 --> Config Class Initialized
INFO - 2023-07-11 07:15:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:15:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:15:29 --> Utf8 Class Initialized
INFO - 2023-07-11 07:15:29 --> URI Class Initialized
INFO - 2023-07-11 07:15:29 --> Router Class Initialized
INFO - 2023-07-11 07:15:29 --> Output Class Initialized
INFO - 2023-07-11 07:15:29 --> Security Class Initialized
DEBUG - 2023-07-11 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:15:29 --> Input Class Initialized
INFO - 2023-07-11 07:15:29 --> Language Class Initialized
ERROR - 2023-07-11 07:15:29 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:32:54 --> Config Class Initialized
INFO - 2023-07-11 07:32:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:54 --> URI Class Initialized
INFO - 2023-07-11 07:32:54 --> Router Class Initialized
INFO - 2023-07-11 07:32:54 --> Output Class Initialized
INFO - 2023-07-11 07:32:54 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:54 --> Input Class Initialized
INFO - 2023-07-11 07:32:54 --> Language Class Initialized
INFO - 2023-07-11 07:32:54 --> Loader Class Initialized
INFO - 2023-07-11 07:32:54 --> Helper loaded: url_helper
INFO - 2023-07-11 07:32:54 --> Database Driver Class Initialized
INFO - 2023-07-11 07:32:54 --> Controller Class Initialized
INFO - 2023-07-11 07:32:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:32:54 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:32:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:32:54 --> Final output sent to browser
DEBUG - 2023-07-11 07:32:54 --> Total execution time: 0.1455
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:32:55 --> Config Class Initialized
INFO - 2023-07-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:32:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:32:55 --> Utf8 Class Initialized
INFO - 2023-07-11 07:32:55 --> URI Class Initialized
INFO - 2023-07-11 07:32:55 --> Router Class Initialized
INFO - 2023-07-11 07:32:55 --> Output Class Initialized
INFO - 2023-07-11 07:32:55 --> Security Class Initialized
DEBUG - 2023-07-11 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:32:55 --> Input Class Initialized
INFO - 2023-07-11 07:32:55 --> Language Class Initialized
ERROR - 2023-07-11 07:32:55 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:27 --> Config Class Initialized
INFO - 2023-07-11 07:48:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:27 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:27 --> URI Class Initialized
INFO - 2023-07-11 07:48:27 --> Router Class Initialized
INFO - 2023-07-11 07:48:27 --> Output Class Initialized
INFO - 2023-07-11 07:48:27 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:27 --> Input Class Initialized
INFO - 2023-07-11 07:48:27 --> Language Class Initialized
INFO - 2023-07-11 07:48:27 --> Loader Class Initialized
INFO - 2023-07-11 07:48:27 --> Helper loaded: url_helper
INFO - 2023-07-11 07:48:27 --> Database Driver Class Initialized
INFO - 2023-07-11 07:48:27 --> Controller Class Initialized
INFO - 2023-07-11 07:48:27 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:48:27 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:48:27 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:48:27 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:48:27 --> Final output sent to browser
DEBUG - 2023-07-11 07:48:27 --> Total execution time: 0.4108
INFO - 2023-07-11 07:48:27 --> Config Class Initialized
INFO - 2023-07-11 07:48:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:27 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:27 --> Config Class Initialized
INFO - 2023-07-11 07:48:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:27 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:27 --> URI Class Initialized
INFO - 2023-07-11 07:48:27 --> Router Class Initialized
INFO - 2023-07-11 07:48:27 --> Output Class Initialized
INFO - 2023-07-11 07:48:27 --> Config Class Initialized
INFO - 2023-07-11 07:48:27 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:27 --> Security Class Initialized
INFO - 2023-07-11 07:48:27 --> Config Class Initialized
INFO - 2023-07-11 07:48:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:27 --> Input Class Initialized
DEBUG - 2023-07-11 07:48:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:27 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:27 --> Language Class Initialized
INFO - 2023-07-11 07:48:27 --> URI Class Initialized
ERROR - 2023-07-11 07:48:27 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:48:27 --> Router Class Initialized
DEBUG - 2023-07-11 07:48:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:27 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:27 --> URI Class Initialized
INFO - 2023-07-11 07:48:27 --> Output Class Initialized
INFO - 2023-07-11 07:48:27 --> Security Class Initialized
INFO - 2023-07-11 07:48:27 --> Router Class Initialized
DEBUG - 2023-07-11 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:27 --> Input Class Initialized
INFO - 2023-07-11 07:48:27 --> Output Class Initialized
INFO - 2023-07-11 07:48:27 --> Language Class Initialized
INFO - 2023-07-11 07:48:27 --> Security Class Initialized
ERROR - 2023-07-11 07:48:27 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:27 --> Input Class Initialized
INFO - 2023-07-11 07:48:27 --> Language Class Initialized
INFO - 2023-07-11 07:48:27 --> URI Class Initialized
ERROR - 2023-07-11 07:48:27 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:27 --> Router Class Initialized
INFO - 2023-07-11 07:48:27 --> Output Class Initialized
INFO - 2023-07-11 07:48:27 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:27 --> Input Class Initialized
INFO - 2023-07-11 07:48:27 --> Language Class Initialized
ERROR - 2023-07-11 07:48:27 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:27 --> Config Class Initialized
INFO - 2023-07-11 07:48:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:27 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:27 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:48:28 --> Config Class Initialized
INFO - 2023-07-11 07:48:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:28 --> URI Class Initialized
INFO - 2023-07-11 07:48:28 --> Router Class Initialized
INFO - 2023-07-11 07:48:28 --> Output Class Initialized
INFO - 2023-07-11 07:48:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:28 --> Input Class Initialized
INFO - 2023-07-11 07:48:28 --> Language Class Initialized
ERROR - 2023-07-11 07:48:28 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:48:38 --> Config Class Initialized
INFO - 2023-07-11 07:48:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:38 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:38 --> URI Class Initialized
INFO - 2023-07-11 07:48:38 --> Router Class Initialized
INFO - 2023-07-11 07:48:38 --> Output Class Initialized
INFO - 2023-07-11 07:48:38 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:38 --> Input Class Initialized
INFO - 2023-07-11 07:48:38 --> Language Class Initialized
INFO - 2023-07-11 07:48:38 --> Loader Class Initialized
INFO - 2023-07-11 07:48:38 --> Helper loaded: url_helper
INFO - 2023-07-11 07:48:38 --> Database Driver Class Initialized
INFO - 2023-07-11 07:48:38 --> Controller Class Initialized
INFO - 2023-07-11 07:48:38 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:48:38 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 07:48:38 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:48:38 --> Final output sent to browser
DEBUG - 2023-07-11 07:48:38 --> Total execution time: 0.1584
INFO - 2023-07-11 07:48:38 --> Config Class Initialized
INFO - 2023-07-11 07:48:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:38 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:38 --> URI Class Initialized
INFO - 2023-07-11 07:48:38 --> Router Class Initialized
INFO - 2023-07-11 07:48:38 --> Output Class Initialized
INFO - 2023-07-11 07:48:38 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:38 --> Input Class Initialized
INFO - 2023-07-11 07:48:38 --> Language Class Initialized
ERROR - 2023-07-11 07:48:38 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:48:38 --> Config Class Initialized
INFO - 2023-07-11 07:48:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:38 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:38 --> URI Class Initialized
INFO - 2023-07-11 07:48:38 --> Config Class Initialized
INFO - 2023-07-11 07:48:38 --> Hooks Class Initialized
INFO - 2023-07-11 07:48:38 --> Router Class Initialized
INFO - 2023-07-11 07:48:38 --> Output Class Initialized
DEBUG - 2023-07-11 07:48:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:38 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:38 --> URI Class Initialized
INFO - 2023-07-11 07:48:38 --> Security Class Initialized
INFO - 2023-07-11 07:48:38 --> Router Class Initialized
DEBUG - 2023-07-11 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:38 --> Input Class Initialized
INFO - 2023-07-11 07:48:38 --> Output Class Initialized
INFO - 2023-07-11 07:48:38 --> Language Class Initialized
INFO - 2023-07-11 07:48:38 --> Security Class Initialized
ERROR - 2023-07-11 07:48:38 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:38 --> Input Class Initialized
INFO - 2023-07-11 07:48:38 --> Language Class Initialized
ERROR - 2023-07-11 07:48:38 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 07:48:38 --> Config Class Initialized
INFO - 2023-07-11 07:48:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:38 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:38 --> URI Class Initialized
INFO - 2023-07-11 07:48:38 --> Router Class Initialized
INFO - 2023-07-11 07:48:38 --> Output Class Initialized
INFO - 2023-07-11 07:48:38 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:38 --> Input Class Initialized
INFO - 2023-07-11 07:48:38 --> Language Class Initialized
ERROR - 2023-07-11 07:48:38 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:48:40 --> Config Class Initialized
INFO - 2023-07-11 07:48:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:48:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:48:40 --> Utf8 Class Initialized
INFO - 2023-07-11 07:48:40 --> URI Class Initialized
INFO - 2023-07-11 07:48:40 --> Router Class Initialized
INFO - 2023-07-11 07:48:40 --> Output Class Initialized
INFO - 2023-07-11 07:48:40 --> Security Class Initialized
DEBUG - 2023-07-11 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:48:40 --> Input Class Initialized
INFO - 2023-07-11 07:48:40 --> Language Class Initialized
ERROR - 2023-07-11 07:48:40 --> 404 Page Not Found: UserListctr/edit1
INFO - 2023-07-11 07:54:31 --> Config Class Initialized
INFO - 2023-07-11 07:54:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:31 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:31 --> URI Class Initialized
INFO - 2023-07-11 07:54:31 --> Router Class Initialized
INFO - 2023-07-11 07:54:31 --> Output Class Initialized
INFO - 2023-07-11 07:54:31 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:31 --> Input Class Initialized
INFO - 2023-07-11 07:54:31 --> Language Class Initialized
INFO - 2023-07-11 07:54:31 --> Loader Class Initialized
INFO - 2023-07-11 07:54:31 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:31 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:31 --> Controller Class Initialized
INFO - 2023-07-11 07:54:31 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:54:31 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:54:31 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:54:31 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:31 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:31 --> Total execution time: 0.0956
INFO - 2023-07-11 07:54:31 --> Config Class Initialized
INFO - 2023-07-11 07:54:31 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:31 --> Config Class Initialized
INFO - 2023-07-11 07:54:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:31 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:31 --> URI Class Initialized
DEBUG - 2023-07-11 07:54:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:31 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:31 --> Router Class Initialized
INFO - 2023-07-11 07:54:31 --> URI Class Initialized
INFO - 2023-07-11 07:54:31 --> Output Class Initialized
INFO - 2023-07-11 07:54:31 --> Router Class Initialized
INFO - 2023-07-11 07:54:31 --> Security Class Initialized
INFO - 2023-07-11 07:54:31 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: UserListctr/assest
INFO - 2023-07-11 07:54:32 --> Config Class Initialized
INFO - 2023-07-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:32 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:32 --> URI Class Initialized
INFO - 2023-07-11 07:54:32 --> Router Class Initialized
INFO - 2023-07-11 07:54:32 --> Output Class Initialized
INFO - 2023-07-11 07:54:32 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:32 --> Input Class Initialized
INFO - 2023-07-11 07:54:32 --> Language Class Initialized
ERROR - 2023-07-11 07:54:32 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:54:40 --> Config Class Initialized
INFO - 2023-07-11 07:54:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:40 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:40 --> URI Class Initialized
INFO - 2023-07-11 07:54:40 --> Router Class Initialized
INFO - 2023-07-11 07:54:40 --> Output Class Initialized
INFO - 2023-07-11 07:54:40 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:40 --> Input Class Initialized
INFO - 2023-07-11 07:54:40 --> Language Class Initialized
ERROR - 2023-07-11 07:54:40 --> 404 Page Not Found: UserListctr/edit1
INFO - 2023-07-11 07:54:52 --> Config Class Initialized
INFO - 2023-07-11 07:54:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:52 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:52 --> URI Class Initialized
INFO - 2023-07-11 07:54:52 --> Router Class Initialized
INFO - 2023-07-11 07:54:52 --> Output Class Initialized
INFO - 2023-07-11 07:54:52 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:52 --> Input Class Initialized
INFO - 2023-07-11 07:54:52 --> Language Class Initialized
INFO - 2023-07-11 07:54:52 --> Loader Class Initialized
INFO - 2023-07-11 07:54:52 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:52 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:52 --> Controller Class Initialized
INFO - 2023-07-11 07:54:52 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:52 --> File loaded: C:\xampp\htdocs\code\application\views\/Student/listing.php
INFO - 2023-07-11 07:54:52 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:52 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:52 --> Total execution time: 0.0918
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:53 --> Config Class Initialized
INFO - 2023-07-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:53 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:53 --> URI Class Initialized
INFO - 2023-07-11 07:54:53 --> Router Class Initialized
INFO - 2023-07-11 07:54:53 --> Output Class Initialized
INFO - 2023-07-11 07:54:53 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:53 --> Input Class Initialized
INFO - 2023-07-11 07:54:53 --> Language Class Initialized
ERROR - 2023-07-11 07:54:53 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:54 --> Config Class Initialized
INFO - 2023-07-11 07:54:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:54 --> URI Class Initialized
INFO - 2023-07-11 07:54:54 --> Router Class Initialized
INFO - 2023-07-11 07:54:54 --> Output Class Initialized
INFO - 2023-07-11 07:54:54 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:54 --> Input Class Initialized
INFO - 2023-07-11 07:54:54 --> Language Class Initialized
ERROR - 2023-07-11 07:54:54 --> 404 Page Not Found: Student/assest
INFO - 2023-07-11 07:54:54 --> Config Class Initialized
INFO - 2023-07-11 07:54:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:54 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:54 --> URI Class Initialized
INFO - 2023-07-11 07:54:54 --> Router Class Initialized
INFO - 2023-07-11 07:54:54 --> Output Class Initialized
INFO - 2023-07-11 07:54:54 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:54 --> Input Class Initialized
INFO - 2023-07-11 07:54:54 --> Language Class Initialized
ERROR - 2023-07-11 07:54:54 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1664
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
ERROR - 2023-07-11 07:54:57 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1236
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1073
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1314
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1355
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1463
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1501
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1588
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1686
DEBUG - 2023-07-11 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:57 --> Input Class Initialized
INFO - 2023-07-11 07:54:57 --> Language Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
INFO - 2023-07-11 07:54:57 --> Loader Class Initialized
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1895
INFO - 2023-07-11 07:54:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:57 --> Controller Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:57 --> Config Class Initialized
INFO - 2023-07-11 07:54:57 --> Hooks Class Initialized
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
ERROR - 2023-07-11 07:54:57 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
DEBUG - 2023-07-11 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:57 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:57 --> Total execution time: 0.1816
INFO - 2023-07-11 07:54:57 --> URI Class Initialized
INFO - 2023-07-11 07:54:57 --> Router Class Initialized
INFO - 2023-07-11 07:54:57 --> Output Class Initialized
INFO - 2023-07-11 07:54:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:58 --> Input Class Initialized
INFO - 2023-07-11 07:54:58 --> Language Class Initialized
INFO - 2023-07-11 07:54:58 --> Loader Class Initialized
INFO - 2023-07-11 07:54:58 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:58 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:58 --> Controller Class Initialized
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:58 --> Config Class Initialized
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
INFO - 2023-07-11 07:54:58 --> Hooks Class Initialized
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
DEBUG - 2023-07-11 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:58 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:58 --> Final output sent to browser
INFO - 2023-07-11 07:54:58 --> URI Class Initialized
DEBUG - 2023-07-11 07:54:58 --> Total execution time: 0.0840
INFO - 2023-07-11 07:54:58 --> Router Class Initialized
INFO - 2023-07-11 07:54:58 --> Output Class Initialized
INFO - 2023-07-11 07:54:58 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:58 --> Input Class Initialized
INFO - 2023-07-11 07:54:58 --> Language Class Initialized
INFO - 2023-07-11 07:54:58 --> Loader Class Initialized
INFO - 2023-07-11 07:54:58 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:58 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:58 --> Controller Class Initialized
INFO - 2023-07-11 07:54:58 --> Config Class Initialized
INFO - 2023-07-11 07:54:58 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
INFO - 2023-07-11 07:54:58 --> Config Class Initialized
DEBUG - 2023-07-11 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:58 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:58 --> Hooks Class Initialized
INFO - 2023-07-11 07:54:58 --> URI Class Initialized
INFO - 2023-07-11 07:54:58 --> Config Class Initialized
INFO - 2023-07-11 07:54:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:58 --> Router Class Initialized
INFO - 2023-07-11 07:54:58 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:58 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:58 --> Output Class Initialized
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
INFO - 2023-07-11 07:54:58 --> URI Class Initialized
INFO - 2023-07-11 07:54:58 --> Security Class Initialized
INFO - 2023-07-11 07:54:58 --> URI Class Initialized
INFO - 2023-07-11 07:54:58 --> Router Class Initialized
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
DEBUG - 2023-07-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:58 --> Input Class Initialized
INFO - 2023-07-11 07:54:58 --> Router Class Initialized
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:58 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:58 --> Total execution time: 0.1623
INFO - 2023-07-11 07:54:58 --> Output Class Initialized
INFO - 2023-07-11 07:54:58 --> Language Class Initialized
INFO - 2023-07-11 07:54:58 --> Security Class Initialized
INFO - 2023-07-11 07:54:58 --> Output Class Initialized
DEBUG - 2023-07-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:58 --> Security Class Initialized
INFO - 2023-07-11 07:54:58 --> Input Class Initialized
INFO - 2023-07-11 07:54:58 --> Language Class Initialized
DEBUG - 2023-07-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:58 --> Loader Class Initialized
INFO - 2023-07-11 07:54:58 --> Input Class Initialized
INFO - 2023-07-11 07:54:58 --> Language Class Initialized
INFO - 2023-07-11 07:54:58 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:58 --> Loader Class Initialized
INFO - 2023-07-11 07:54:58 --> Loader Class Initialized
INFO - 2023-07-11 07:54:58 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:58 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:58 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:58 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:58 --> Controller Class Initialized
INFO - 2023-07-11 07:54:58 --> Controller Class Initialized
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:58 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:58 --> Total execution time: 0.1305
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:58 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:58 --> Total execution time: 0.0971
INFO - 2023-07-11 07:54:58 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:58 --> Controller Class Initialized
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:58 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:58 --> Total execution time: 0.1860
INFO - 2023-07-11 07:54:58 --> Config Class Initialized
INFO - 2023-07-11 07:54:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:58 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:58 --> URI Class Initialized
INFO - 2023-07-11 07:54:58 --> Router Class Initialized
INFO - 2023-07-11 07:54:58 --> Output Class Initialized
INFO - 2023-07-11 07:54:58 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:58 --> Input Class Initialized
INFO - 2023-07-11 07:54:58 --> Language Class Initialized
ERROR - 2023-07-11 07:54:58 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:54:58 --> Config Class Initialized
INFO - 2023-07-11 07:54:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:54:58 --> Utf8 Class Initialized
INFO - 2023-07-11 07:54:58 --> URI Class Initialized
INFO - 2023-07-11 07:54:58 --> Router Class Initialized
INFO - 2023-07-11 07:54:58 --> Output Class Initialized
INFO - 2023-07-11 07:54:58 --> Security Class Initialized
DEBUG - 2023-07-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:54:58 --> Input Class Initialized
INFO - 2023-07-11 07:54:58 --> Language Class Initialized
INFO - 2023-07-11 07:54:58 --> Loader Class Initialized
INFO - 2023-07-11 07:54:58 --> Helper loaded: url_helper
INFO - 2023-07-11 07:54:58 --> Database Driver Class Initialized
INFO - 2023-07-11 07:54:58 --> Controller Class Initialized
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 12
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 17
ERROR - 2023-07-11 07:54:58 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\code\application\views\Student\edit.php 22
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/student/edit.php
INFO - 2023-07-11 07:54:58 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:54:58 --> Final output sent to browser
DEBUG - 2023-07-11 07:54:58 --> Total execution time: 0.0608
INFO - 2023-07-11 07:55:12 --> Config Class Initialized
INFO - 2023-07-11 07:55:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:12 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:12 --> URI Class Initialized
INFO - 2023-07-11 07:55:12 --> Router Class Initialized
INFO - 2023-07-11 07:55:12 --> Output Class Initialized
INFO - 2023-07-11 07:55:12 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:12 --> Input Class Initialized
INFO - 2023-07-11 07:55:12 --> Language Class Initialized
INFO - 2023-07-11 07:55:12 --> Loader Class Initialized
INFO - 2023-07-11 07:55:12 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:12 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:12 --> Controller Class Initialized
INFO - 2023-07-11 07:55:12 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:12 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:12 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:12 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:12 --> Total execution time: 0.0663
INFO - 2023-07-11 07:55:12 --> Config Class Initialized
INFO - 2023-07-11 07:55:12 --> Config Class Initialized
INFO - 2023-07-11 07:55:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:12 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:12 --> Config Class Initialized
INFO - 2023-07-11 07:55:12 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:12 --> URI Class Initialized
INFO - 2023-07-11 07:55:12 --> Router Class Initialized
DEBUG - 2023-07-11 07:55:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:12 --> Output Class Initialized
INFO - 2023-07-11 07:55:12 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:12 --> URI Class Initialized
INFO - 2023-07-11 07:55:12 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:12 --> Input Class Initialized
INFO - 2023-07-11 07:55:12 --> Router Class Initialized
INFO - 2023-07-11 07:55:12 --> Language Class Initialized
INFO - 2023-07-11 07:55:12 --> Output Class Initialized
INFO - 2023-07-11 07:55:12 --> Loader Class Initialized
INFO - 2023-07-11 07:55:12 --> Security Class Initialized
INFO - 2023-07-11 07:55:12 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:12 --> Helper loaded: url_helper
DEBUG - 2023-07-11 07:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:12 --> Input Class Initialized
INFO - 2023-07-11 07:55:12 --> Language Class Initialized
ERROR - 2023-07-11 07:55:12 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:55:12 --> Config Class Initialized
INFO - 2023-07-11 07:55:12 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:12 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:55:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:12 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:55:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:12 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:12 --> URI Class Initialized
INFO - 2023-07-11 07:55:12 --> URI Class Initialized
INFO - 2023-07-11 07:55:12 --> Router Class Initialized
INFO - 2023-07-11 07:55:12 --> Router Class Initialized
INFO - 2023-07-11 07:55:12 --> Controller Class Initialized
INFO - 2023-07-11 07:55:12 --> Config Class Initialized
INFO - 2023-07-11 07:55:12 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:12 --> Hooks Class Initialized
ERROR - 2023-07-11 07:55:12 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:12 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
DEBUG - 2023-07-11 07:55:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:12 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:55:12 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:12 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:55:12 --> URI Class Initialized
INFO - 2023-07-11 07:55:12 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1416
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.2000
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1650
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1397
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1510
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1715
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.2574
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.2943
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.2425
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.3451
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1525
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1436
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1979
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1570
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:13 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:13 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:13 --> Total execution time: 0.1889
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
ERROR - 2023-07-11 07:55:13 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:55:13 --> Config Class Initialized
INFO - 2023-07-11 07:55:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:13 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:13 --> URI Class Initialized
INFO - 2023-07-11 07:55:13 --> Router Class Initialized
INFO - 2023-07-11 07:55:13 --> Output Class Initialized
INFO - 2023-07-11 07:55:13 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:13 --> Input Class Initialized
INFO - 2023-07-11 07:55:13 --> Language Class Initialized
INFO - 2023-07-11 07:55:13 --> Loader Class Initialized
INFO - 2023-07-11 07:55:13 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:13 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:13 --> Controller Class Initialized
INFO - 2023-07-11 07:55:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:14 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:14 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:14 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:14 --> Total execution time: 0.0840
INFO - 2023-07-11 07:55:45 --> Config Class Initialized
INFO - 2023-07-11 07:55:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:45 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:45 --> URI Class Initialized
INFO - 2023-07-11 07:55:45 --> Router Class Initialized
INFO - 2023-07-11 07:55:45 --> Output Class Initialized
INFO - 2023-07-11 07:55:45 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:45 --> Input Class Initialized
INFO - 2023-07-11 07:55:45 --> Language Class Initialized
INFO - 2023-07-11 07:55:45 --> Loader Class Initialized
INFO - 2023-07-11 07:55:45 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:45 --> Controller Class Initialized
INFO - 2023-07-11 07:55:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:46 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 07:55:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:46 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:46 --> Total execution time: 0.1867
INFO - 2023-07-11 07:55:46 --> Config Class Initialized
INFO - 2023-07-11 07:55:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:46 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:46 --> URI Class Initialized
INFO - 2023-07-11 07:55:46 --> Router Class Initialized
INFO - 2023-07-11 07:55:46 --> Output Class Initialized
INFO - 2023-07-11 07:55:46 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:46 --> Input Class Initialized
INFO - 2023-07-11 07:55:46 --> Language Class Initialized
ERROR - 2023-07-11 07:55:46 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:55:46 --> Config Class Initialized
INFO - 2023-07-11 07:55:46 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:46 --> Config Class Initialized
INFO - 2023-07-11 07:55:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:46 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:55:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:46 --> URI Class Initialized
INFO - 2023-07-11 07:55:46 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:46 --> URI Class Initialized
INFO - 2023-07-11 07:55:46 --> Router Class Initialized
INFO - 2023-07-11 07:55:46 --> Router Class Initialized
INFO - 2023-07-11 07:55:46 --> Output Class Initialized
INFO - 2023-07-11 07:55:46 --> Security Class Initialized
INFO - 2023-07-11 07:55:46 --> Output Class Initialized
DEBUG - 2023-07-11 07:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:46 --> Input Class Initialized
INFO - 2023-07-11 07:55:46 --> Security Class Initialized
INFO - 2023-07-11 07:55:46 --> Language Class Initialized
DEBUG - 2023-07-11 07:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:46 --> Input Class Initialized
INFO - 2023-07-11 07:55:46 --> Language Class Initialized
ERROR - 2023-07-11 07:55:46 --> 404 Page Not Found: Indexjs/index
ERROR - 2023-07-11 07:55:46 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 07:55:46 --> Config Class Initialized
INFO - 2023-07-11 07:55:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:46 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:46 --> URI Class Initialized
INFO - 2023-07-11 07:55:46 --> Router Class Initialized
INFO - 2023-07-11 07:55:46 --> Output Class Initialized
INFO - 2023-07-11 07:55:46 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:46 --> Input Class Initialized
INFO - 2023-07-11 07:55:46 --> Language Class Initialized
ERROR - 2023-07-11 07:55:46 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:55:48 --> Config Class Initialized
INFO - 2023-07-11 07:55:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:48 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.0648
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
ERROR - 2023-07-11 07:55:49 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1439
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1840
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.2192
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1927
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1388
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1789
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.2034
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.2231
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1983
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.3801
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:49 --> Loader Class Initialized
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1036
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:49 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> Controller Class Initialized
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1787
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1638
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:55:49 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1921
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:49 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:49 --> Total execution time: 0.1916
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:49 --> Output Class Initialized
INFO - 2023-07-11 07:55:49 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:49 --> Input Class Initialized
INFO - 2023-07-11 07:55:49 --> Language Class Initialized
ERROR - 2023-07-11 07:55:49 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:55:49 --> Config Class Initialized
INFO - 2023-07-11 07:55:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:55:49 --> Utf8 Class Initialized
INFO - 2023-07-11 07:55:49 --> URI Class Initialized
INFO - 2023-07-11 07:55:49 --> Router Class Initialized
INFO - 2023-07-11 07:55:50 --> Output Class Initialized
INFO - 2023-07-11 07:55:50 --> Security Class Initialized
DEBUG - 2023-07-11 07:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:55:50 --> Input Class Initialized
INFO - 2023-07-11 07:55:50 --> Language Class Initialized
INFO - 2023-07-11 07:55:50 --> Loader Class Initialized
INFO - 2023-07-11 07:55:50 --> Helper loaded: url_helper
INFO - 2023-07-11 07:55:50 --> Database Driver Class Initialized
INFO - 2023-07-11 07:55:50 --> Controller Class Initialized
INFO - 2023-07-11 07:55:50 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:55:50 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:55:50 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:55:50 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:55:50 --> Final output sent to browser
DEBUG - 2023-07-11 07:55:50 --> Total execution time: 0.0691
INFO - 2023-07-11 07:56:07 --> Config Class Initialized
INFO - 2023-07-11 07:56:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:56:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:56:07 --> Utf8 Class Initialized
INFO - 2023-07-11 07:56:07 --> URI Class Initialized
INFO - 2023-07-11 07:56:07 --> Router Class Initialized
INFO - 2023-07-11 07:56:07 --> Output Class Initialized
INFO - 2023-07-11 07:56:07 --> Security Class Initialized
DEBUG - 2023-07-11 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:56:07 --> Input Class Initialized
INFO - 2023-07-11 07:56:07 --> Language Class Initialized
INFO - 2023-07-11 07:56:07 --> Loader Class Initialized
INFO - 2023-07-11 07:56:07 --> Helper loaded: url_helper
INFO - 2023-07-11 07:56:07 --> Database Driver Class Initialized
INFO - 2023-07-11 07:56:07 --> Controller Class Initialized
INFO - 2023-07-11 07:56:08 --> Config Class Initialized
INFO - 2023-07-11 07:56:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:56:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:56:08 --> Utf8 Class Initialized
INFO - 2023-07-11 07:56:08 --> URI Class Initialized
INFO - 2023-07-11 07:56:08 --> Router Class Initialized
INFO - 2023-07-11 07:56:08 --> Output Class Initialized
INFO - 2023-07-11 07:56:08 --> Security Class Initialized
DEBUG - 2023-07-11 07:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:56:08 --> Input Class Initialized
INFO - 2023-07-11 07:56:08 --> Language Class Initialized
ERROR - 2023-07-11 07:56:08 --> 404 Page Not Found: UserList/index
INFO - 2023-07-11 07:56:37 --> Config Class Initialized
INFO - 2023-07-11 07:56:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:56:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:56:37 --> Utf8 Class Initialized
INFO - 2023-07-11 07:56:37 --> URI Class Initialized
INFO - 2023-07-11 07:56:37 --> Router Class Initialized
INFO - 2023-07-11 07:56:37 --> Output Class Initialized
INFO - 2023-07-11 07:56:37 --> Security Class Initialized
DEBUG - 2023-07-11 07:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:56:37 --> Input Class Initialized
INFO - 2023-07-11 07:56:37 --> Language Class Initialized
INFO - 2023-07-11 07:56:37 --> Loader Class Initialized
INFO - 2023-07-11 07:56:37 --> Helper loaded: url_helper
INFO - 2023-07-11 07:56:37 --> Database Driver Class Initialized
INFO - 2023-07-11 07:56:37 --> Controller Class Initialized
INFO - 2023-07-11 07:56:37 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:56:37 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 07:56:37 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:56:37 --> Final output sent to browser
DEBUG - 2023-07-11 07:56:37 --> Total execution time: 0.0686
INFO - 2023-07-11 07:56:37 --> Config Class Initialized
INFO - 2023-07-11 07:56:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:56:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:56:37 --> Utf8 Class Initialized
INFO - 2023-07-11 07:56:37 --> URI Class Initialized
INFO - 2023-07-11 07:56:37 --> Router Class Initialized
INFO - 2023-07-11 07:56:37 --> Output Class Initialized
INFO - 2023-07-11 07:56:37 --> Security Class Initialized
DEBUG - 2023-07-11 07:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:56:37 --> Input Class Initialized
INFO - 2023-07-11 07:56:37 --> Language Class Initialized
INFO - 2023-07-11 07:56:37 --> Config Class Initialized
INFO - 2023-07-11 07:56:37 --> Hooks Class Initialized
ERROR - 2023-07-11 07:56:37 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 07:56:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:56:37 --> Utf8 Class Initialized
INFO - 2023-07-11 07:56:37 --> URI Class Initialized
INFO - 2023-07-11 07:56:37 --> Router Class Initialized
INFO - 2023-07-11 07:56:37 --> Output Class Initialized
INFO - 2023-07-11 07:56:37 --> Security Class Initialized
DEBUG - 2023-07-11 07:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:56:37 --> Input Class Initialized
INFO - 2023-07-11 07:56:37 --> Config Class Initialized
INFO - 2023-07-11 07:56:37 --> Hooks Class Initialized
INFO - 2023-07-11 07:56:37 --> Language Class Initialized
ERROR - 2023-07-11 07:56:37 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 07:56:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:56:37 --> Utf8 Class Initialized
INFO - 2023-07-11 07:56:37 --> URI Class Initialized
INFO - 2023-07-11 07:56:37 --> Router Class Initialized
INFO - 2023-07-11 07:56:37 --> Output Class Initialized
INFO - 2023-07-11 07:56:37 --> Security Class Initialized
DEBUG - 2023-07-11 07:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:56:37 --> Input Class Initialized
INFO - 2023-07-11 07:56:37 --> Language Class Initialized
ERROR - 2023-07-11 07:56:37 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 07:56:37 --> Config Class Initialized
INFO - 2023-07-11 07:56:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:56:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:56:37 --> Utf8 Class Initialized
INFO - 2023-07-11 07:56:37 --> URI Class Initialized
INFO - 2023-07-11 07:56:37 --> Router Class Initialized
INFO - 2023-07-11 07:56:37 --> Output Class Initialized
INFO - 2023-07-11 07:56:37 --> Security Class Initialized
DEBUG - 2023-07-11 07:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:56:37 --> Input Class Initialized
INFO - 2023-07-11 07:56:37 --> Language Class Initialized
ERROR - 2023-07-11 07:56:37 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:57:27 --> Config Class Initialized
INFO - 2023-07-11 07:57:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:27 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:27 --> URI Class Initialized
INFO - 2023-07-11 07:57:27 --> Router Class Initialized
INFO - 2023-07-11 07:57:27 --> Output Class Initialized
INFO - 2023-07-11 07:57:27 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:27 --> Input Class Initialized
INFO - 2023-07-11 07:57:27 --> Language Class Initialized
INFO - 2023-07-11 07:57:27 --> Loader Class Initialized
INFO - 2023-07-11 07:57:27 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:28 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:28 --> Controller Class Initialized
INFO - 2023-07-11 07:57:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:28 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 07:57:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:28 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:28 --> Total execution time: 0.2530
INFO - 2023-07-11 07:57:28 --> Config Class Initialized
INFO - 2023-07-11 07:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:28 --> URI Class Initialized
INFO - 2023-07-11 07:57:28 --> Router Class Initialized
INFO - 2023-07-11 07:57:28 --> Output Class Initialized
INFO - 2023-07-11 07:57:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:28 --> Input Class Initialized
INFO - 2023-07-11 07:57:28 --> Language Class Initialized
ERROR - 2023-07-11 07:57:28 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:57:28 --> Config Class Initialized
INFO - 2023-07-11 07:57:28 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:28 --> Config Class Initialized
INFO - 2023-07-11 07:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:28 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:28 --> URI Class Initialized
INFO - 2023-07-11 07:57:28 --> URI Class Initialized
INFO - 2023-07-11 07:57:28 --> Router Class Initialized
INFO - 2023-07-11 07:57:28 --> Router Class Initialized
INFO - 2023-07-11 07:57:28 --> Output Class Initialized
INFO - 2023-07-11 07:57:28 --> Output Class Initialized
INFO - 2023-07-11 07:57:28 --> Security Class Initialized
INFO - 2023-07-11 07:57:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:28 --> Input Class Initialized
DEBUG - 2023-07-11 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:28 --> Input Class Initialized
INFO - 2023-07-11 07:57:28 --> Language Class Initialized
INFO - 2023-07-11 07:57:28 --> Language Class Initialized
ERROR - 2023-07-11 07:57:28 --> 404 Page Not Found: Indexjs/index
ERROR - 2023-07-11 07:57:28 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 07:57:28 --> Config Class Initialized
INFO - 2023-07-11 07:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:28 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:28 --> URI Class Initialized
INFO - 2023-07-11 07:57:28 --> Router Class Initialized
INFO - 2023-07-11 07:57:28 --> Output Class Initialized
INFO - 2023-07-11 07:57:28 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:28 --> Input Class Initialized
INFO - 2023-07-11 07:57:28 --> Language Class Initialized
ERROR - 2023-07-11 07:57:28 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:34 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:34 --> Total execution time: 0.0568
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:34 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:34 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:34 --> Total execution time: 0.0978
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:34 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:34 --> Total execution time: 0.1234
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:57:34 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:34 --> Total execution time: 0.1794
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:34 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:34 --> Total execution time: 0.1205
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Config Class Initialized
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
INFO - 2023-07-11 07:57:34 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
DEBUG - 2023-07-11 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:34 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:34 --> URI Class Initialized
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:34 --> Router Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:34 --> Loader Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:34 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:57:34 --> Output Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:57:34 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
DEBUG - 2023-07-11 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:34 --> Final output sent to browser
INFO - 2023-07-11 07:57:34 --> Input Class Initialized
DEBUG - 2023-07-11 07:57:34 --> Total execution time: 0.1520
INFO - 2023-07-11 07:57:34 --> Language Class Initialized
INFO - 2023-07-11 07:57:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:34 --> Security Class Initialized
INFO - 2023-07-11 07:57:34 --> Controller Class Initialized
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:34 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.1601
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:57:35 --> Config Class Initialized
INFO - 2023-07-11 07:57:35 --> Hooks Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
DEBUG - 2023-07-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:35 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> Config Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:35 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:35 --> URI Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.2366
INFO - 2023-07-11 07:57:35 --> Router Class Initialized
DEBUG - 2023-07-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:35 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:35 --> Output Class Initialized
INFO - 2023-07-11 07:57:35 --> URI Class Initialized
INFO - 2023-07-11 07:57:35 --> Security Class Initialized
INFO - 2023-07-11 07:57:35 --> Router Class Initialized
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
INFO - 2023-07-11 07:57:35 --> Output Class Initialized
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
INFO - 2023-07-11 07:57:35 --> Security Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.3240
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.3609
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.3505
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:35 --> Config Class Initialized
INFO - 2023-07-11 07:57:35 --> Config Class Initialized
INFO - 2023-07-11 07:57:35 --> Hooks Class Initialized
INFO - 2023-07-11 07:57:35 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:35 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:35 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:35 --> URI Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:57:35 --> URI Class Initialized
INFO - 2023-07-11 07:57:35 --> Router Class Initialized
INFO - 2023-07-11 07:57:35 --> Router Class Initialized
INFO - 2023-07-11 07:57:35 --> Output Class Initialized
INFO - 2023-07-11 07:57:35 --> Output Class Initialized
INFO - 2023-07-11 07:57:35 --> Security Class Initialized
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:35 --> Security Class Initialized
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:57:35 --> Config Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:57:35 --> Hooks Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
DEBUG - 2023-07-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:35 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.2079
INFO - 2023-07-11 07:57:35 --> URI Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:57:35 --> Router Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:57:35 --> Output Class Initialized
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:57:35 --> Security Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.2391
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.1394
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.1589
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.1416
INFO - 2023-07-11 07:57:35 --> Config Class Initialized
INFO - 2023-07-11 07:57:35 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:35 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:35 --> URI Class Initialized
INFO - 2023-07-11 07:57:35 --> Router Class Initialized
INFO - 2023-07-11 07:57:35 --> Output Class Initialized
INFO - 2023-07-11 07:57:35 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
ERROR - 2023-07-11 07:57:35 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:57:35 --> Config Class Initialized
INFO - 2023-07-11 07:57:35 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:35 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:35 --> URI Class Initialized
INFO - 2023-07-11 07:57:35 --> Router Class Initialized
INFO - 2023-07-11 07:57:35 --> Output Class Initialized
INFO - 2023-07-11 07:57:35 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:35 --> Input Class Initialized
INFO - 2023-07-11 07:57:35 --> Language Class Initialized
INFO - 2023-07-11 07:57:35 --> Loader Class Initialized
INFO - 2023-07-11 07:57:35 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:35 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:35 --> Controller Class Initialized
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:57:35 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:57:35 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-07-11 07:57:35 --> Total execution time: 0.0898
INFO - 2023-07-11 07:57:57 --> Config Class Initialized
INFO - 2023-07-11 07:57:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:57 --> URI Class Initialized
INFO - 2023-07-11 07:57:57 --> Router Class Initialized
INFO - 2023-07-11 07:57:57 --> Output Class Initialized
INFO - 2023-07-11 07:57:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:57 --> Input Class Initialized
INFO - 2023-07-11 07:57:57 --> Language Class Initialized
INFO - 2023-07-11 07:57:57 --> Loader Class Initialized
INFO - 2023-07-11 07:57:57 --> Helper loaded: url_helper
INFO - 2023-07-11 07:57:57 --> Database Driver Class Initialized
INFO - 2023-07-11 07:57:57 --> Controller Class Initialized
INFO - 2023-07-11 07:57:57 --> Config Class Initialized
INFO - 2023-07-11 07:57:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:57:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:57:57 --> Utf8 Class Initialized
INFO - 2023-07-11 07:57:57 --> URI Class Initialized
INFO - 2023-07-11 07:57:57 --> Router Class Initialized
INFO - 2023-07-11 07:57:57 --> Output Class Initialized
INFO - 2023-07-11 07:57:57 --> Security Class Initialized
DEBUG - 2023-07-11 07:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:57:57 --> Input Class Initialized
INFO - 2023-07-11 07:57:57 --> Language Class Initialized
ERROR - 2023-07-11 07:57:57 --> 404 Page Not Found: Userlist/index
INFO - 2023-07-11 07:58:39 --> Config Class Initialized
INFO - 2023-07-11 07:58:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:39 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:39 --> URI Class Initialized
INFO - 2023-07-11 07:58:39 --> Router Class Initialized
INFO - 2023-07-11 07:58:39 --> Output Class Initialized
INFO - 2023-07-11 07:58:39 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:39 --> Input Class Initialized
INFO - 2023-07-11 07:58:39 --> Language Class Initialized
INFO - 2023-07-11 07:58:39 --> Loader Class Initialized
INFO - 2023-07-11 07:58:39 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:39 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:39 --> Controller Class Initialized
INFO - 2023-07-11 07:58:39 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:39 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 07:58:39 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:39 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:39 --> Total execution time: 0.1010
INFO - 2023-07-11 07:58:39 --> Config Class Initialized
INFO - 2023-07-11 07:58:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:39 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:39 --> URI Class Initialized
INFO - 2023-07-11 07:58:39 --> Router Class Initialized
INFO - 2023-07-11 07:58:39 --> Output Class Initialized
INFO - 2023-07-11 07:58:39 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:39 --> Input Class Initialized
INFO - 2023-07-11 07:58:39 --> Language Class Initialized
ERROR - 2023-07-11 07:58:39 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:58:39 --> Config Class Initialized
INFO - 2023-07-11 07:58:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:39 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:39 --> URI Class Initialized
INFO - 2023-07-11 07:58:39 --> Router Class Initialized
INFO - 2023-07-11 07:58:39 --> Output Class Initialized
INFO - 2023-07-11 07:58:39 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:39 --> Input Class Initialized
INFO - 2023-07-11 07:58:39 --> Language Class Initialized
ERROR - 2023-07-11 07:58:39 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 07:58:39 --> Config Class Initialized
INFO - 2023-07-11 07:58:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:39 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:39 --> URI Class Initialized
INFO - 2023-07-11 07:58:39 --> Router Class Initialized
INFO - 2023-07-11 07:58:39 --> Output Class Initialized
INFO - 2023-07-11 07:58:39 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:39 --> Input Class Initialized
INFO - 2023-07-11 07:58:39 --> Language Class Initialized
ERROR - 2023-07-11 07:58:39 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 07:58:40 --> Config Class Initialized
INFO - 2023-07-11 07:58:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:40 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:40 --> URI Class Initialized
INFO - 2023-07-11 07:58:40 --> Router Class Initialized
INFO - 2023-07-11 07:58:40 --> Output Class Initialized
INFO - 2023-07-11 07:58:40 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:40 --> Input Class Initialized
INFO - 2023-07-11 07:58:40 --> Language Class Initialized
ERROR - 2023-07-11 07:58:40 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:44 --> Controller Class Initialized
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:44 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:44 --> Total execution time: 0.0578
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
ERROR - 2023-07-11 07:58:44 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
INFO - 2023-07-11 07:58:44 --> Controller Class Initialized
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:58:44 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:44 --> Total execution time: 0.1100
INFO - 2023-07-11 07:58:44 --> Controller Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:44 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:58:44 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:44 --> Controller Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:58:44 --> Controller Class Initialized
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:58:44 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:44 --> Total execution time: 0.1827
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:58:44 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:44 --> Total execution time: 0.1436
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:44 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:44 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:44 --> Total execution time: 0.1543
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> Config Class Initialized
INFO - 2023-07-11 07:58:44 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:44 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
INFO - 2023-07-11 07:58:44 --> URI Class Initialized
INFO - 2023-07-11 07:58:44 --> Router Class Initialized
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:44 --> Output Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Security Class Initialized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
DEBUG - 2023-07-11 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:44 --> Input Class Initialized
INFO - 2023-07-11 07:58:44 --> Language Class Initialized
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> Loader Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:44 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:44 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1463
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1478
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1812
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1199
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.2708
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1550
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.3158
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1729
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1639
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.2980
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.1222
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
ERROR - 2023-07-11 07:58:45 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 07:58:45 --> Config Class Initialized
INFO - 2023-07-11 07:58:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:58:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:58:45 --> Utf8 Class Initialized
INFO - 2023-07-11 07:58:45 --> URI Class Initialized
INFO - 2023-07-11 07:58:45 --> Router Class Initialized
INFO - 2023-07-11 07:58:45 --> Output Class Initialized
INFO - 2023-07-11 07:58:45 --> Security Class Initialized
DEBUG - 2023-07-11 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:58:45 --> Input Class Initialized
INFO - 2023-07-11 07:58:45 --> Language Class Initialized
INFO - 2023-07-11 07:58:45 --> Loader Class Initialized
INFO - 2023-07-11 07:58:45 --> Helper loaded: url_helper
INFO - 2023-07-11 07:58:45 --> Database Driver Class Initialized
INFO - 2023-07-11 07:58:45 --> Controller Class Initialized
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 07:58:45 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 07:58:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:58:45 --> Final output sent to browser
DEBUG - 2023-07-11 07:58:45 --> Total execution time: 0.0871
INFO - 2023-07-11 07:59:01 --> Config Class Initialized
INFO - 2023-07-11 07:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:59:01 --> Utf8 Class Initialized
INFO - 2023-07-11 07:59:01 --> URI Class Initialized
INFO - 2023-07-11 07:59:01 --> Router Class Initialized
INFO - 2023-07-11 07:59:01 --> Output Class Initialized
INFO - 2023-07-11 07:59:01 --> Security Class Initialized
DEBUG - 2023-07-11 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:59:01 --> Input Class Initialized
INFO - 2023-07-11 07:59:01 --> Language Class Initialized
INFO - 2023-07-11 07:59:01 --> Loader Class Initialized
INFO - 2023-07-11 07:59:01 --> Helper loaded: url_helper
INFO - 2023-07-11 07:59:01 --> Database Driver Class Initialized
INFO - 2023-07-11 07:59:01 --> Controller Class Initialized
INFO - 2023-07-11 07:59:01 --> Config Class Initialized
INFO - 2023-07-11 07:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:59:01 --> Utf8 Class Initialized
INFO - 2023-07-11 07:59:01 --> URI Class Initialized
INFO - 2023-07-11 07:59:01 --> Router Class Initialized
INFO - 2023-07-11 07:59:01 --> Output Class Initialized
INFO - 2023-07-11 07:59:01 --> Security Class Initialized
DEBUG - 2023-07-11 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:59:01 --> Input Class Initialized
INFO - 2023-07-11 07:59:01 --> Language Class Initialized
INFO - 2023-07-11 07:59:01 --> Loader Class Initialized
INFO - 2023-07-11 07:59:01 --> Helper loaded: url_helper
INFO - 2023-07-11 07:59:01 --> Database Driver Class Initialized
INFO - 2023-07-11 07:59:01 --> Controller Class Initialized
INFO - 2023-07-11 07:59:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 07:59:01 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 07:59:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 07:59:01 --> Final output sent to browser
DEBUG - 2023-07-11 07:59:01 --> Total execution time: 0.0992
INFO - 2023-07-11 07:59:01 --> Config Class Initialized
INFO - 2023-07-11 07:59:01 --> Hooks Class Initialized
INFO - 2023-07-11 07:59:01 --> Config Class Initialized
INFO - 2023-07-11 07:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:59:01 --> Utf8 Class Initialized
DEBUG - 2023-07-11 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:59:01 --> URI Class Initialized
INFO - 2023-07-11 07:59:01 --> Utf8 Class Initialized
INFO - 2023-07-11 07:59:01 --> Router Class Initialized
INFO - 2023-07-11 07:59:01 --> URI Class Initialized
INFO - 2023-07-11 07:59:01 --> Output Class Initialized
INFO - 2023-07-11 07:59:01 --> Router Class Initialized
INFO - 2023-07-11 07:59:01 --> Security Class Initialized
INFO - 2023-07-11 07:59:01 --> Output Class Initialized
DEBUG - 2023-07-11 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:59:01 --> Input Class Initialized
INFO - 2023-07-11 07:59:01 --> Language Class Initialized
INFO - 2023-07-11 07:59:01 --> Security Class Initialized
ERROR - 2023-07-11 07:59:01 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:59:01 --> Input Class Initialized
INFO - 2023-07-11 07:59:01 --> Language Class Initialized
ERROR - 2023-07-11 07:59:01 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 07:59:01 --> Config Class Initialized
INFO - 2023-07-11 07:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:59:01 --> Utf8 Class Initialized
INFO - 2023-07-11 07:59:01 --> URI Class Initialized
INFO - 2023-07-11 07:59:01 --> Router Class Initialized
INFO - 2023-07-11 07:59:01 --> Output Class Initialized
INFO - 2023-07-11 07:59:01 --> Security Class Initialized
DEBUG - 2023-07-11 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:59:01 --> Input Class Initialized
INFO - 2023-07-11 07:59:01 --> Language Class Initialized
ERROR - 2023-07-11 07:59:01 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 07:59:01 --> Config Class Initialized
INFO - 2023-07-11 07:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 07:59:01 --> Utf8 Class Initialized
INFO - 2023-07-11 07:59:01 --> URI Class Initialized
INFO - 2023-07-11 07:59:01 --> Router Class Initialized
INFO - 2023-07-11 07:59:01 --> Output Class Initialized
INFO - 2023-07-11 07:59:01 --> Security Class Initialized
DEBUG - 2023-07-11 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 07:59:01 --> Input Class Initialized
INFO - 2023-07-11 07:59:01 --> Language Class Initialized
ERROR - 2023-07-11 07:59:01 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:02:14 --> Config Class Initialized
INFO - 2023-07-11 08:02:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:02:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:02:14 --> Utf8 Class Initialized
INFO - 2023-07-11 08:02:15 --> URI Class Initialized
INFO - 2023-07-11 08:02:15 --> Router Class Initialized
INFO - 2023-07-11 08:02:15 --> Output Class Initialized
INFO - 2023-07-11 08:02:15 --> Security Class Initialized
DEBUG - 2023-07-11 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:02:15 --> Input Class Initialized
INFO - 2023-07-11 08:02:15 --> Language Class Initialized
INFO - 2023-07-11 08:02:15 --> Loader Class Initialized
INFO - 2023-07-11 08:02:15 --> Helper loaded: url_helper
INFO - 2023-07-11 08:02:15 --> Database Driver Class Initialized
INFO - 2023-07-11 08:02:15 --> Controller Class Initialized
INFO - 2023-07-11 08:02:15 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:02:15 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:02:15 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:02:15 --> Final output sent to browser
DEBUG - 2023-07-11 08:02:15 --> Total execution time: 0.1291
INFO - 2023-07-11 08:02:15 --> Config Class Initialized
INFO - 2023-07-11 08:02:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:02:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:02:15 --> Utf8 Class Initialized
INFO - 2023-07-11 08:02:15 --> URI Class Initialized
INFO - 2023-07-11 08:02:15 --> Router Class Initialized
INFO - 2023-07-11 08:02:15 --> Config Class Initialized
INFO - 2023-07-11 08:02:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:02:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:02:15 --> Utf8 Class Initialized
INFO - 2023-07-11 08:02:15 --> URI Class Initialized
INFO - 2023-07-11 08:02:15 --> Output Class Initialized
INFO - 2023-07-11 08:02:15 --> Router Class Initialized
INFO - 2023-07-11 08:02:15 --> Security Class Initialized
INFO - 2023-07-11 08:02:15 --> Output Class Initialized
DEBUG - 2023-07-11 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:02:15 --> Input Class Initialized
INFO - 2023-07-11 08:02:15 --> Language Class Initialized
INFO - 2023-07-11 08:02:15 --> Security Class Initialized
ERROR - 2023-07-11 08:02:15 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:02:15 --> Input Class Initialized
INFO - 2023-07-11 08:02:15 --> Language Class Initialized
ERROR - 2023-07-11 08:02:15 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:02:15 --> Config Class Initialized
INFO - 2023-07-11 08:02:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:02:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:02:15 --> Utf8 Class Initialized
INFO - 2023-07-11 08:02:15 --> URI Class Initialized
INFO - 2023-07-11 08:02:15 --> Router Class Initialized
INFO - 2023-07-11 08:02:15 --> Output Class Initialized
INFO - 2023-07-11 08:02:15 --> Security Class Initialized
DEBUG - 2023-07-11 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:02:15 --> Input Class Initialized
INFO - 2023-07-11 08:02:15 --> Language Class Initialized
ERROR - 2023-07-11 08:02:15 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:02:15 --> Config Class Initialized
INFO - 2023-07-11 08:02:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:02:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:02:15 --> Utf8 Class Initialized
INFO - 2023-07-11 08:02:15 --> URI Class Initialized
INFO - 2023-07-11 08:02:15 --> Router Class Initialized
INFO - 2023-07-11 08:02:15 --> Output Class Initialized
INFO - 2023-07-11 08:02:15 --> Security Class Initialized
DEBUG - 2023-07-11 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:02:15 --> Input Class Initialized
INFO - 2023-07-11 08:02:15 --> Language Class Initialized
ERROR - 2023-07-11 08:02:15 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:04:01 --> Config Class Initialized
INFO - 2023-07-11 08:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:01 --> URI Class Initialized
INFO - 2023-07-11 08:04:01 --> Router Class Initialized
INFO - 2023-07-11 08:04:01 --> Output Class Initialized
INFO - 2023-07-11 08:04:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:01 --> Input Class Initialized
INFO - 2023-07-11 08:04:01 --> Language Class Initialized
INFO - 2023-07-11 08:04:01 --> Loader Class Initialized
INFO - 2023-07-11 08:04:01 --> Helper loaded: url_helper
INFO - 2023-07-11 08:04:01 --> Database Driver Class Initialized
INFO - 2023-07-11 08:04:01 --> Controller Class Initialized
INFO - 2023-07-11 08:04:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:04:01 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:04:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:04:01 --> Final output sent to browser
DEBUG - 2023-07-11 08:04:01 --> Total execution time: 0.0696
INFO - 2023-07-11 08:04:01 --> Config Class Initialized
INFO - 2023-07-11 08:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:01 --> URI Class Initialized
INFO - 2023-07-11 08:04:01 --> Router Class Initialized
INFO - 2023-07-11 08:04:01 --> Output Class Initialized
INFO - 2023-07-11 08:04:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:01 --> Input Class Initialized
INFO - 2023-07-11 08:04:01 --> Language Class Initialized
ERROR - 2023-07-11 08:04:01 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:04:01 --> Config Class Initialized
INFO - 2023-07-11 08:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:01 --> URI Class Initialized
INFO - 2023-07-11 08:04:01 --> Router Class Initialized
INFO - 2023-07-11 08:04:01 --> Config Class Initialized
INFO - 2023-07-11 08:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:01 --> Output Class Initialized
INFO - 2023-07-11 08:04:01 --> URI Class Initialized
INFO - 2023-07-11 08:04:01 --> Security Class Initialized
INFO - 2023-07-11 08:04:01 --> Router Class Initialized
DEBUG - 2023-07-11 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:01 --> Input Class Initialized
INFO - 2023-07-11 08:04:01 --> Output Class Initialized
INFO - 2023-07-11 08:04:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:01 --> Input Class Initialized
INFO - 2023-07-11 08:04:01 --> Language Class Initialized
INFO - 2023-07-11 08:04:01 --> Language Class Initialized
ERROR - 2023-07-11 08:04:01 --> 404 Page Not Found: Indexjs/index
ERROR - 2023-07-11 08:04:01 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:04:01 --> Config Class Initialized
INFO - 2023-07-11 08:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:01 --> URI Class Initialized
INFO - 2023-07-11 08:04:01 --> Router Class Initialized
INFO - 2023-07-11 08:04:01 --> Output Class Initialized
INFO - 2023-07-11 08:04:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:01 --> Input Class Initialized
INFO - 2023-07-11 08:04:01 --> Language Class Initialized
ERROR - 2023-07-11 08:04:01 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:04:07 --> Config Class Initialized
INFO - 2023-07-11 08:04:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:07 --> URI Class Initialized
INFO - 2023-07-11 08:04:07 --> Router Class Initialized
INFO - 2023-07-11 08:04:07 --> Output Class Initialized
INFO - 2023-07-11 08:04:07 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:07 --> Input Class Initialized
INFO - 2023-07-11 08:04:07 --> Language Class Initialized
INFO - 2023-07-11 08:04:07 --> Loader Class Initialized
INFO - 2023-07-11 08:04:07 --> Helper loaded: url_helper
INFO - 2023-07-11 08:04:07 --> Database Driver Class Initialized
INFO - 2023-07-11 08:04:07 --> Controller Class Initialized
INFO - 2023-07-11 08:04:07 --> Config Class Initialized
INFO - 2023-07-11 08:04:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:07 --> URI Class Initialized
INFO - 2023-07-11 08:04:07 --> Router Class Initialized
INFO - 2023-07-11 08:04:07 --> Output Class Initialized
INFO - 2023-07-11 08:04:07 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:07 --> Input Class Initialized
INFO - 2023-07-11 08:04:07 --> Language Class Initialized
INFO - 2023-07-11 08:04:08 --> Loader Class Initialized
INFO - 2023-07-11 08:04:08 --> Helper loaded: url_helper
INFO - 2023-07-11 08:04:08 --> Database Driver Class Initialized
INFO - 2023-07-11 08:04:08 --> Controller Class Initialized
INFO - 2023-07-11 08:04:08 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:04:08 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:04:08 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:04:08 --> Final output sent to browser
DEBUG - 2023-07-11 08:04:08 --> Total execution time: 0.0865
INFO - 2023-07-11 08:04:08 --> Config Class Initialized
INFO - 2023-07-11 08:04:08 --> Hooks Class Initialized
INFO - 2023-07-11 08:04:08 --> Config Class Initialized
INFO - 2023-07-11 08:04:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:08 --> URI Class Initialized
DEBUG - 2023-07-11 08:04:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:08 --> Router Class Initialized
INFO - 2023-07-11 08:04:08 --> URI Class Initialized
INFO - 2023-07-11 08:04:08 --> Output Class Initialized
INFO - 2023-07-11 08:04:08 --> Router Class Initialized
INFO - 2023-07-11 08:04:08 --> Security Class Initialized
INFO - 2023-07-11 08:04:08 --> Output Class Initialized
DEBUG - 2023-07-11 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:08 --> Security Class Initialized
INFO - 2023-07-11 08:04:08 --> Input Class Initialized
INFO - 2023-07-11 08:04:08 --> Language Class Initialized
ERROR - 2023-07-11 08:04:08 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:08 --> Input Class Initialized
INFO - 2023-07-11 08:04:08 --> Language Class Initialized
ERROR - 2023-07-11 08:04:08 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:04:08 --> Config Class Initialized
INFO - 2023-07-11 08:04:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:08 --> URI Class Initialized
INFO - 2023-07-11 08:04:08 --> Router Class Initialized
INFO - 2023-07-11 08:04:08 --> Output Class Initialized
INFO - 2023-07-11 08:04:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:08 --> Input Class Initialized
INFO - 2023-07-11 08:04:08 --> Language Class Initialized
ERROR - 2023-07-11 08:04:08 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:04:08 --> Config Class Initialized
INFO - 2023-07-11 08:04:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:04:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:04:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:04:08 --> URI Class Initialized
INFO - 2023-07-11 08:04:08 --> Router Class Initialized
INFO - 2023-07-11 08:04:08 --> Output Class Initialized
INFO - 2023-07-11 08:04:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:04:08 --> Input Class Initialized
INFO - 2023-07-11 08:04:08 --> Language Class Initialized
ERROR - 2023-07-11 08:04:08 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:06:01 --> Config Class Initialized
INFO - 2023-07-11 08:06:01 --> Hooks Class Initialized
INFO - 2023-07-11 08:06:01 --> Config Class Initialized
INFO - 2023-07-11 08:06:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:06:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:06:01 --> Utf8 Class Initialized
DEBUG - 2023-07-11 08:06:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:06:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:06:01 --> URI Class Initialized
INFO - 2023-07-11 08:06:01 --> Router Class Initialized
INFO - 2023-07-11 08:06:01 --> Output Class Initialized
INFO - 2023-07-11 08:06:01 --> URI Class Initialized
INFO - 2023-07-11 08:06:01 --> Security Class Initialized
INFO - 2023-07-11 08:06:01 --> Router Class Initialized
DEBUG - 2023-07-11 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:06:01 --> Input Class Initialized
INFO - 2023-07-11 08:06:01 --> Output Class Initialized
INFO - 2023-07-11 08:06:01 --> Language Class Initialized
INFO - 2023-07-11 08:06:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 08:06:01 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:06:01 --> Input Class Initialized
INFO - 2023-07-11 08:06:01 --> Language Class Initialized
ERROR - 2023-07-11 08:06:01 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:07:28 --> Config Class Initialized
INFO - 2023-07-11 08:07:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:07:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:07:28 --> Utf8 Class Initialized
INFO - 2023-07-11 08:07:28 --> URI Class Initialized
INFO - 2023-07-11 08:07:28 --> Router Class Initialized
INFO - 2023-07-11 08:07:28 --> Output Class Initialized
INFO - 2023-07-11 08:07:28 --> Security Class Initialized
DEBUG - 2023-07-11 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:07:28 --> Input Class Initialized
INFO - 2023-07-11 08:07:28 --> Language Class Initialized
INFO - 2023-07-11 08:07:28 --> Loader Class Initialized
INFO - 2023-07-11 08:07:28 --> Helper loaded: url_helper
INFO - 2023-07-11 08:07:28 --> Database Driver Class Initialized
INFO - 2023-07-11 08:07:28 --> Controller Class Initialized
INFO - 2023-07-11 08:07:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:07:28 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:07:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:07:28 --> Final output sent to browser
DEBUG - 2023-07-11 08:07:28 --> Total execution time: 0.0575
INFO - 2023-07-11 08:07:29 --> Config Class Initialized
INFO - 2023-07-11 08:07:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:07:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:07:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:07:29 --> URI Class Initialized
INFO - 2023-07-11 08:07:29 --> Router Class Initialized
INFO - 2023-07-11 08:07:29 --> Output Class Initialized
INFO - 2023-07-11 08:07:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:07:29 --> Input Class Initialized
INFO - 2023-07-11 08:07:29 --> Language Class Initialized
ERROR - 2023-07-11 08:07:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:07:29 --> Config Class Initialized
INFO - 2023-07-11 08:07:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:07:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:07:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:07:29 --> URI Class Initialized
INFO - 2023-07-11 08:07:29 --> Router Class Initialized
INFO - 2023-07-11 08:07:29 --> Output Class Initialized
INFO - 2023-07-11 08:07:29 --> Security Class Initialized
INFO - 2023-07-11 08:07:29 --> Config Class Initialized
INFO - 2023-07-11 08:07:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:07:29 --> Input Class Initialized
DEBUG - 2023-07-11 08:07:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:07:29 --> Language Class Initialized
INFO - 2023-07-11 08:07:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:07:29 --> URI Class Initialized
ERROR - 2023-07-11 08:07:29 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:07:29 --> Router Class Initialized
INFO - 2023-07-11 08:07:29 --> Output Class Initialized
INFO - 2023-07-11 08:07:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:07:29 --> Input Class Initialized
INFO - 2023-07-11 08:07:29 --> Language Class Initialized
ERROR - 2023-07-11 08:07:29 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:07:29 --> Config Class Initialized
INFO - 2023-07-11 08:07:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:07:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:07:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:07:29 --> URI Class Initialized
INFO - 2023-07-11 08:07:29 --> Router Class Initialized
INFO - 2023-07-11 08:07:30 --> Output Class Initialized
INFO - 2023-07-11 08:07:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:07:30 --> Input Class Initialized
INFO - 2023-07-11 08:07:30 --> Language Class Initialized
ERROR - 2023-07-11 08:07:30 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:07:34 --> Config Class Initialized
INFO - 2023-07-11 08:07:34 --> Config Class Initialized
INFO - 2023-07-11 08:07:34 --> Hooks Class Initialized
INFO - 2023-07-11 08:07:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:07:34 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 08:07:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:07:34 --> Utf8 Class Initialized
INFO - 2023-07-11 08:07:34 --> Utf8 Class Initialized
INFO - 2023-07-11 08:07:34 --> URI Class Initialized
INFO - 2023-07-11 08:07:34 --> URI Class Initialized
INFO - 2023-07-11 08:07:34 --> Router Class Initialized
INFO - 2023-07-11 08:07:34 --> Router Class Initialized
INFO - 2023-07-11 08:07:34 --> Output Class Initialized
INFO - 2023-07-11 08:07:34 --> Output Class Initialized
INFO - 2023-07-11 08:07:34 --> Security Class Initialized
INFO - 2023-07-11 08:07:34 --> Security Class Initialized
DEBUG - 2023-07-11 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:07:34 --> Input Class Initialized
DEBUG - 2023-07-11 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:07:34 --> Input Class Initialized
INFO - 2023-07-11 08:07:34 --> Language Class Initialized
INFO - 2023-07-11 08:07:34 --> Language Class Initialized
ERROR - 2023-07-11 08:07:34 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 08:07:34 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:15:36 --> Config Class Initialized
INFO - 2023-07-11 08:15:36 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:36 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:36 --> URI Class Initialized
INFO - 2023-07-11 08:15:36 --> Router Class Initialized
INFO - 2023-07-11 08:15:36 --> Output Class Initialized
INFO - 2023-07-11 08:15:36 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:36 --> Input Class Initialized
INFO - 2023-07-11 08:15:36 --> Language Class Initialized
INFO - 2023-07-11 08:15:36 --> Loader Class Initialized
INFO - 2023-07-11 08:15:36 --> Helper loaded: url_helper
INFO - 2023-07-11 08:15:36 --> Database Driver Class Initialized
INFO - 2023-07-11 08:15:36 --> Controller Class Initialized
INFO - 2023-07-11 08:15:36 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:15:36 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:15:36 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:15:36 --> Final output sent to browser
DEBUG - 2023-07-11 08:15:36 --> Total execution time: 0.1708
INFO - 2023-07-11 08:15:36 --> Config Class Initialized
INFO - 2023-07-11 08:15:36 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:36 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:36 --> URI Class Initialized
INFO - 2023-07-11 08:15:36 --> Router Class Initialized
INFO - 2023-07-11 08:15:36 --> Output Class Initialized
INFO - 2023-07-11 08:15:36 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:36 --> Input Class Initialized
INFO - 2023-07-11 08:15:36 --> Language Class Initialized
ERROR - 2023-07-11 08:15:36 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:15:36 --> Config Class Initialized
INFO - 2023-07-11 08:15:36 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:36 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:36 --> URI Class Initialized
INFO - 2023-07-11 08:15:36 --> Router Class Initialized
INFO - 2023-07-11 08:15:36 --> Output Class Initialized
INFO - 2023-07-11 08:15:36 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:36 --> Input Class Initialized
INFO - 2023-07-11 08:15:36 --> Language Class Initialized
INFO - 2023-07-11 08:15:36 --> Config Class Initialized
INFO - 2023-07-11 08:15:36 --> Hooks Class Initialized
ERROR - 2023-07-11 08:15:36 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 08:15:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:36 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:36 --> URI Class Initialized
INFO - 2023-07-11 08:15:36 --> Router Class Initialized
INFO - 2023-07-11 08:15:36 --> Output Class Initialized
INFO - 2023-07-11 08:15:36 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:36 --> Input Class Initialized
INFO - 2023-07-11 08:15:36 --> Language Class Initialized
ERROR - 2023-07-11 08:15:36 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:15:39 --> Config Class Initialized
INFO - 2023-07-11 08:15:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:39 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:39 --> URI Class Initialized
INFO - 2023-07-11 08:15:39 --> Router Class Initialized
INFO - 2023-07-11 08:15:39 --> Output Class Initialized
INFO - 2023-07-11 08:15:39 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:39 --> Input Class Initialized
INFO - 2023-07-11 08:15:39 --> Language Class Initialized
ERROR - 2023-07-11 08:15:39 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:15:45 --> Config Class Initialized
INFO - 2023-07-11 08:15:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:45 --> URI Class Initialized
INFO - 2023-07-11 08:15:45 --> Router Class Initialized
INFO - 2023-07-11 08:15:45 --> Output Class Initialized
INFO - 2023-07-11 08:15:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:45 --> Input Class Initialized
INFO - 2023-07-11 08:15:45 --> Language Class Initialized
INFO - 2023-07-11 08:15:45 --> Loader Class Initialized
INFO - 2023-07-11 08:15:45 --> Helper loaded: url_helper
INFO - 2023-07-11 08:15:45 --> Database Driver Class Initialized
INFO - 2023-07-11 08:15:45 --> Controller Class Initialized
INFO - 2023-07-11 08:15:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:15:45 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:15:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:15:45 --> Final output sent to browser
DEBUG - 2023-07-11 08:15:45 --> Total execution time: 0.0863
INFO - 2023-07-11 08:15:45 --> Config Class Initialized
INFO - 2023-07-11 08:15:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:45 --> URI Class Initialized
INFO - 2023-07-11 08:15:45 --> Router Class Initialized
INFO - 2023-07-11 08:15:45 --> Output Class Initialized
INFO - 2023-07-11 08:15:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:45 --> Input Class Initialized
INFO - 2023-07-11 08:15:45 --> Language Class Initialized
ERROR - 2023-07-11 08:15:45 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:15:45 --> Config Class Initialized
INFO - 2023-07-11 08:15:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:45 --> URI Class Initialized
INFO - 2023-07-11 08:15:45 --> Router Class Initialized
INFO - 2023-07-11 08:15:45 --> Output Class Initialized
INFO - 2023-07-11 08:15:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:45 --> Input Class Initialized
INFO - 2023-07-11 08:15:45 --> Language Class Initialized
ERROR - 2023-07-11 08:15:45 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:15:45 --> Config Class Initialized
INFO - 2023-07-11 08:15:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:45 --> URI Class Initialized
INFO - 2023-07-11 08:15:45 --> Router Class Initialized
INFO - 2023-07-11 08:15:45 --> Output Class Initialized
INFO - 2023-07-11 08:15:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:45 --> Input Class Initialized
INFO - 2023-07-11 08:15:45 --> Language Class Initialized
ERROR - 2023-07-11 08:15:45 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:15:45 --> Config Class Initialized
INFO - 2023-07-11 08:15:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:15:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:15:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:15:45 --> URI Class Initialized
INFO - 2023-07-11 08:15:45 --> Router Class Initialized
INFO - 2023-07-11 08:15:45 --> Output Class Initialized
INFO - 2023-07-11 08:15:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:15:45 --> Input Class Initialized
INFO - 2023-07-11 08:15:45 --> Language Class Initialized
ERROR - 2023-07-11 08:15:45 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:16:05 --> Config Class Initialized
INFO - 2023-07-11 08:16:05 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:05 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:05 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:05 --> URI Class Initialized
INFO - 2023-07-11 08:16:05 --> Router Class Initialized
INFO - 2023-07-11 08:16:05 --> Output Class Initialized
INFO - 2023-07-11 08:16:05 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:05 --> Input Class Initialized
INFO - 2023-07-11 08:16:05 --> Language Class Initialized
INFO - 2023-07-11 08:16:05 --> Loader Class Initialized
INFO - 2023-07-11 08:16:05 --> Helper loaded: url_helper
INFO - 2023-07-11 08:16:05 --> Database Driver Class Initialized
INFO - 2023-07-11 08:16:05 --> Controller Class Initialized
INFO - 2023-07-11 08:16:05 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:16:05 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:16:05 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:16:05 --> Final output sent to browser
DEBUG - 2023-07-11 08:16:05 --> Total execution time: 0.0876
INFO - 2023-07-11 08:16:05 --> Config Class Initialized
INFO - 2023-07-11 08:16:05 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:05 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:05 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:05 --> URI Class Initialized
INFO - 2023-07-11 08:16:05 --> Router Class Initialized
INFO - 2023-07-11 08:16:05 --> Output Class Initialized
INFO - 2023-07-11 08:16:05 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:05 --> Input Class Initialized
INFO - 2023-07-11 08:16:05 --> Language Class Initialized
ERROR - 2023-07-11 08:16:05 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:16:05 --> Config Class Initialized
INFO - 2023-07-11 08:16:05 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:05 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:05 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:05 --> URI Class Initialized
INFO - 2023-07-11 08:16:05 --> Router Class Initialized
INFO - 2023-07-11 08:16:05 --> Output Class Initialized
INFO - 2023-07-11 08:16:05 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:05 --> Input Class Initialized
INFO - 2023-07-11 08:16:05 --> Language Class Initialized
ERROR - 2023-07-11 08:16:05 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:16:05 --> Config Class Initialized
INFO - 2023-07-11 08:16:05 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:05 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:05 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:05 --> URI Class Initialized
INFO - 2023-07-11 08:16:05 --> Router Class Initialized
INFO - 2023-07-11 08:16:05 --> Output Class Initialized
INFO - 2023-07-11 08:16:05 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:05 --> Input Class Initialized
INFO - 2023-07-11 08:16:05 --> Language Class Initialized
ERROR - 2023-07-11 08:16:05 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:16:30 --> Config Class Initialized
INFO - 2023-07-11 08:16:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:30 --> URI Class Initialized
INFO - 2023-07-11 08:16:30 --> Router Class Initialized
INFO - 2023-07-11 08:16:30 --> Output Class Initialized
INFO - 2023-07-11 08:16:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:30 --> Input Class Initialized
INFO - 2023-07-11 08:16:30 --> Language Class Initialized
INFO - 2023-07-11 08:16:30 --> Loader Class Initialized
INFO - 2023-07-11 08:16:30 --> Helper loaded: url_helper
INFO - 2023-07-11 08:16:30 --> Database Driver Class Initialized
INFO - 2023-07-11 08:16:30 --> Controller Class Initialized
INFO - 2023-07-11 08:16:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:16:30 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:16:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:16:30 --> Final output sent to browser
DEBUG - 2023-07-11 08:16:30 --> Total execution time: 0.0886
INFO - 2023-07-11 08:16:30 --> Config Class Initialized
INFO - 2023-07-11 08:16:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:30 --> URI Class Initialized
INFO - 2023-07-11 08:16:30 --> Router Class Initialized
INFO - 2023-07-11 08:16:30 --> Output Class Initialized
INFO - 2023-07-11 08:16:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:30 --> Input Class Initialized
INFO - 2023-07-11 08:16:30 --> Language Class Initialized
ERROR - 2023-07-11 08:16:30 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:16:30 --> Config Class Initialized
INFO - 2023-07-11 08:16:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:30 --> URI Class Initialized
INFO - 2023-07-11 08:16:30 --> Router Class Initialized
INFO - 2023-07-11 08:16:30 --> Output Class Initialized
INFO - 2023-07-11 08:16:31 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:31 --> Input Class Initialized
INFO - 2023-07-11 08:16:31 --> Language Class Initialized
ERROR - 2023-07-11 08:16:31 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:16:31 --> Config Class Initialized
INFO - 2023-07-11 08:16:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:31 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:31 --> URI Class Initialized
INFO - 2023-07-11 08:16:31 --> Router Class Initialized
INFO - 2023-07-11 08:16:31 --> Output Class Initialized
INFO - 2023-07-11 08:16:31 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:31 --> Input Class Initialized
INFO - 2023-07-11 08:16:31 --> Language Class Initialized
ERROR - 2023-07-11 08:16:31 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:16:51 --> Config Class Initialized
INFO - 2023-07-11 08:16:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:51 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:51 --> URI Class Initialized
INFO - 2023-07-11 08:16:51 --> Router Class Initialized
INFO - 2023-07-11 08:16:51 --> Output Class Initialized
INFO - 2023-07-11 08:16:51 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:51 --> Input Class Initialized
INFO - 2023-07-11 08:16:51 --> Language Class Initialized
INFO - 2023-07-11 08:16:51 --> Loader Class Initialized
INFO - 2023-07-11 08:16:51 --> Helper loaded: url_helper
INFO - 2023-07-11 08:16:51 --> Database Driver Class Initialized
INFO - 2023-07-11 08:16:51 --> Controller Class Initialized
INFO - 2023-07-11 08:16:51 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:16:51 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:16:51 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:16:51 --> Final output sent to browser
DEBUG - 2023-07-11 08:16:51 --> Total execution time: 0.0831
INFO - 2023-07-11 08:16:51 --> Config Class Initialized
INFO - 2023-07-11 08:16:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:51 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:51 --> URI Class Initialized
INFO - 2023-07-11 08:16:51 --> Router Class Initialized
INFO - 2023-07-11 08:16:51 --> Output Class Initialized
INFO - 2023-07-11 08:16:51 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:51 --> Input Class Initialized
INFO - 2023-07-11 08:16:51 --> Language Class Initialized
ERROR - 2023-07-11 08:16:51 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:16:51 --> Config Class Initialized
INFO - 2023-07-11 08:16:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:51 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:51 --> URI Class Initialized
INFO - 2023-07-11 08:16:51 --> Router Class Initialized
INFO - 2023-07-11 08:16:51 --> Output Class Initialized
INFO - 2023-07-11 08:16:51 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:51 --> Input Class Initialized
INFO - 2023-07-11 08:16:51 --> Language Class Initialized
ERROR - 2023-07-11 08:16:51 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:16:51 --> Config Class Initialized
INFO - 2023-07-11 08:16:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:16:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:16:51 --> Utf8 Class Initialized
INFO - 2023-07-11 08:16:51 --> URI Class Initialized
INFO - 2023-07-11 08:16:51 --> Router Class Initialized
INFO - 2023-07-11 08:16:51 --> Output Class Initialized
INFO - 2023-07-11 08:16:51 --> Security Class Initialized
DEBUG - 2023-07-11 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:16:51 --> Input Class Initialized
INFO - 2023-07-11 08:16:51 --> Language Class Initialized
ERROR - 2023-07-11 08:16:51 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:17:07 --> Config Class Initialized
INFO - 2023-07-11 08:17:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:07 --> URI Class Initialized
INFO - 2023-07-11 08:17:07 --> Router Class Initialized
INFO - 2023-07-11 08:17:07 --> Output Class Initialized
INFO - 2023-07-11 08:17:07 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:07 --> Input Class Initialized
INFO - 2023-07-11 08:17:07 --> Language Class Initialized
INFO - 2023-07-11 08:17:07 --> Loader Class Initialized
INFO - 2023-07-11 08:17:07 --> Helper loaded: url_helper
INFO - 2023-07-11 08:17:07 --> Database Driver Class Initialized
INFO - 2023-07-11 08:17:07 --> Controller Class Initialized
INFO - 2023-07-11 08:17:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:17:07 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:17:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:17:07 --> Final output sent to browser
DEBUG - 2023-07-11 08:17:07 --> Total execution time: 0.0603
INFO - 2023-07-11 08:17:08 --> Config Class Initialized
INFO - 2023-07-11 08:17:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:08 --> URI Class Initialized
INFO - 2023-07-11 08:17:08 --> Router Class Initialized
INFO - 2023-07-11 08:17:08 --> Output Class Initialized
INFO - 2023-07-11 08:17:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:08 --> Input Class Initialized
INFO - 2023-07-11 08:17:08 --> Language Class Initialized
ERROR - 2023-07-11 08:17:08 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:17:08 --> Config Class Initialized
INFO - 2023-07-11 08:17:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:08 --> URI Class Initialized
INFO - 2023-07-11 08:17:08 --> Router Class Initialized
INFO - 2023-07-11 08:17:08 --> Output Class Initialized
INFO - 2023-07-11 08:17:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:08 --> Input Class Initialized
INFO - 2023-07-11 08:17:08 --> Language Class Initialized
ERROR - 2023-07-11 08:17:08 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:17:08 --> Config Class Initialized
INFO - 2023-07-11 08:17:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:08 --> URI Class Initialized
INFO - 2023-07-11 08:17:08 --> Router Class Initialized
INFO - 2023-07-11 08:17:08 --> Output Class Initialized
INFO - 2023-07-11 08:17:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:08 --> Input Class Initialized
INFO - 2023-07-11 08:17:08 --> Language Class Initialized
ERROR - 2023-07-11 08:17:08 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:17:08 --> Config Class Initialized
INFO - 2023-07-11 08:17:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:08 --> URI Class Initialized
INFO - 2023-07-11 08:17:08 --> Router Class Initialized
INFO - 2023-07-11 08:17:08 --> Output Class Initialized
INFO - 2023-07-11 08:17:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:08 --> Input Class Initialized
INFO - 2023-07-11 08:17:08 --> Language Class Initialized
ERROR - 2023-07-11 08:17:08 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:17:12 --> Config Class Initialized
INFO - 2023-07-11 08:17:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:12 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:12 --> URI Class Initialized
INFO - 2023-07-11 08:17:12 --> Router Class Initialized
INFO - 2023-07-11 08:17:12 --> Output Class Initialized
INFO - 2023-07-11 08:17:12 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:12 --> Input Class Initialized
INFO - 2023-07-11 08:17:12 --> Language Class Initialized
INFO - 2023-07-11 08:17:12 --> Loader Class Initialized
INFO - 2023-07-11 08:17:12 --> Helper loaded: url_helper
INFO - 2023-07-11 08:17:12 --> Database Driver Class Initialized
INFO - 2023-07-11 08:17:12 --> Controller Class Initialized
INFO - 2023-07-11 08:17:12 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:17:12 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:17:12 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:17:12 --> Final output sent to browser
DEBUG - 2023-07-11 08:17:12 --> Total execution time: 0.0608
INFO - 2023-07-11 08:17:12 --> Config Class Initialized
INFO - 2023-07-11 08:17:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:12 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:12 --> URI Class Initialized
INFO - 2023-07-11 08:17:12 --> Router Class Initialized
INFO - 2023-07-11 08:17:12 --> Output Class Initialized
INFO - 2023-07-11 08:17:12 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:12 --> Input Class Initialized
INFO - 2023-07-11 08:17:12 --> Language Class Initialized
ERROR - 2023-07-11 08:17:12 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:17:13 --> Config Class Initialized
INFO - 2023-07-11 08:17:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:13 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:13 --> URI Class Initialized
INFO - 2023-07-11 08:17:13 --> Router Class Initialized
INFO - 2023-07-11 08:17:13 --> Output Class Initialized
INFO - 2023-07-11 08:17:13 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:13 --> Input Class Initialized
INFO - 2023-07-11 08:17:13 --> Language Class Initialized
ERROR - 2023-07-11 08:17:13 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:17:13 --> Config Class Initialized
INFO - 2023-07-11 08:17:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:17:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:17:13 --> Utf8 Class Initialized
INFO - 2023-07-11 08:17:13 --> URI Class Initialized
INFO - 2023-07-11 08:17:13 --> Router Class Initialized
INFO - 2023-07-11 08:17:13 --> Output Class Initialized
INFO - 2023-07-11 08:17:13 --> Security Class Initialized
DEBUG - 2023-07-11 08:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:17:13 --> Input Class Initialized
INFO - 2023-07-11 08:17:13 --> Language Class Initialized
ERROR - 2023-07-11 08:17:13 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:18:54 --> Config Class Initialized
INFO - 2023-07-11 08:18:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:18:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:18:55 --> Utf8 Class Initialized
INFO - 2023-07-11 08:18:55 --> URI Class Initialized
INFO - 2023-07-11 08:18:55 --> Router Class Initialized
INFO - 2023-07-11 08:18:55 --> Output Class Initialized
INFO - 2023-07-11 08:18:55 --> Security Class Initialized
DEBUG - 2023-07-11 08:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:18:55 --> Input Class Initialized
INFO - 2023-07-11 08:18:56 --> Language Class Initialized
INFO - 2023-07-11 08:18:56 --> Loader Class Initialized
INFO - 2023-07-11 08:18:56 --> Helper loaded: url_helper
INFO - 2023-07-11 08:18:56 --> Database Driver Class Initialized
INFO - 2023-07-11 08:18:56 --> Controller Class Initialized
INFO - 2023-07-11 08:18:56 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:18:56 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:18:56 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:18:56 --> Final output sent to browser
DEBUG - 2023-07-11 08:18:56 --> Total execution time: 1.9670
INFO - 2023-07-11 08:18:57 --> Config Class Initialized
INFO - 2023-07-11 08:18:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:18:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:18:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:18:57 --> URI Class Initialized
INFO - 2023-07-11 08:18:57 --> Router Class Initialized
INFO - 2023-07-11 08:18:57 --> Output Class Initialized
INFO - 2023-07-11 08:18:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:18:57 --> Input Class Initialized
INFO - 2023-07-11 08:18:57 --> Language Class Initialized
ERROR - 2023-07-11 08:18:57 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:18:57 --> Config Class Initialized
INFO - 2023-07-11 08:18:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:18:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:18:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:18:57 --> URI Class Initialized
INFO - 2023-07-11 08:18:57 --> Router Class Initialized
INFO - 2023-07-11 08:18:57 --> Output Class Initialized
INFO - 2023-07-11 08:18:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:18:57 --> Input Class Initialized
INFO - 2023-07-11 08:18:57 --> Language Class Initialized
ERROR - 2023-07-11 08:18:57 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:18:57 --> Config Class Initialized
INFO - 2023-07-11 08:18:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:18:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:18:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:18:57 --> URI Class Initialized
INFO - 2023-07-11 08:18:57 --> Router Class Initialized
INFO - 2023-07-11 08:18:57 --> Output Class Initialized
INFO - 2023-07-11 08:18:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:18:57 --> Input Class Initialized
INFO - 2023-07-11 08:18:57 --> Language Class Initialized
ERROR - 2023-07-11 08:18:57 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:18:57 --> Config Class Initialized
INFO - 2023-07-11 08:18:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:18:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:18:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:18:57 --> URI Class Initialized
INFO - 2023-07-11 08:18:57 --> Router Class Initialized
INFO - 2023-07-11 08:18:57 --> Output Class Initialized
INFO - 2023-07-11 08:18:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:18:57 --> Input Class Initialized
INFO - 2023-07-11 08:18:57 --> Language Class Initialized
ERROR - 2023-07-11 08:18:57 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:19:03 --> Config Class Initialized
INFO - 2023-07-11 08:19:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:19:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:19:03 --> Utf8 Class Initialized
INFO - 2023-07-11 08:19:03 --> URI Class Initialized
INFO - 2023-07-11 08:19:03 --> Router Class Initialized
INFO - 2023-07-11 08:19:03 --> Output Class Initialized
INFO - 2023-07-11 08:19:03 --> Security Class Initialized
DEBUG - 2023-07-11 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:19:03 --> Input Class Initialized
INFO - 2023-07-11 08:19:03 --> Language Class Initialized
INFO - 2023-07-11 08:19:03 --> Loader Class Initialized
INFO - 2023-07-11 08:19:03 --> Helper loaded: url_helper
INFO - 2023-07-11 08:19:03 --> Database Driver Class Initialized
INFO - 2023-07-11 08:19:03 --> Controller Class Initialized
INFO - 2023-07-11 08:19:03 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:19:03 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:19:03 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:19:03 --> Final output sent to browser
DEBUG - 2023-07-11 08:19:03 --> Total execution time: 0.0835
INFO - 2023-07-11 08:19:03 --> Config Class Initialized
INFO - 2023-07-11 08:19:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:19:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:19:03 --> Utf8 Class Initialized
INFO - 2023-07-11 08:19:03 --> URI Class Initialized
INFO - 2023-07-11 08:19:03 --> Router Class Initialized
INFO - 2023-07-11 08:19:03 --> Output Class Initialized
INFO - 2023-07-11 08:19:03 --> Security Class Initialized
DEBUG - 2023-07-11 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:19:03 --> Input Class Initialized
INFO - 2023-07-11 08:19:03 --> Language Class Initialized
ERROR - 2023-07-11 08:19:03 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:19:03 --> Config Class Initialized
INFO - 2023-07-11 08:19:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:19:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:19:03 --> Utf8 Class Initialized
INFO - 2023-07-11 08:19:03 --> URI Class Initialized
INFO - 2023-07-11 08:19:03 --> Router Class Initialized
INFO - 2023-07-11 08:19:04 --> Output Class Initialized
INFO - 2023-07-11 08:19:04 --> Security Class Initialized
DEBUG - 2023-07-11 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:19:04 --> Input Class Initialized
INFO - 2023-07-11 08:19:04 --> Language Class Initialized
ERROR - 2023-07-11 08:19:04 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:19:04 --> Config Class Initialized
INFO - 2023-07-11 08:19:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:19:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:19:04 --> Utf8 Class Initialized
INFO - 2023-07-11 08:19:04 --> URI Class Initialized
INFO - 2023-07-11 08:19:04 --> Router Class Initialized
INFO - 2023-07-11 08:19:04 --> Output Class Initialized
INFO - 2023-07-11 08:19:04 --> Security Class Initialized
DEBUG - 2023-07-11 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:19:04 --> Input Class Initialized
INFO - 2023-07-11 08:19:04 --> Language Class Initialized
ERROR - 2023-07-11 08:19:04 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:19:04 --> Config Class Initialized
INFO - 2023-07-11 08:19:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:19:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:19:04 --> Utf8 Class Initialized
INFO - 2023-07-11 08:19:04 --> URI Class Initialized
INFO - 2023-07-11 08:19:04 --> Router Class Initialized
INFO - 2023-07-11 08:19:04 --> Output Class Initialized
INFO - 2023-07-11 08:19:04 --> Security Class Initialized
DEBUG - 2023-07-11 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:19:04 --> Input Class Initialized
INFO - 2023-07-11 08:19:04 --> Language Class Initialized
ERROR - 2023-07-11 08:19:04 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:21:07 --> Config Class Initialized
INFO - 2023-07-11 08:21:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:07 --> URI Class Initialized
INFO - 2023-07-11 08:21:07 --> Router Class Initialized
INFO - 2023-07-11 08:21:07 --> Output Class Initialized
INFO - 2023-07-11 08:21:07 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:07 --> Input Class Initialized
INFO - 2023-07-11 08:21:07 --> Language Class Initialized
INFO - 2023-07-11 08:21:07 --> Loader Class Initialized
INFO - 2023-07-11 08:21:07 --> Helper loaded: url_helper
INFO - 2023-07-11 08:21:07 --> Database Driver Class Initialized
INFO - 2023-07-11 08:21:07 --> Controller Class Initialized
INFO - 2023-07-11 08:21:08 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:21:08 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:21:08 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:21:08 --> Final output sent to browser
DEBUG - 2023-07-11 08:21:08 --> Total execution time: 0.0879
INFO - 2023-07-11 08:21:08 --> Config Class Initialized
INFO - 2023-07-11 08:21:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:08 --> URI Class Initialized
INFO - 2023-07-11 08:21:08 --> Router Class Initialized
INFO - 2023-07-11 08:21:08 --> Output Class Initialized
INFO - 2023-07-11 08:21:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:08 --> Input Class Initialized
INFO - 2023-07-11 08:21:08 --> Language Class Initialized
ERROR - 2023-07-11 08:21:08 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:08 --> Config Class Initialized
INFO - 2023-07-11 08:21:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:08 --> URI Class Initialized
INFO - 2023-07-11 08:21:08 --> Router Class Initialized
INFO - 2023-07-11 08:21:08 --> Output Class Initialized
INFO - 2023-07-11 08:21:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:08 --> Input Class Initialized
INFO - 2023-07-11 08:21:08 --> Language Class Initialized
ERROR - 2023-07-11 08:21:08 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:08 --> Config Class Initialized
INFO - 2023-07-11 08:21:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:08 --> URI Class Initialized
INFO - 2023-07-11 08:21:08 --> Router Class Initialized
INFO - 2023-07-11 08:21:08 --> Output Class Initialized
INFO - 2023-07-11 08:21:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:08 --> Input Class Initialized
INFO - 2023-07-11 08:21:08 --> Language Class Initialized
ERROR - 2023-07-11 08:21:08 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:08 --> Config Class Initialized
INFO - 2023-07-11 08:21:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:08 --> URI Class Initialized
INFO - 2023-07-11 08:21:08 --> Router Class Initialized
INFO - 2023-07-11 08:21:08 --> Output Class Initialized
INFO - 2023-07-11 08:21:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:08 --> Input Class Initialized
INFO - 2023-07-11 08:21:08 --> Language Class Initialized
ERROR - 2023-07-11 08:21:08 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:21:22 --> Config Class Initialized
INFO - 2023-07-11 08:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:22 --> URI Class Initialized
INFO - 2023-07-11 08:21:22 --> Router Class Initialized
INFO - 2023-07-11 08:21:22 --> Output Class Initialized
INFO - 2023-07-11 08:21:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:22 --> Input Class Initialized
INFO - 2023-07-11 08:21:22 --> Language Class Initialized
INFO - 2023-07-11 08:21:22 --> Loader Class Initialized
INFO - 2023-07-11 08:21:22 --> Helper loaded: url_helper
INFO - 2023-07-11 08:21:22 --> Database Driver Class Initialized
INFO - 2023-07-11 08:21:22 --> Controller Class Initialized
INFO - 2023-07-11 08:21:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:21:22 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:21:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:21:22 --> Final output sent to browser
DEBUG - 2023-07-11 08:21:22 --> Total execution time: 0.0990
INFO - 2023-07-11 08:21:22 --> Config Class Initialized
INFO - 2023-07-11 08:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:22 --> URI Class Initialized
INFO - 2023-07-11 08:21:22 --> Router Class Initialized
INFO - 2023-07-11 08:21:22 --> Output Class Initialized
INFO - 2023-07-11 08:21:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:22 --> Input Class Initialized
INFO - 2023-07-11 08:21:22 --> Language Class Initialized
ERROR - 2023-07-11 08:21:22 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:22 --> Config Class Initialized
INFO - 2023-07-11 08:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:22 --> URI Class Initialized
INFO - 2023-07-11 08:21:22 --> Router Class Initialized
INFO - 2023-07-11 08:21:22 --> Output Class Initialized
INFO - 2023-07-11 08:21:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:22 --> Input Class Initialized
INFO - 2023-07-11 08:21:22 --> Language Class Initialized
ERROR - 2023-07-11 08:21:22 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:22 --> Config Class Initialized
INFO - 2023-07-11 08:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:22 --> URI Class Initialized
INFO - 2023-07-11 08:21:22 --> Router Class Initialized
INFO - 2023-07-11 08:21:22 --> Output Class Initialized
INFO - 2023-07-11 08:21:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:22 --> Input Class Initialized
INFO - 2023-07-11 08:21:22 --> Language Class Initialized
ERROR - 2023-07-11 08:21:22 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:21:28 --> Config Class Initialized
INFO - 2023-07-11 08:21:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:28 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:28 --> URI Class Initialized
INFO - 2023-07-11 08:21:28 --> Router Class Initialized
INFO - 2023-07-11 08:21:28 --> Output Class Initialized
INFO - 2023-07-11 08:21:28 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:28 --> Input Class Initialized
INFO - 2023-07-11 08:21:28 --> Language Class Initialized
INFO - 2023-07-11 08:21:28 --> Loader Class Initialized
INFO - 2023-07-11 08:21:28 --> Helper loaded: url_helper
INFO - 2023-07-11 08:21:28 --> Database Driver Class Initialized
INFO - 2023-07-11 08:21:28 --> Controller Class Initialized
INFO - 2023-07-11 08:21:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:21:28 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:21:28 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:21:28 --> Final output sent to browser
DEBUG - 2023-07-11 08:21:28 --> Total execution time: 0.0590
INFO - 2023-07-11 08:21:28 --> Config Class Initialized
INFO - 2023-07-11 08:21:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:28 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:28 --> URI Class Initialized
INFO - 2023-07-11 08:21:28 --> Router Class Initialized
INFO - 2023-07-11 08:21:29 --> Output Class Initialized
INFO - 2023-07-11 08:21:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:29 --> Input Class Initialized
INFO - 2023-07-11 08:21:29 --> Language Class Initialized
ERROR - 2023-07-11 08:21:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:29 --> Config Class Initialized
INFO - 2023-07-11 08:21:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:29 --> URI Class Initialized
INFO - 2023-07-11 08:21:29 --> Router Class Initialized
INFO - 2023-07-11 08:21:29 --> Output Class Initialized
INFO - 2023-07-11 08:21:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:29 --> Input Class Initialized
INFO - 2023-07-11 08:21:29 --> Language Class Initialized
ERROR - 2023-07-11 08:21:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:29 --> Config Class Initialized
INFO - 2023-07-11 08:21:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:29 --> URI Class Initialized
INFO - 2023-07-11 08:21:29 --> Router Class Initialized
INFO - 2023-07-11 08:21:29 --> Output Class Initialized
INFO - 2023-07-11 08:21:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:29 --> Input Class Initialized
INFO - 2023-07-11 08:21:29 --> Language Class Initialized
ERROR - 2023-07-11 08:21:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:21:29 --> Config Class Initialized
INFO - 2023-07-11 08:21:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:21:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:21:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:21:29 --> URI Class Initialized
INFO - 2023-07-11 08:21:29 --> Router Class Initialized
INFO - 2023-07-11 08:21:29 --> Output Class Initialized
INFO - 2023-07-11 08:21:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:21:29 --> Input Class Initialized
INFO - 2023-07-11 08:21:29 --> Language Class Initialized
ERROR - 2023-07-11 08:21:29 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:22:46 --> Config Class Initialized
INFO - 2023-07-11 08:22:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:22:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:22:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:22:46 --> URI Class Initialized
INFO - 2023-07-11 08:22:46 --> Router Class Initialized
INFO - 2023-07-11 08:22:46 --> Output Class Initialized
INFO - 2023-07-11 08:22:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:22:46 --> Input Class Initialized
INFO - 2023-07-11 08:22:46 --> Language Class Initialized
ERROR - 2023-07-11 08:22:46 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:24:37 --> Config Class Initialized
INFO - 2023-07-11 08:24:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:37 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:37 --> URI Class Initialized
INFO - 2023-07-11 08:24:37 --> Router Class Initialized
INFO - 2023-07-11 08:24:37 --> Output Class Initialized
INFO - 2023-07-11 08:24:37 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:37 --> Input Class Initialized
INFO - 2023-07-11 08:24:37 --> Language Class Initialized
INFO - 2023-07-11 08:24:37 --> Loader Class Initialized
INFO - 2023-07-11 08:24:37 --> Helper loaded: url_helper
INFO - 2023-07-11 08:24:37 --> Database Driver Class Initialized
INFO - 2023-07-11 08:24:37 --> Controller Class Initialized
INFO - 2023-07-11 08:24:37 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:24:37 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:24:37 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:24:37 --> Final output sent to browser
DEBUG - 2023-07-11 08:24:37 --> Total execution time: 0.0946
INFO - 2023-07-11 08:24:37 --> Config Class Initialized
INFO - 2023-07-11 08:24:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:37 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:37 --> URI Class Initialized
INFO - 2023-07-11 08:24:37 --> Router Class Initialized
INFO - 2023-07-11 08:24:37 --> Output Class Initialized
INFO - 2023-07-11 08:24:37 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:37 --> Input Class Initialized
INFO - 2023-07-11 08:24:37 --> Language Class Initialized
ERROR - 2023-07-11 08:24:37 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:24:37 --> Config Class Initialized
INFO - 2023-07-11 08:24:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:38 --> URI Class Initialized
INFO - 2023-07-11 08:24:38 --> Router Class Initialized
INFO - 2023-07-11 08:24:38 --> Output Class Initialized
INFO - 2023-07-11 08:24:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:38 --> Input Class Initialized
INFO - 2023-07-11 08:24:38 --> Language Class Initialized
ERROR - 2023-07-11 08:24:38 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:24:38 --> Config Class Initialized
INFO - 2023-07-11 08:24:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:38 --> URI Class Initialized
INFO - 2023-07-11 08:24:38 --> Router Class Initialized
INFO - 2023-07-11 08:24:38 --> Output Class Initialized
INFO - 2023-07-11 08:24:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:38 --> Input Class Initialized
INFO - 2023-07-11 08:24:38 --> Language Class Initialized
ERROR - 2023-07-11 08:24:38 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:24:38 --> Config Class Initialized
INFO - 2023-07-11 08:24:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:38 --> URI Class Initialized
INFO - 2023-07-11 08:24:38 --> Router Class Initialized
INFO - 2023-07-11 08:24:38 --> Output Class Initialized
INFO - 2023-07-11 08:24:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:38 --> Input Class Initialized
INFO - 2023-07-11 08:24:38 --> Language Class Initialized
ERROR - 2023-07-11 08:24:38 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:24:43 --> Config Class Initialized
INFO - 2023-07-11 08:24:43 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:43 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:43 --> URI Class Initialized
INFO - 2023-07-11 08:24:43 --> Router Class Initialized
INFO - 2023-07-11 08:24:43 --> Output Class Initialized
INFO - 2023-07-11 08:24:43 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:43 --> Input Class Initialized
INFO - 2023-07-11 08:24:43 --> Language Class Initialized
ERROR - 2023-07-11 08:24:43 --> 404 Page Not Found: About/index
INFO - 2023-07-11 08:24:48 --> Config Class Initialized
INFO - 2023-07-11 08:24:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:48 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:48 --> URI Class Initialized
INFO - 2023-07-11 08:24:48 --> Router Class Initialized
INFO - 2023-07-11 08:24:48 --> Output Class Initialized
INFO - 2023-07-11 08:24:48 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:48 --> Input Class Initialized
INFO - 2023-07-11 08:24:48 --> Language Class Initialized
INFO - 2023-07-11 08:24:48 --> Loader Class Initialized
INFO - 2023-07-11 08:24:48 --> Helper loaded: url_helper
INFO - 2023-07-11 08:24:48 --> Database Driver Class Initialized
INFO - 2023-07-11 08:24:48 --> Controller Class Initialized
INFO - 2023-07-11 08:24:48 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:24:48 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:24:48 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:24:48 --> Final output sent to browser
DEBUG - 2023-07-11 08:24:48 --> Total execution time: 0.0566
INFO - 2023-07-11 08:24:48 --> Config Class Initialized
INFO - 2023-07-11 08:24:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:48 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:48 --> URI Class Initialized
INFO - 2023-07-11 08:24:48 --> Router Class Initialized
INFO - 2023-07-11 08:24:48 --> Output Class Initialized
INFO - 2023-07-11 08:24:48 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:48 --> Input Class Initialized
INFO - 2023-07-11 08:24:48 --> Language Class Initialized
ERROR - 2023-07-11 08:24:48 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:24:48 --> Config Class Initialized
INFO - 2023-07-11 08:24:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:48 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:48 --> URI Class Initialized
INFO - 2023-07-11 08:24:48 --> Router Class Initialized
INFO - 2023-07-11 08:24:48 --> Output Class Initialized
INFO - 2023-07-11 08:24:48 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:48 --> Input Class Initialized
INFO - 2023-07-11 08:24:48 --> Language Class Initialized
ERROR - 2023-07-11 08:24:48 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:24:48 --> Config Class Initialized
INFO - 2023-07-11 08:24:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:48 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:48 --> URI Class Initialized
INFO - 2023-07-11 08:24:48 --> Router Class Initialized
INFO - 2023-07-11 08:24:48 --> Output Class Initialized
INFO - 2023-07-11 08:24:48 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:48 --> Input Class Initialized
INFO - 2023-07-11 08:24:48 --> Language Class Initialized
ERROR - 2023-07-11 08:24:48 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:24:59 --> Config Class Initialized
INFO - 2023-07-11 08:24:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:59 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:59 --> URI Class Initialized
INFO - 2023-07-11 08:24:59 --> Router Class Initialized
INFO - 2023-07-11 08:24:59 --> Output Class Initialized
INFO - 2023-07-11 08:24:59 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:59 --> Input Class Initialized
INFO - 2023-07-11 08:24:59 --> Language Class Initialized
INFO - 2023-07-11 08:24:59 --> Loader Class Initialized
INFO - 2023-07-11 08:24:59 --> Helper loaded: url_helper
INFO - 2023-07-11 08:24:59 --> Database Driver Class Initialized
INFO - 2023-07-11 08:24:59 --> Controller Class Initialized
INFO - 2023-07-11 08:24:59 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:24:59 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:24:59 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:24:59 --> Final output sent to browser
DEBUG - 2023-07-11 08:24:59 --> Total execution time: 0.0582
INFO - 2023-07-11 08:24:59 --> Config Class Initialized
INFO - 2023-07-11 08:24:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:24:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:24:59 --> Utf8 Class Initialized
INFO - 2023-07-11 08:24:59 --> URI Class Initialized
INFO - 2023-07-11 08:24:59 --> Router Class Initialized
INFO - 2023-07-11 08:24:59 --> Output Class Initialized
INFO - 2023-07-11 08:24:59 --> Security Class Initialized
DEBUG - 2023-07-11 08:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:24:59 --> Input Class Initialized
INFO - 2023-07-11 08:24:59 --> Language Class Initialized
ERROR - 2023-07-11 08:24:59 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:00 --> Config Class Initialized
INFO - 2023-07-11 08:25:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:00 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:00 --> URI Class Initialized
INFO - 2023-07-11 08:25:00 --> Router Class Initialized
INFO - 2023-07-11 08:25:00 --> Output Class Initialized
INFO - 2023-07-11 08:25:00 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:00 --> Input Class Initialized
INFO - 2023-07-11 08:25:00 --> Language Class Initialized
ERROR - 2023-07-11 08:25:00 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:00 --> Config Class Initialized
INFO - 2023-07-11 08:25:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:00 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:00 --> URI Class Initialized
INFO - 2023-07-11 08:25:00 --> Router Class Initialized
INFO - 2023-07-11 08:25:00 --> Output Class Initialized
INFO - 2023-07-11 08:25:00 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:00 --> Input Class Initialized
INFO - 2023-07-11 08:25:00 --> Language Class Initialized
ERROR - 2023-07-11 08:25:00 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:25:01 --> Config Class Initialized
INFO - 2023-07-11 08:25:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:01 --> URI Class Initialized
INFO - 2023-07-11 08:25:01 --> Router Class Initialized
INFO - 2023-07-11 08:25:01 --> Output Class Initialized
INFO - 2023-07-11 08:25:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:01 --> Input Class Initialized
INFO - 2023-07-11 08:25:01 --> Language Class Initialized
INFO - 2023-07-11 08:25:01 --> Loader Class Initialized
INFO - 2023-07-11 08:25:01 --> Helper loaded: url_helper
INFO - 2023-07-11 08:25:01 --> Database Driver Class Initialized
INFO - 2023-07-11 08:25:01 --> Controller Class Initialized
INFO - 2023-07-11 08:25:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:25:01 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:25:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:25:01 --> Final output sent to browser
DEBUG - 2023-07-11 08:25:01 --> Total execution time: 0.0621
INFO - 2023-07-11 08:25:01 --> Config Class Initialized
INFO - 2023-07-11 08:25:01 --> Hooks Class Initialized
INFO - 2023-07-11 08:25:01 --> Config Class Initialized
INFO - 2023-07-11 08:25:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:01 --> URI Class Initialized
DEBUG - 2023-07-11 08:25:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:01 --> Router Class Initialized
INFO - 2023-07-11 08:25:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:01 --> URI Class Initialized
INFO - 2023-07-11 08:25:01 --> Output Class Initialized
INFO - 2023-07-11 08:25:01 --> Router Class Initialized
INFO - 2023-07-11 08:25:01 --> Security Class Initialized
INFO - 2023-07-11 08:25:01 --> Output Class Initialized
DEBUG - 2023-07-11 08:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:01 --> Input Class Initialized
INFO - 2023-07-11 08:25:01 --> Security Class Initialized
INFO - 2023-07-11 08:25:01 --> Language Class Initialized
ERROR - 2023-07-11 08:25:01 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:01 --> Input Class Initialized
INFO - 2023-07-11 08:25:01 --> Language Class Initialized
ERROR - 2023-07-11 08:25:01 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:25:01 --> Config Class Initialized
INFO - 2023-07-11 08:25:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:02 --> URI Class Initialized
INFO - 2023-07-11 08:25:02 --> Router Class Initialized
INFO - 2023-07-11 08:25:02 --> Output Class Initialized
INFO - 2023-07-11 08:25:02 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:02 --> Input Class Initialized
INFO - 2023-07-11 08:25:02 --> Language Class Initialized
ERROR - 2023-07-11 08:25:02 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:25:02 --> Config Class Initialized
INFO - 2023-07-11 08:25:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:02 --> URI Class Initialized
INFO - 2023-07-11 08:25:02 --> Router Class Initialized
INFO - 2023-07-11 08:25:02 --> Output Class Initialized
INFO - 2023-07-11 08:25:02 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:02 --> Input Class Initialized
INFO - 2023-07-11 08:25:02 --> Language Class Initialized
ERROR - 2023-07-11 08:25:02 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:25:11 --> Config Class Initialized
INFO - 2023-07-11 08:25:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:11 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:11 --> URI Class Initialized
INFO - 2023-07-11 08:25:11 --> Router Class Initialized
INFO - 2023-07-11 08:25:11 --> Output Class Initialized
INFO - 2023-07-11 08:25:11 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:11 --> Input Class Initialized
INFO - 2023-07-11 08:25:11 --> Language Class Initialized
INFO - 2023-07-11 08:25:11 --> Loader Class Initialized
INFO - 2023-07-11 08:25:11 --> Helper loaded: url_helper
INFO - 2023-07-11 08:25:11 --> Database Driver Class Initialized
INFO - 2023-07-11 08:25:11 --> Controller Class Initialized
INFO - 2023-07-11 08:25:11 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:25:11 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:25:11 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:25:11 --> Final output sent to browser
DEBUG - 2023-07-11 08:25:11 --> Total execution time: 0.0592
INFO - 2023-07-11 08:25:11 --> Config Class Initialized
INFO - 2023-07-11 08:25:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:11 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:11 --> URI Class Initialized
INFO - 2023-07-11 08:25:11 --> Router Class Initialized
INFO - 2023-07-11 08:25:11 --> Output Class Initialized
INFO - 2023-07-11 08:25:11 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:11 --> Input Class Initialized
INFO - 2023-07-11 08:25:11 --> Language Class Initialized
ERROR - 2023-07-11 08:25:11 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:11 --> Config Class Initialized
INFO - 2023-07-11 08:25:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:11 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:11 --> URI Class Initialized
INFO - 2023-07-11 08:25:11 --> Router Class Initialized
INFO - 2023-07-11 08:25:11 --> Output Class Initialized
INFO - 2023-07-11 08:25:11 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:11 --> Input Class Initialized
INFO - 2023-07-11 08:25:11 --> Language Class Initialized
ERROR - 2023-07-11 08:25:11 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:11 --> Config Class Initialized
INFO - 2023-07-11 08:25:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:11 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:11 --> URI Class Initialized
INFO - 2023-07-11 08:25:11 --> Router Class Initialized
INFO - 2023-07-11 08:25:11 --> Output Class Initialized
INFO - 2023-07-11 08:25:11 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:11 --> Input Class Initialized
INFO - 2023-07-11 08:25:11 --> Language Class Initialized
ERROR - 2023-07-11 08:25:11 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:11 --> Config Class Initialized
INFO - 2023-07-11 08:25:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:11 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:11 --> URI Class Initialized
INFO - 2023-07-11 08:25:11 --> Router Class Initialized
INFO - 2023-07-11 08:25:11 --> Output Class Initialized
INFO - 2023-07-11 08:25:11 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:11 --> Input Class Initialized
INFO - 2023-07-11 08:25:11 --> Language Class Initialized
ERROR - 2023-07-11 08:25:11 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:25:14 --> Config Class Initialized
INFO - 2023-07-11 08:25:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:14 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:14 --> URI Class Initialized
INFO - 2023-07-11 08:25:14 --> Router Class Initialized
INFO - 2023-07-11 08:25:14 --> Output Class Initialized
INFO - 2023-07-11 08:25:14 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:14 --> Input Class Initialized
INFO - 2023-07-11 08:25:14 --> Language Class Initialized
INFO - 2023-07-11 08:25:14 --> Loader Class Initialized
INFO - 2023-07-11 08:25:14 --> Helper loaded: url_helper
INFO - 2023-07-11 08:25:14 --> Database Driver Class Initialized
INFO - 2023-07-11 08:25:14 --> Controller Class Initialized
INFO - 2023-07-11 08:25:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:25:14 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:25:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:25:14 --> Final output sent to browser
DEBUG - 2023-07-11 08:25:14 --> Total execution time: 0.0540
INFO - 2023-07-11 08:25:14 --> Config Class Initialized
INFO - 2023-07-11 08:25:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:14 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:14 --> URI Class Initialized
INFO - 2023-07-11 08:25:14 --> Router Class Initialized
INFO - 2023-07-11 08:25:14 --> Output Class Initialized
INFO - 2023-07-11 08:25:14 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:14 --> Input Class Initialized
INFO - 2023-07-11 08:25:14 --> Language Class Initialized
ERROR - 2023-07-11 08:25:14 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:15 --> Config Class Initialized
INFO - 2023-07-11 08:25:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:15 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:15 --> URI Class Initialized
INFO - 2023-07-11 08:25:15 --> Router Class Initialized
INFO - 2023-07-11 08:25:15 --> Output Class Initialized
INFO - 2023-07-11 08:25:15 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:15 --> Input Class Initialized
INFO - 2023-07-11 08:25:15 --> Language Class Initialized
ERROR - 2023-07-11 08:25:15 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:15 --> Config Class Initialized
INFO - 2023-07-11 08:25:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:15 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:15 --> URI Class Initialized
INFO - 2023-07-11 08:25:15 --> Router Class Initialized
INFO - 2023-07-11 08:25:15 --> Output Class Initialized
INFO - 2023-07-11 08:25:15 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:15 --> Input Class Initialized
INFO - 2023-07-11 08:25:15 --> Language Class Initialized
ERROR - 2023-07-11 08:25:15 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:25:38 --> Config Class Initialized
INFO - 2023-07-11 08:25:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:38 --> URI Class Initialized
INFO - 2023-07-11 08:25:38 --> Router Class Initialized
INFO - 2023-07-11 08:25:38 --> Output Class Initialized
INFO - 2023-07-11 08:25:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:38 --> Input Class Initialized
INFO - 2023-07-11 08:25:38 --> Language Class Initialized
INFO - 2023-07-11 08:25:38 --> Loader Class Initialized
INFO - 2023-07-11 08:25:38 --> Helper loaded: url_helper
INFO - 2023-07-11 08:25:38 --> Database Driver Class Initialized
INFO - 2023-07-11 08:25:38 --> Controller Class Initialized
INFO - 2023-07-11 08:25:38 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:25:38 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:25:38 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:25:38 --> Final output sent to browser
DEBUG - 2023-07-11 08:25:38 --> Total execution time: 0.0553
INFO - 2023-07-11 08:25:38 --> Config Class Initialized
INFO - 2023-07-11 08:25:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:38 --> URI Class Initialized
INFO - 2023-07-11 08:25:38 --> Router Class Initialized
INFO - 2023-07-11 08:25:38 --> Output Class Initialized
INFO - 2023-07-11 08:25:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:38 --> Input Class Initialized
INFO - 2023-07-11 08:25:38 --> Language Class Initialized
ERROR - 2023-07-11 08:25:38 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:38 --> Config Class Initialized
INFO - 2023-07-11 08:25:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:38 --> URI Class Initialized
INFO - 2023-07-11 08:25:38 --> Router Class Initialized
INFO - 2023-07-11 08:25:38 --> Output Class Initialized
INFO - 2023-07-11 08:25:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:38 --> Input Class Initialized
INFO - 2023-07-11 08:25:38 --> Language Class Initialized
ERROR - 2023-07-11 08:25:38 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:38 --> Config Class Initialized
INFO - 2023-07-11 08:25:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:38 --> URI Class Initialized
INFO - 2023-07-11 08:25:38 --> Router Class Initialized
INFO - 2023-07-11 08:25:38 --> Output Class Initialized
INFO - 2023-07-11 08:25:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:38 --> Input Class Initialized
INFO - 2023-07-11 08:25:38 --> Language Class Initialized
ERROR - 2023-07-11 08:25:38 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:25:38 --> Config Class Initialized
INFO - 2023-07-11 08:25:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:25:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:25:38 --> Utf8 Class Initialized
INFO - 2023-07-11 08:25:38 --> URI Class Initialized
INFO - 2023-07-11 08:25:38 --> Router Class Initialized
INFO - 2023-07-11 08:25:38 --> Output Class Initialized
INFO - 2023-07-11 08:25:38 --> Security Class Initialized
DEBUG - 2023-07-11 08:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:25:38 --> Input Class Initialized
INFO - 2023-07-11 08:25:38 --> Language Class Initialized
ERROR - 2023-07-11 08:25:38 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:26:16 --> Config Class Initialized
INFO - 2023-07-11 08:26:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:16 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:16 --> URI Class Initialized
INFO - 2023-07-11 08:26:16 --> Router Class Initialized
INFO - 2023-07-11 08:26:16 --> Output Class Initialized
INFO - 2023-07-11 08:26:16 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:16 --> Input Class Initialized
INFO - 2023-07-11 08:26:16 --> Language Class Initialized
INFO - 2023-07-11 08:26:16 --> Loader Class Initialized
INFO - 2023-07-11 08:26:16 --> Helper loaded: url_helper
INFO - 2023-07-11 08:26:16 --> Database Driver Class Initialized
INFO - 2023-07-11 08:26:16 --> Controller Class Initialized
INFO - 2023-07-11 08:26:16 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:26:16 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:26:16 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:26:16 --> Final output sent to browser
DEBUG - 2023-07-11 08:26:16 --> Total execution time: 0.0560
INFO - 2023-07-11 08:26:16 --> Config Class Initialized
INFO - 2023-07-11 08:26:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:16 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:16 --> URI Class Initialized
INFO - 2023-07-11 08:26:16 --> Router Class Initialized
INFO - 2023-07-11 08:26:16 --> Output Class Initialized
INFO - 2023-07-11 08:26:16 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:16 --> Input Class Initialized
INFO - 2023-07-11 08:26:16 --> Language Class Initialized
ERROR - 2023-07-11 08:26:16 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:26:16 --> Config Class Initialized
INFO - 2023-07-11 08:26:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:16 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:16 --> URI Class Initialized
INFO - 2023-07-11 08:26:16 --> Router Class Initialized
INFO - 2023-07-11 08:26:16 --> Output Class Initialized
INFO - 2023-07-11 08:26:16 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:16 --> Input Class Initialized
INFO - 2023-07-11 08:26:16 --> Language Class Initialized
ERROR - 2023-07-11 08:26:16 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:26:16 --> Config Class Initialized
INFO - 2023-07-11 08:26:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:16 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:16 --> URI Class Initialized
INFO - 2023-07-11 08:26:16 --> Router Class Initialized
INFO - 2023-07-11 08:26:17 --> Output Class Initialized
INFO - 2023-07-11 08:26:17 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:17 --> Input Class Initialized
INFO - 2023-07-11 08:26:17 --> Language Class Initialized
ERROR - 2023-07-11 08:26:17 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:26:29 --> Config Class Initialized
INFO - 2023-07-11 08:26:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:29 --> URI Class Initialized
INFO - 2023-07-11 08:26:29 --> Router Class Initialized
INFO - 2023-07-11 08:26:29 --> Output Class Initialized
INFO - 2023-07-11 08:26:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:29 --> Input Class Initialized
INFO - 2023-07-11 08:26:29 --> Language Class Initialized
INFO - 2023-07-11 08:26:29 --> Loader Class Initialized
INFO - 2023-07-11 08:26:29 --> Helper loaded: url_helper
INFO - 2023-07-11 08:26:29 --> Database Driver Class Initialized
INFO - 2023-07-11 08:26:29 --> Controller Class Initialized
INFO - 2023-07-11 08:26:29 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:26:29 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:26:29 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:26:29 --> Final output sent to browser
DEBUG - 2023-07-11 08:26:29 --> Total execution time: 0.0539
INFO - 2023-07-11 08:26:29 --> Config Class Initialized
INFO - 2023-07-11 08:26:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:29 --> URI Class Initialized
INFO - 2023-07-11 08:26:29 --> Router Class Initialized
INFO - 2023-07-11 08:26:29 --> Output Class Initialized
INFO - 2023-07-11 08:26:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:29 --> Input Class Initialized
INFO - 2023-07-11 08:26:29 --> Language Class Initialized
ERROR - 2023-07-11 08:26:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:26:30 --> Config Class Initialized
INFO - 2023-07-11 08:26:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:30 --> URI Class Initialized
INFO - 2023-07-11 08:26:30 --> Router Class Initialized
INFO - 2023-07-11 08:26:30 --> Output Class Initialized
INFO - 2023-07-11 08:26:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:30 --> Input Class Initialized
INFO - 2023-07-11 08:26:30 --> Language Class Initialized
ERROR - 2023-07-11 08:26:30 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:26:30 --> Config Class Initialized
INFO - 2023-07-11 08:26:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:30 --> URI Class Initialized
INFO - 2023-07-11 08:26:30 --> Router Class Initialized
INFO - 2023-07-11 08:26:30 --> Output Class Initialized
INFO - 2023-07-11 08:26:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:30 --> Input Class Initialized
INFO - 2023-07-11 08:26:30 --> Language Class Initialized
ERROR - 2023-07-11 08:26:30 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:26:30 --> Config Class Initialized
INFO - 2023-07-11 08:26:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:26:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:26:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:26:30 --> URI Class Initialized
INFO - 2023-07-11 08:26:30 --> Router Class Initialized
INFO - 2023-07-11 08:26:30 --> Output Class Initialized
INFO - 2023-07-11 08:26:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:26:30 --> Input Class Initialized
INFO - 2023-07-11 08:26:30 --> Language Class Initialized
ERROR - 2023-07-11 08:26:30 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:27:29 --> Config Class Initialized
INFO - 2023-07-11 08:27:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:27:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:27:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:27:29 --> URI Class Initialized
INFO - 2023-07-11 08:27:29 --> Router Class Initialized
INFO - 2023-07-11 08:27:29 --> Output Class Initialized
INFO - 2023-07-11 08:27:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:27:29 --> Input Class Initialized
INFO - 2023-07-11 08:27:29 --> Language Class Initialized
INFO - 2023-07-11 08:27:29 --> Loader Class Initialized
INFO - 2023-07-11 08:27:29 --> Helper loaded: url_helper
INFO - 2023-07-11 08:27:29 --> Database Driver Class Initialized
INFO - 2023-07-11 08:27:29 --> Controller Class Initialized
INFO - 2023-07-11 08:27:29 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:27:29 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:27:29 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:27:29 --> Final output sent to browser
DEBUG - 2023-07-11 08:27:29 --> Total execution time: 0.0884
INFO - 2023-07-11 08:27:29 --> Config Class Initialized
INFO - 2023-07-11 08:27:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:27:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:27:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:27:29 --> URI Class Initialized
INFO - 2023-07-11 08:27:29 --> Router Class Initialized
INFO - 2023-07-11 08:27:29 --> Output Class Initialized
INFO - 2023-07-11 08:27:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:27:29 --> Input Class Initialized
INFO - 2023-07-11 08:27:29 --> Language Class Initialized
ERROR - 2023-07-11 08:27:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:27:29 --> Config Class Initialized
INFO - 2023-07-11 08:27:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:27:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:27:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:27:29 --> URI Class Initialized
INFO - 2023-07-11 08:27:29 --> Router Class Initialized
INFO - 2023-07-11 08:27:29 --> Output Class Initialized
INFO - 2023-07-11 08:27:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:27:29 --> Input Class Initialized
INFO - 2023-07-11 08:27:29 --> Language Class Initialized
ERROR - 2023-07-11 08:27:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:27:29 --> Config Class Initialized
INFO - 2023-07-11 08:27:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:27:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:27:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:27:29 --> URI Class Initialized
INFO - 2023-07-11 08:27:29 --> Router Class Initialized
INFO - 2023-07-11 08:27:29 --> Output Class Initialized
INFO - 2023-07-11 08:27:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:27:29 --> Input Class Initialized
INFO - 2023-07-11 08:27:29 --> Language Class Initialized
ERROR - 2023-07-11 08:27:29 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:27:29 --> Config Class Initialized
INFO - 2023-07-11 08:27:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:27:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:27:29 --> Utf8 Class Initialized
INFO - 2023-07-11 08:27:29 --> URI Class Initialized
INFO - 2023-07-11 08:27:29 --> Router Class Initialized
INFO - 2023-07-11 08:27:29 --> Output Class Initialized
INFO - 2023-07-11 08:27:29 --> Security Class Initialized
DEBUG - 2023-07-11 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:27:29 --> Input Class Initialized
INFO - 2023-07-11 08:27:29 --> Language Class Initialized
ERROR - 2023-07-11 08:27:29 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:27:53 --> Config Class Initialized
INFO - 2023-07-11 08:27:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:27:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:27:53 --> Utf8 Class Initialized
INFO - 2023-07-11 08:27:53 --> URI Class Initialized
INFO - 2023-07-11 08:27:53 --> Router Class Initialized
INFO - 2023-07-11 08:27:53 --> Output Class Initialized
INFO - 2023-07-11 08:27:53 --> Security Class Initialized
DEBUG - 2023-07-11 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:27:53 --> Input Class Initialized
INFO - 2023-07-11 08:27:53 --> Language Class Initialized
ERROR - 2023-07-11 08:27:53 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:28:56 --> Config Class Initialized
INFO - 2023-07-11 08:28:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:28:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:28:56 --> Utf8 Class Initialized
INFO - 2023-07-11 08:28:56 --> URI Class Initialized
INFO - 2023-07-11 08:28:56 --> Router Class Initialized
INFO - 2023-07-11 08:28:56 --> Output Class Initialized
INFO - 2023-07-11 08:28:56 --> Security Class Initialized
DEBUG - 2023-07-11 08:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:28:56 --> Input Class Initialized
INFO - 2023-07-11 08:28:56 --> Language Class Initialized
INFO - 2023-07-11 08:28:56 --> Loader Class Initialized
INFO - 2023-07-11 08:28:57 --> Helper loaded: url_helper
INFO - 2023-07-11 08:28:57 --> Database Driver Class Initialized
INFO - 2023-07-11 08:28:57 --> Controller Class Initialized
INFO - 2023-07-11 08:28:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:28:57 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:28:57 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:28:57 --> Final output sent to browser
DEBUG - 2023-07-11 08:28:57 --> Total execution time: 0.0668
INFO - 2023-07-11 08:28:57 --> Config Class Initialized
INFO - 2023-07-11 08:28:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:28:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:28:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:28:57 --> URI Class Initialized
INFO - 2023-07-11 08:28:57 --> Router Class Initialized
INFO - 2023-07-11 08:28:57 --> Output Class Initialized
INFO - 2023-07-11 08:28:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:28:57 --> Input Class Initialized
INFO - 2023-07-11 08:28:57 --> Language Class Initialized
ERROR - 2023-07-11 08:28:57 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:28:57 --> Config Class Initialized
INFO - 2023-07-11 08:28:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:28:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:28:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:28:57 --> URI Class Initialized
INFO - 2023-07-11 08:28:57 --> Router Class Initialized
INFO - 2023-07-11 08:28:57 --> Output Class Initialized
INFO - 2023-07-11 08:28:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:28:57 --> Input Class Initialized
INFO - 2023-07-11 08:28:57 --> Language Class Initialized
ERROR - 2023-07-11 08:28:57 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:28:57 --> Config Class Initialized
INFO - 2023-07-11 08:28:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:28:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:28:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:28:57 --> URI Class Initialized
INFO - 2023-07-11 08:28:57 --> Router Class Initialized
INFO - 2023-07-11 08:28:57 --> Output Class Initialized
INFO - 2023-07-11 08:28:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:28:57 --> Input Class Initialized
INFO - 2023-07-11 08:28:57 --> Language Class Initialized
ERROR - 2023-07-11 08:28:57 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:28:57 --> Config Class Initialized
INFO - 2023-07-11 08:28:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:28:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:28:57 --> Utf8 Class Initialized
INFO - 2023-07-11 08:28:57 --> URI Class Initialized
INFO - 2023-07-11 08:28:57 --> Router Class Initialized
INFO - 2023-07-11 08:28:57 --> Output Class Initialized
INFO - 2023-07-11 08:28:57 --> Security Class Initialized
DEBUG - 2023-07-11 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:28:57 --> Input Class Initialized
INFO - 2023-07-11 08:28:57 --> Language Class Initialized
ERROR - 2023-07-11 08:28:57 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:49:01 --> Config Class Initialized
INFO - 2023-07-11 08:49:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:49:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:49:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:49:01 --> URI Class Initialized
INFO - 2023-07-11 08:49:01 --> Router Class Initialized
INFO - 2023-07-11 08:49:01 --> Output Class Initialized
INFO - 2023-07-11 08:49:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:49:01 --> Input Class Initialized
INFO - 2023-07-11 08:49:01 --> Language Class Initialized
INFO - 2023-07-11 08:49:01 --> Loader Class Initialized
INFO - 2023-07-11 08:49:01 --> Helper loaded: url_helper
INFO - 2023-07-11 08:49:01 --> Database Driver Class Initialized
INFO - 2023-07-11 08:49:01 --> Controller Class Initialized
INFO - 2023-07-11 08:49:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:49:01 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:49:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:49:01 --> Final output sent to browser
DEBUG - 2023-07-11 08:49:01 --> Total execution time: 0.1561
INFO - 2023-07-11 08:49:01 --> Config Class Initialized
INFO - 2023-07-11 08:49:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:49:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:49:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:49:01 --> URI Class Initialized
INFO - 2023-07-11 08:49:01 --> Router Class Initialized
INFO - 2023-07-11 08:49:01 --> Output Class Initialized
INFO - 2023-07-11 08:49:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:49:01 --> Input Class Initialized
INFO - 2023-07-11 08:49:01 --> Language Class Initialized
ERROR - 2023-07-11 08:49:01 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:49:01 --> Config Class Initialized
INFO - 2023-07-11 08:49:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:49:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:49:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:49:01 --> URI Class Initialized
INFO - 2023-07-11 08:49:01 --> Router Class Initialized
INFO - 2023-07-11 08:49:01 --> Output Class Initialized
INFO - 2023-07-11 08:49:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:49:01 --> Input Class Initialized
INFO - 2023-07-11 08:49:01 --> Language Class Initialized
ERROR - 2023-07-11 08:49:01 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:49:01 --> Config Class Initialized
INFO - 2023-07-11 08:49:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:49:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:49:01 --> Utf8 Class Initialized
INFO - 2023-07-11 08:49:01 --> URI Class Initialized
INFO - 2023-07-11 08:49:01 --> Router Class Initialized
INFO - 2023-07-11 08:49:01 --> Output Class Initialized
INFO - 2023-07-11 08:49:01 --> Security Class Initialized
DEBUG - 2023-07-11 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:49:01 --> Input Class Initialized
INFO - 2023-07-11 08:49:01 --> Language Class Initialized
ERROR - 2023-07-11 08:49:01 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:52:02 --> Config Class Initialized
INFO - 2023-07-11 08:52:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:02 --> URI Class Initialized
INFO - 2023-07-11 08:52:02 --> Router Class Initialized
INFO - 2023-07-11 08:52:02 --> Output Class Initialized
INFO - 2023-07-11 08:52:02 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:02 --> Input Class Initialized
INFO - 2023-07-11 08:52:02 --> Language Class Initialized
INFO - 2023-07-11 08:52:02 --> Loader Class Initialized
INFO - 2023-07-11 08:52:02 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:02 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:02 --> Controller Class Initialized
INFO - 2023-07-11 08:52:02 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:02 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:52:02 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:02 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:02 --> Total execution time: 0.1125
INFO - 2023-07-11 08:52:02 --> Config Class Initialized
INFO - 2023-07-11 08:52:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:02 --> URI Class Initialized
INFO - 2023-07-11 08:52:02 --> Router Class Initialized
INFO - 2023-07-11 08:52:02 --> Output Class Initialized
INFO - 2023-07-11 08:52:02 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:02 --> Input Class Initialized
INFO - 2023-07-11 08:52:02 --> Language Class Initialized
ERROR - 2023-07-11 08:52:02 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:52:02 --> Config Class Initialized
INFO - 2023-07-11 08:52:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:02 --> URI Class Initialized
INFO - 2023-07-11 08:52:02 --> Router Class Initialized
INFO - 2023-07-11 08:52:02 --> Output Class Initialized
INFO - 2023-07-11 08:52:02 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:02 --> Input Class Initialized
INFO - 2023-07-11 08:52:02 --> Language Class Initialized
ERROR - 2023-07-11 08:52:02 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:52:06 --> Config Class Initialized
INFO - 2023-07-11 08:52:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:06 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:06 --> URI Class Initialized
INFO - 2023-07-11 08:52:06 --> Router Class Initialized
INFO - 2023-07-11 08:52:06 --> Output Class Initialized
INFO - 2023-07-11 08:52:06 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:06 --> Input Class Initialized
INFO - 2023-07-11 08:52:06 --> Language Class Initialized
INFO - 2023-07-11 08:52:06 --> Loader Class Initialized
INFO - 2023-07-11 08:52:07 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:07 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:07 --> Controller Class Initialized
INFO - 2023-07-11 08:52:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:07 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:52:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:07 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:07 --> Total execution time: 0.0542
INFO - 2023-07-11 08:52:07 --> Config Class Initialized
INFO - 2023-07-11 08:52:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:07 --> URI Class Initialized
INFO - 2023-07-11 08:52:07 --> Router Class Initialized
INFO - 2023-07-11 08:52:07 --> Output Class Initialized
INFO - 2023-07-11 08:52:07 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:07 --> Input Class Initialized
INFO - 2023-07-11 08:52:07 --> Language Class Initialized
ERROR - 2023-07-11 08:52:07 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:52:07 --> Config Class Initialized
INFO - 2023-07-11 08:52:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:07 --> URI Class Initialized
INFO - 2023-07-11 08:52:07 --> Router Class Initialized
INFO - 2023-07-11 08:52:07 --> Output Class Initialized
INFO - 2023-07-11 08:52:07 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:07 --> Input Class Initialized
INFO - 2023-07-11 08:52:07 --> Language Class Initialized
ERROR - 2023-07-11 08:52:07 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:52:08 --> Config Class Initialized
INFO - 2023-07-11 08:52:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:08 --> URI Class Initialized
INFO - 2023-07-11 08:52:08 --> Router Class Initialized
INFO - 2023-07-11 08:52:08 --> Output Class Initialized
INFO - 2023-07-11 08:52:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:08 --> Input Class Initialized
INFO - 2023-07-11 08:52:08 --> Language Class Initialized
ERROR - 2023-07-11 08:52:08 --> 404 Page Not Found: About/index
INFO - 2023-07-11 08:52:12 --> Config Class Initialized
INFO - 2023-07-11 08:52:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:12 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:12 --> URI Class Initialized
INFO - 2023-07-11 08:52:12 --> Router Class Initialized
INFO - 2023-07-11 08:52:12 --> Output Class Initialized
INFO - 2023-07-11 08:52:12 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:12 --> Input Class Initialized
INFO - 2023-07-11 08:52:12 --> Language Class Initialized
INFO - 2023-07-11 08:52:12 --> Loader Class Initialized
INFO - 2023-07-11 08:52:12 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:12 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:12 --> Controller Class Initialized
INFO - 2023-07-11 08:52:12 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:12 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:52:12 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:12 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:12 --> Total execution time: 0.0591
INFO - 2023-07-11 08:52:12 --> Config Class Initialized
INFO - 2023-07-11 08:52:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:12 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:12 --> URI Class Initialized
INFO - 2023-07-11 08:52:12 --> Router Class Initialized
INFO - 2023-07-11 08:52:12 --> Output Class Initialized
INFO - 2023-07-11 08:52:12 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:12 --> Input Class Initialized
INFO - 2023-07-11 08:52:12 --> Language Class Initialized
ERROR - 2023-07-11 08:52:12 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:52:12 --> Config Class Initialized
INFO - 2023-07-11 08:52:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:12 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:12 --> URI Class Initialized
INFO - 2023-07-11 08:52:12 --> Router Class Initialized
INFO - 2023-07-11 08:52:12 --> Output Class Initialized
INFO - 2023-07-11 08:52:12 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:12 --> Input Class Initialized
INFO - 2023-07-11 08:52:12 --> Language Class Initialized
ERROR - 2023-07-11 08:52:12 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:52:17 --> Config Class Initialized
INFO - 2023-07-11 08:52:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:17 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:17 --> URI Class Initialized
INFO - 2023-07-11 08:52:17 --> Router Class Initialized
INFO - 2023-07-11 08:52:17 --> Output Class Initialized
INFO - 2023-07-11 08:52:17 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:17 --> Input Class Initialized
INFO - 2023-07-11 08:52:17 --> Language Class Initialized
INFO - 2023-07-11 08:52:17 --> Loader Class Initialized
INFO - 2023-07-11 08:52:17 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:17 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:17 --> Controller Class Initialized
INFO - 2023-07-11 08:52:17 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:17 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:52:17 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:17 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:17 --> Total execution time: 0.0624
INFO - 2023-07-11 08:52:17 --> Config Class Initialized
INFO - 2023-07-11 08:52:17 --> Hooks Class Initialized
INFO - 2023-07-11 08:52:17 --> Config Class Initialized
DEBUG - 2023-07-11 08:52:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:17 --> Hooks Class Initialized
INFO - 2023-07-11 08:52:17 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:17 --> URI Class Initialized
DEBUG - 2023-07-11 08:52:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:17 --> Router Class Initialized
INFO - 2023-07-11 08:52:17 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:17 --> URI Class Initialized
INFO - 2023-07-11 08:52:17 --> Output Class Initialized
INFO - 2023-07-11 08:52:17 --> Router Class Initialized
INFO - 2023-07-11 08:52:17 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:17 --> Input Class Initialized
INFO - 2023-07-11 08:52:17 --> Output Class Initialized
INFO - 2023-07-11 08:52:17 --> Language Class Initialized
INFO - 2023-07-11 08:52:17 --> Security Class Initialized
ERROR - 2023-07-11 08:52:17 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:17 --> Input Class Initialized
INFO - 2023-07-11 08:52:17 --> Language Class Initialized
ERROR - 2023-07-11 08:52:17 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:52:17 --> Config Class Initialized
INFO - 2023-07-11 08:52:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:17 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:17 --> URI Class Initialized
INFO - 2023-07-11 08:52:17 --> Router Class Initialized
INFO - 2023-07-11 08:52:17 --> Output Class Initialized
INFO - 2023-07-11 08:52:17 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:17 --> Input Class Initialized
INFO - 2023-07-11 08:52:17 --> Language Class Initialized
ERROR - 2023-07-11 08:52:17 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:52:22 --> Config Class Initialized
INFO - 2023-07-11 08:52:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:22 --> URI Class Initialized
INFO - 2023-07-11 08:52:22 --> Router Class Initialized
INFO - 2023-07-11 08:52:22 --> Output Class Initialized
INFO - 2023-07-11 08:52:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:22 --> Input Class Initialized
INFO - 2023-07-11 08:52:22 --> Language Class Initialized
INFO - 2023-07-11 08:52:22 --> Loader Class Initialized
INFO - 2023-07-11 08:52:22 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:22 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:22 --> Controller Class Initialized
INFO - 2023-07-11 08:52:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:22 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:52:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:22 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:22 --> Total execution time: 0.0712
INFO - 2023-07-11 08:52:22 --> Config Class Initialized
INFO - 2023-07-11 08:52:22 --> Config Class Initialized
INFO - 2023-07-11 08:52:22 --> Hooks Class Initialized
INFO - 2023-07-11 08:52:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:22 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:22 --> URI Class Initialized
INFO - 2023-07-11 08:52:22 --> URI Class Initialized
INFO - 2023-07-11 08:52:22 --> Router Class Initialized
INFO - 2023-07-11 08:52:22 --> Router Class Initialized
INFO - 2023-07-11 08:52:22 --> Output Class Initialized
INFO - 2023-07-11 08:52:22 --> Output Class Initialized
INFO - 2023-07-11 08:52:22 --> Security Class Initialized
INFO - 2023-07-11 08:52:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:22 --> Input Class Initialized
INFO - 2023-07-11 08:52:22 --> Input Class Initialized
INFO - 2023-07-11 08:52:22 --> Language Class Initialized
INFO - 2023-07-11 08:52:22 --> Language Class Initialized
ERROR - 2023-07-11 08:52:22 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 08:52:22 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:52:22 --> Config Class Initialized
INFO - 2023-07-11 08:52:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:22 --> URI Class Initialized
INFO - 2023-07-11 08:52:22 --> Router Class Initialized
INFO - 2023-07-11 08:52:22 --> Output Class Initialized
INFO - 2023-07-11 08:52:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:22 --> Input Class Initialized
INFO - 2023-07-11 08:52:22 --> Language Class Initialized
ERROR - 2023-07-11 08:52:22 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:52:22 --> Config Class Initialized
INFO - 2023-07-11 08:52:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:22 --> URI Class Initialized
INFO - 2023-07-11 08:52:22 --> Router Class Initialized
INFO - 2023-07-11 08:52:22 --> Output Class Initialized
INFO - 2023-07-11 08:52:22 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:22 --> Input Class Initialized
INFO - 2023-07-11 08:52:22 --> Language Class Initialized
INFO - 2023-07-11 08:52:22 --> Loader Class Initialized
INFO - 2023-07-11 08:52:22 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:22 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:22 --> Controller Class Initialized
INFO - 2023-07-11 08:52:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:22 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:52:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:22 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:22 --> Total execution time: 0.0603
INFO - 2023-07-11 08:52:22 --> Config Class Initialized
INFO - 2023-07-11 08:52:22 --> Hooks Class Initialized
INFO - 2023-07-11 08:52:22 --> Config Class Initialized
INFO - 2023-07-11 08:52:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:22 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:22 --> URI Class Initialized
DEBUG - 2023-07-11 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:23 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:23 --> Router Class Initialized
INFO - 2023-07-11 08:52:23 --> URI Class Initialized
INFO - 2023-07-11 08:52:23 --> Output Class Initialized
INFO - 2023-07-11 08:52:23 --> Router Class Initialized
INFO - 2023-07-11 08:52:23 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:23 --> Input Class Initialized
INFO - 2023-07-11 08:52:23 --> Output Class Initialized
INFO - 2023-07-11 08:52:23 --> Language Class Initialized
INFO - 2023-07-11 08:52:23 --> Security Class Initialized
ERROR - 2023-07-11 08:52:23 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:23 --> Input Class Initialized
INFO - 2023-07-11 08:52:23 --> Language Class Initialized
ERROR - 2023-07-11 08:52:23 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:52:23 --> Config Class Initialized
INFO - 2023-07-11 08:52:23 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:23 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:23 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:23 --> URI Class Initialized
INFO - 2023-07-11 08:52:23 --> Router Class Initialized
INFO - 2023-07-11 08:52:23 --> Output Class Initialized
INFO - 2023-07-11 08:52:23 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:23 --> Input Class Initialized
INFO - 2023-07-11 08:52:23 --> Language Class Initialized
ERROR - 2023-07-11 08:52:23 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:52:30 --> Config Class Initialized
INFO - 2023-07-11 08:52:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:30 --> URI Class Initialized
INFO - 2023-07-11 08:52:30 --> Router Class Initialized
INFO - 2023-07-11 08:52:30 --> Output Class Initialized
INFO - 2023-07-11 08:52:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:30 --> Input Class Initialized
INFO - 2023-07-11 08:52:30 --> Language Class Initialized
INFO - 2023-07-11 08:52:30 --> Loader Class Initialized
INFO - 2023-07-11 08:52:30 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:30 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:30 --> Controller Class Initialized
INFO - 2023-07-11 08:52:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:30 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:52:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:30 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:30 --> Total execution time: 0.0571
INFO - 2023-07-11 08:52:30 --> Config Class Initialized
INFO - 2023-07-11 08:52:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:30 --> URI Class Initialized
INFO - 2023-07-11 08:52:30 --> Router Class Initialized
INFO - 2023-07-11 08:52:30 --> Output Class Initialized
INFO - 2023-07-11 08:52:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:30 --> Input Class Initialized
INFO - 2023-07-11 08:52:30 --> Language Class Initialized
ERROR - 2023-07-11 08:52:30 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:52:30 --> Config Class Initialized
INFO - 2023-07-11 08:52:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:30 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:30 --> URI Class Initialized
INFO - 2023-07-11 08:52:30 --> Router Class Initialized
INFO - 2023-07-11 08:52:30 --> Output Class Initialized
INFO - 2023-07-11 08:52:30 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:30 --> Input Class Initialized
INFO - 2023-07-11 08:52:30 --> Language Class Initialized
ERROR - 2023-07-11 08:52:30 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:52:49 --> Config Class Initialized
INFO - 2023-07-11 08:52:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:49 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:49 --> URI Class Initialized
INFO - 2023-07-11 08:52:49 --> Router Class Initialized
INFO - 2023-07-11 08:52:49 --> Output Class Initialized
INFO - 2023-07-11 08:52:49 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:49 --> Input Class Initialized
INFO - 2023-07-11 08:52:49 --> Language Class Initialized
INFO - 2023-07-11 08:52:49 --> Loader Class Initialized
INFO - 2023-07-11 08:52:49 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:49 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:49 --> Controller Class Initialized
INFO - 2023-07-11 08:52:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:49 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:52:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:49 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:49 --> Total execution time: 0.0756
INFO - 2023-07-11 08:52:49 --> Config Class Initialized
INFO - 2023-07-11 08:52:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:49 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:49 --> URI Class Initialized
INFO - 2023-07-11 08:52:49 --> Router Class Initialized
INFO - 2023-07-11 08:52:49 --> Output Class Initialized
INFO - 2023-07-11 08:52:49 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:49 --> Input Class Initialized
INFO - 2023-07-11 08:52:49 --> Language Class Initialized
ERROR - 2023-07-11 08:52:49 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:52:49 --> Config Class Initialized
INFO - 2023-07-11 08:52:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:49 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:49 --> URI Class Initialized
INFO - 2023-07-11 08:52:49 --> Router Class Initialized
INFO - 2023-07-11 08:52:49 --> Output Class Initialized
INFO - 2023-07-11 08:52:49 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:49 --> Input Class Initialized
INFO - 2023-07-11 08:52:49 --> Language Class Initialized
ERROR - 2023-07-11 08:52:49 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:52:54 --> Config Class Initialized
INFO - 2023-07-11 08:52:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:54 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:54 --> URI Class Initialized
INFO - 2023-07-11 08:52:54 --> Router Class Initialized
INFO - 2023-07-11 08:52:54 --> Output Class Initialized
INFO - 2023-07-11 08:52:54 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:54 --> Input Class Initialized
INFO - 2023-07-11 08:52:54 --> Language Class Initialized
INFO - 2023-07-11 08:52:54 --> Loader Class Initialized
INFO - 2023-07-11 08:52:54 --> Helper loaded: url_helper
INFO - 2023-07-11 08:52:54 --> Database Driver Class Initialized
INFO - 2023-07-11 08:52:54 --> Controller Class Initialized
INFO - 2023-07-11 08:52:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:52:54 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:52:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:52:54 --> Final output sent to browser
DEBUG - 2023-07-11 08:52:54 --> Total execution time: 0.0582
INFO - 2023-07-11 08:52:54 --> Config Class Initialized
INFO - 2023-07-11 08:52:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:54 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:54 --> URI Class Initialized
INFO - 2023-07-11 08:52:54 --> Router Class Initialized
INFO - 2023-07-11 08:52:54 --> Output Class Initialized
INFO - 2023-07-11 08:52:54 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:54 --> Input Class Initialized
INFO - 2023-07-11 08:52:54 --> Language Class Initialized
ERROR - 2023-07-11 08:52:54 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:52:54 --> Config Class Initialized
INFO - 2023-07-11 08:52:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:52:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:52:54 --> Utf8 Class Initialized
INFO - 2023-07-11 08:52:54 --> URI Class Initialized
INFO - 2023-07-11 08:52:54 --> Router Class Initialized
INFO - 2023-07-11 08:52:54 --> Output Class Initialized
INFO - 2023-07-11 08:52:54 --> Security Class Initialized
DEBUG - 2023-07-11 08:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:52:54 --> Input Class Initialized
INFO - 2023-07-11 08:52:54 --> Language Class Initialized
ERROR - 2023-07-11 08:52:54 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:53:07 --> Config Class Initialized
INFO - 2023-07-11 08:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:07 --> URI Class Initialized
INFO - 2023-07-11 08:53:07 --> Router Class Initialized
INFO - 2023-07-11 08:53:07 --> Output Class Initialized
INFO - 2023-07-11 08:53:07 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:07 --> Input Class Initialized
INFO - 2023-07-11 08:53:07 --> Language Class Initialized
INFO - 2023-07-11 08:53:07 --> Loader Class Initialized
INFO - 2023-07-11 08:53:07 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:07 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:07 --> Controller Class Initialized
INFO - 2023-07-11 08:53:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:07 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:07 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:07 --> Total execution time: 0.0605
INFO - 2023-07-11 08:53:07 --> Config Class Initialized
INFO - 2023-07-11 08:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:07 --> Config Class Initialized
INFO - 2023-07-11 08:53:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:07 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:07 --> URI Class Initialized
INFO - 2023-07-11 08:53:07 --> Router Class Initialized
DEBUG - 2023-07-11 08:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:07 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:07 --> URI Class Initialized
INFO - 2023-07-11 08:53:07 --> Output Class Initialized
INFO - 2023-07-11 08:53:07 --> Security Class Initialized
INFO - 2023-07-11 08:53:07 --> Router Class Initialized
DEBUG - 2023-07-11 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:07 --> Input Class Initialized
INFO - 2023-07-11 08:53:07 --> Output Class Initialized
INFO - 2023-07-11 08:53:07 --> Language Class Initialized
INFO - 2023-07-11 08:53:07 --> Security Class Initialized
ERROR - 2023-07-11 08:53:07 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:07 --> Input Class Initialized
INFO - 2023-07-11 08:53:07 --> Language Class Initialized
ERROR - 2023-07-11 08:53:07 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:08 --> Config Class Initialized
INFO - 2023-07-11 08:53:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:08 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:08 --> URI Class Initialized
INFO - 2023-07-11 08:53:08 --> Router Class Initialized
INFO - 2023-07-11 08:53:08 --> Output Class Initialized
INFO - 2023-07-11 08:53:08 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:08 --> Input Class Initialized
INFO - 2023-07-11 08:53:08 --> Language Class Initialized
ERROR - 2023-07-11 08:53:08 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:43 --> Config Class Initialized
INFO - 2023-07-11 08:53:43 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:43 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:43 --> URI Class Initialized
INFO - 2023-07-11 08:53:43 --> Router Class Initialized
INFO - 2023-07-11 08:53:43 --> Output Class Initialized
INFO - 2023-07-11 08:53:43 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:43 --> Input Class Initialized
INFO - 2023-07-11 08:53:43 --> Language Class Initialized
INFO - 2023-07-11 08:53:43 --> Loader Class Initialized
INFO - 2023-07-11 08:53:43 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:43 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:43 --> Controller Class Initialized
INFO - 2023-07-11 08:53:43 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:43 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:43 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:43 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:43 --> Total execution time: 0.0617
INFO - 2023-07-11 08:53:43 --> Config Class Initialized
INFO - 2023-07-11 08:53:43 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:43 --> Config Class Initialized
INFO - 2023-07-11 08:53:43 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:43 --> Utf8 Class Initialized
DEBUG - 2023-07-11 08:53:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:43 --> URI Class Initialized
INFO - 2023-07-11 08:53:43 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:43 --> URI Class Initialized
INFO - 2023-07-11 08:53:43 --> Router Class Initialized
INFO - 2023-07-11 08:53:43 --> Router Class Initialized
INFO - 2023-07-11 08:53:43 --> Output Class Initialized
INFO - 2023-07-11 08:53:43 --> Output Class Initialized
INFO - 2023-07-11 08:53:43 --> Security Class Initialized
INFO - 2023-07-11 08:53:43 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 08:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:43 --> Input Class Initialized
INFO - 2023-07-11 08:53:43 --> Input Class Initialized
INFO - 2023-07-11 08:53:43 --> Language Class Initialized
INFO - 2023-07-11 08:53:43 --> Language Class Initialized
ERROR - 2023-07-11 08:53:43 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 08:53:43 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:43 --> Config Class Initialized
INFO - 2023-07-11 08:53:43 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:43 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:43 --> URI Class Initialized
INFO - 2023-07-11 08:53:43 --> Router Class Initialized
INFO - 2023-07-11 08:53:43 --> Output Class Initialized
INFO - 2023-07-11 08:53:43 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:43 --> Input Class Initialized
INFO - 2023-07-11 08:53:43 --> Language Class Initialized
ERROR - 2023-07-11 08:53:43 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:44 --> Config Class Initialized
INFO - 2023-07-11 08:53:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:44 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:44 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
INFO - 2023-07-11 08:53:45 --> Loader Class Initialized
INFO - 2023-07-11 08:53:45 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:45 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:45 --> Controller Class Initialized
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:45 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:45 --> Total execution time: 0.0643
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
INFO - 2023-07-11 08:53:45 --> Loader Class Initialized
INFO - 2023-07-11 08:53:45 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:45 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:45 --> Controller Class Initialized
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:45 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:45 --> Total execution time: 0.0630
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
INFO - 2023-07-11 08:53:45 --> Loader Class Initialized
INFO - 2023-07-11 08:53:45 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:45 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:45 --> Controller Class Initialized
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:45 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:45 --> Total execution time: 0.0561
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
ERROR - 2023-07-11 08:53:45 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:45 --> Config Class Initialized
INFO - 2023-07-11 08:53:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:45 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:45 --> URI Class Initialized
INFO - 2023-07-11 08:53:45 --> Router Class Initialized
INFO - 2023-07-11 08:53:45 --> Output Class Initialized
INFO - 2023-07-11 08:53:45 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:45 --> Input Class Initialized
INFO - 2023-07-11 08:53:45 --> Language Class Initialized
INFO - 2023-07-11 08:53:45 --> Loader Class Initialized
INFO - 2023-07-11 08:53:45 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:45 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:45 --> Controller Class Initialized
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:45 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:46 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:46 --> Total execution time: 0.0647
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
INFO - 2023-07-11 08:53:46 --> Loader Class Initialized
INFO - 2023-07-11 08:53:46 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:46 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:46 --> Controller Class Initialized
INFO - 2023-07-11 08:53:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:46 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:46 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:46 --> Total execution time: 0.0635
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
INFO - 2023-07-11 08:53:46 --> Loader Class Initialized
INFO - 2023-07-11 08:53:46 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:46 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:46 --> Controller Class Initialized
INFO - 2023-07-11 08:53:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:46 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:46 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:46 --> Total execution time: 0.0657
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:46 --> Config Class Initialized
INFO - 2023-07-11 08:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:46 --> URI Class Initialized
INFO - 2023-07-11 08:53:46 --> Router Class Initialized
INFO - 2023-07-11 08:53:46 --> Output Class Initialized
INFO - 2023-07-11 08:53:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:46 --> Input Class Initialized
INFO - 2023-07-11 08:53:46 --> Language Class Initialized
ERROR - 2023-07-11 08:53:46 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
INFO - 2023-07-11 08:53:47 --> Loader Class Initialized
INFO - 2023-07-11 08:53:47 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:47 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:47 --> Controller Class Initialized
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:47 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:47 --> Total execution time: 0.0614
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
INFO - 2023-07-11 08:53:47 --> Loader Class Initialized
INFO - 2023-07-11 08:53:47 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:47 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:47 --> Controller Class Initialized
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:47 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:47 --> Total execution time: 0.0624
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
INFO - 2023-07-11 08:53:47 --> Loader Class Initialized
INFO - 2023-07-11 08:53:47 --> Helper loaded: url_helper
INFO - 2023-07-11 08:53:47 --> Database Driver Class Initialized
INFO - 2023-07-11 08:53:47 --> Controller Class Initialized
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:53:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:53:47 --> Final output sent to browser
DEBUG - 2023-07-11 08:53:47 --> Total execution time: 0.0596
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:53:47 --> Config Class Initialized
INFO - 2023-07-11 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:47 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:47 --> URI Class Initialized
INFO - 2023-07-11 08:53:47 --> Router Class Initialized
INFO - 2023-07-11 08:53:47 --> Output Class Initialized
INFO - 2023-07-11 08:53:47 --> Security Class Initialized
DEBUG - 2023-07-11 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:47 --> Input Class Initialized
INFO - 2023-07-11 08:53:47 --> Language Class Initialized
ERROR - 2023-07-11 08:53:47 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:53:52 --> Config Class Initialized
INFO - 2023-07-11 08:53:52 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:52 --> Config Class Initialized
DEBUG - 2023-07-11 08:53:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:52 --> Hooks Class Initialized
INFO - 2023-07-11 08:53:52 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:52 --> URI Class Initialized
DEBUG - 2023-07-11 08:53:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:53:52 --> Router Class Initialized
INFO - 2023-07-11 08:53:52 --> Utf8 Class Initialized
INFO - 2023-07-11 08:53:52 --> URI Class Initialized
INFO - 2023-07-11 08:53:52 --> Output Class Initialized
INFO - 2023-07-11 08:53:52 --> Router Class Initialized
INFO - 2023-07-11 08:53:52 --> Security Class Initialized
INFO - 2023-07-11 08:53:52 --> Output Class Initialized
DEBUG - 2023-07-11 08:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:53:52 --> Input Class Initialized
INFO - 2023-07-11 08:53:52 --> Security Class Initialized
INFO - 2023-07-11 08:53:52 --> Language Class Initialized
DEBUG - 2023-07-11 08:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 08:53:52 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:53:52 --> Input Class Initialized
INFO - 2023-07-11 08:53:52 --> Language Class Initialized
ERROR - 2023-07-11 08:53:52 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:54:46 --> Config Class Initialized
INFO - 2023-07-11 08:54:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:54:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:54:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:54:46 --> URI Class Initialized
INFO - 2023-07-11 08:54:46 --> Router Class Initialized
INFO - 2023-07-11 08:54:46 --> Output Class Initialized
INFO - 2023-07-11 08:54:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:54:46 --> Input Class Initialized
INFO - 2023-07-11 08:54:46 --> Language Class Initialized
INFO - 2023-07-11 08:54:46 --> Loader Class Initialized
INFO - 2023-07-11 08:54:46 --> Helper loaded: url_helper
INFO - 2023-07-11 08:54:46 --> Database Driver Class Initialized
INFO - 2023-07-11 08:54:46 --> Controller Class Initialized
INFO - 2023-07-11 08:54:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:54:46 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:54:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:54:46 --> Final output sent to browser
DEBUG - 2023-07-11 08:54:46 --> Total execution time: 0.0632
INFO - 2023-07-11 08:54:46 --> Config Class Initialized
INFO - 2023-07-11 08:54:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:54:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:54:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:54:46 --> URI Class Initialized
INFO - 2023-07-11 08:54:46 --> Router Class Initialized
INFO - 2023-07-11 08:54:46 --> Output Class Initialized
INFO - 2023-07-11 08:54:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:54:46 --> Input Class Initialized
INFO - 2023-07-11 08:54:46 --> Language Class Initialized
ERROR - 2023-07-11 08:54:46 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:54:46 --> Config Class Initialized
INFO - 2023-07-11 08:54:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:54:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:54:46 --> Utf8 Class Initialized
INFO - 2023-07-11 08:54:46 --> URI Class Initialized
INFO - 2023-07-11 08:54:46 --> Router Class Initialized
INFO - 2023-07-11 08:54:46 --> Output Class Initialized
INFO - 2023-07-11 08:54:46 --> Security Class Initialized
DEBUG - 2023-07-11 08:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:54:46 --> Input Class Initialized
INFO - 2023-07-11 08:54:46 --> Language Class Initialized
ERROR - 2023-07-11 08:54:46 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:54:54 --> Config Class Initialized
INFO - 2023-07-11 08:54:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:54:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:54:54 --> Utf8 Class Initialized
INFO - 2023-07-11 08:54:54 --> URI Class Initialized
INFO - 2023-07-11 08:54:54 --> Router Class Initialized
INFO - 2023-07-11 08:54:54 --> Output Class Initialized
INFO - 2023-07-11 08:54:54 --> Security Class Initialized
DEBUG - 2023-07-11 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:54:54 --> Input Class Initialized
INFO - 2023-07-11 08:54:54 --> Language Class Initialized
INFO - 2023-07-11 08:54:54 --> Loader Class Initialized
INFO - 2023-07-11 08:54:54 --> Helper loaded: url_helper
INFO - 2023-07-11 08:54:54 --> Database Driver Class Initialized
INFO - 2023-07-11 08:54:54 --> Controller Class Initialized
INFO - 2023-07-11 08:54:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:54:54 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:54:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:54:54 --> Final output sent to browser
DEBUG - 2023-07-11 08:54:54 --> Total execution time: 0.0550
INFO - 2023-07-11 08:54:54 --> Config Class Initialized
INFO - 2023-07-11 08:54:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:54:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:54:54 --> Utf8 Class Initialized
INFO - 2023-07-11 08:54:54 --> URI Class Initialized
INFO - 2023-07-11 08:54:54 --> Router Class Initialized
INFO - 2023-07-11 08:54:54 --> Output Class Initialized
INFO - 2023-07-11 08:54:54 --> Security Class Initialized
DEBUG - 2023-07-11 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:54:54 --> Input Class Initialized
INFO - 2023-07-11 08:54:54 --> Language Class Initialized
ERROR - 2023-07-11 08:54:54 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:54:54 --> Config Class Initialized
INFO - 2023-07-11 08:54:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:54:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:54:54 --> Utf8 Class Initialized
INFO - 2023-07-11 08:54:54 --> URI Class Initialized
INFO - 2023-07-11 08:54:54 --> Router Class Initialized
INFO - 2023-07-11 08:54:54 --> Output Class Initialized
INFO - 2023-07-11 08:54:54 --> Security Class Initialized
DEBUG - 2023-07-11 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:54:54 --> Input Class Initialized
INFO - 2023-07-11 08:54:54 --> Language Class Initialized
ERROR - 2023-07-11 08:54:54 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:55:02 --> Config Class Initialized
INFO - 2023-07-11 08:55:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:02 --> URI Class Initialized
INFO - 2023-07-11 08:55:02 --> Router Class Initialized
INFO - 2023-07-11 08:55:02 --> Output Class Initialized
INFO - 2023-07-11 08:55:02 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:02 --> Input Class Initialized
INFO - 2023-07-11 08:55:02 --> Language Class Initialized
INFO - 2023-07-11 08:55:02 --> Loader Class Initialized
INFO - 2023-07-11 08:55:02 --> Helper loaded: url_helper
INFO - 2023-07-11 08:55:02 --> Database Driver Class Initialized
INFO - 2023-07-11 08:55:02 --> Controller Class Initialized
INFO - 2023-07-11 08:55:02 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:55:02 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:55:02 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:55:02 --> Final output sent to browser
DEBUG - 2023-07-11 08:55:02 --> Total execution time: 0.0571
INFO - 2023-07-11 08:55:02 --> Config Class Initialized
INFO - 2023-07-11 08:55:02 --> Hooks Class Initialized
INFO - 2023-07-11 08:55:02 --> Config Class Initialized
INFO - 2023-07-11 08:55:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:02 --> URI Class Initialized
DEBUG - 2023-07-11 08:55:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:02 --> Router Class Initialized
INFO - 2023-07-11 08:55:02 --> URI Class Initialized
INFO - 2023-07-11 08:55:02 --> Output Class Initialized
INFO - 2023-07-11 08:55:02 --> Router Class Initialized
INFO - 2023-07-11 08:55:02 --> Security Class Initialized
INFO - 2023-07-11 08:55:02 --> Output Class Initialized
DEBUG - 2023-07-11 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:02 --> Input Class Initialized
INFO - 2023-07-11 08:55:02 --> Language Class Initialized
INFO - 2023-07-11 08:55:02 --> Security Class Initialized
ERROR - 2023-07-11 08:55:02 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:02 --> Input Class Initialized
INFO - 2023-07-11 08:55:02 --> Language Class Initialized
ERROR - 2023-07-11 08:55:02 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:55:02 --> Config Class Initialized
INFO - 2023-07-11 08:55:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:02 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:02 --> URI Class Initialized
INFO - 2023-07-11 08:55:02 --> Router Class Initialized
INFO - 2023-07-11 08:55:02 --> Output Class Initialized
INFO - 2023-07-11 08:55:02 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:02 --> Input Class Initialized
INFO - 2023-07-11 08:55:02 --> Language Class Initialized
ERROR - 2023-07-11 08:55:02 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 08:55:06 --> Config Class Initialized
INFO - 2023-07-11 08:55:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:06 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:06 --> URI Class Initialized
INFO - 2023-07-11 08:55:06 --> Router Class Initialized
INFO - 2023-07-11 08:55:06 --> Output Class Initialized
INFO - 2023-07-11 08:55:06 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:06 --> Input Class Initialized
INFO - 2023-07-11 08:55:06 --> Language Class Initialized
INFO - 2023-07-11 08:55:06 --> Loader Class Initialized
INFO - 2023-07-11 08:55:06 --> Helper loaded: url_helper
INFO - 2023-07-11 08:55:06 --> Database Driver Class Initialized
INFO - 2023-07-11 08:55:06 --> Controller Class Initialized
INFO - 2023-07-11 08:55:06 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:55:06 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 08:55:06 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:55:06 --> Final output sent to browser
DEBUG - 2023-07-11 08:55:06 --> Total execution time: 0.0565
INFO - 2023-07-11 08:55:06 --> Config Class Initialized
INFO - 2023-07-11 08:55:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:06 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:06 --> URI Class Initialized
INFO - 2023-07-11 08:55:06 --> Router Class Initialized
INFO - 2023-07-11 08:55:06 --> Output Class Initialized
INFO - 2023-07-11 08:55:06 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:06 --> Input Class Initialized
INFO - 2023-07-11 08:55:06 --> Language Class Initialized
ERROR - 2023-07-11 08:55:06 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:55:06 --> Config Class Initialized
INFO - 2023-07-11 08:55:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:06 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:06 --> URI Class Initialized
INFO - 2023-07-11 08:55:06 --> Router Class Initialized
INFO - 2023-07-11 08:55:06 --> Output Class Initialized
INFO - 2023-07-11 08:55:06 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:06 --> Input Class Initialized
INFO - 2023-07-11 08:55:06 --> Language Class Initialized
ERROR - 2023-07-11 08:55:06 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:55:09 --> Config Class Initialized
INFO - 2023-07-11 08:55:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:09 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:09 --> URI Class Initialized
INFO - 2023-07-11 08:55:09 --> Router Class Initialized
INFO - 2023-07-11 08:55:09 --> Output Class Initialized
INFO - 2023-07-11 08:55:09 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:09 --> Input Class Initialized
INFO - 2023-07-11 08:55:09 --> Language Class Initialized
INFO - 2023-07-11 08:55:09 --> Loader Class Initialized
INFO - 2023-07-11 08:55:09 --> Helper loaded: url_helper
INFO - 2023-07-11 08:55:09 --> Database Driver Class Initialized
INFO - 2023-07-11 08:55:09 --> Controller Class Initialized
INFO - 2023-07-11 08:55:09 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:55:09 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 08:55:09 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:55:09 --> Final output sent to browser
DEBUG - 2023-07-11 08:55:09 --> Total execution time: 0.0555
INFO - 2023-07-11 08:55:09 --> Config Class Initialized
INFO - 2023-07-11 08:55:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:09 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:09 --> URI Class Initialized
INFO - 2023-07-11 08:55:09 --> Router Class Initialized
INFO - 2023-07-11 08:55:09 --> Output Class Initialized
INFO - 2023-07-11 08:55:09 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:09 --> Input Class Initialized
INFO - 2023-07-11 08:55:09 --> Language Class Initialized
ERROR - 2023-07-11 08:55:09 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 08:55:09 --> Config Class Initialized
INFO - 2023-07-11 08:55:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:09 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:09 --> URI Class Initialized
INFO - 2023-07-11 08:55:09 --> Router Class Initialized
INFO - 2023-07-11 08:55:09 --> Output Class Initialized
INFO - 2023-07-11 08:55:09 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:09 --> Input Class Initialized
INFO - 2023-07-11 08:55:09 --> Language Class Initialized
ERROR - 2023-07-11 08:55:09 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 08:55:21 --> Config Class Initialized
INFO - 2023-07-11 08:55:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:21 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:21 --> URI Class Initialized
INFO - 2023-07-11 08:55:21 --> Router Class Initialized
INFO - 2023-07-11 08:55:21 --> Output Class Initialized
INFO - 2023-07-11 08:55:21 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:21 --> Input Class Initialized
INFO - 2023-07-11 08:55:21 --> Language Class Initialized
INFO - 2023-07-11 08:55:21 --> Loader Class Initialized
INFO - 2023-07-11 08:55:21 --> Helper loaded: url_helper
INFO - 2023-07-11 08:55:21 --> Database Driver Class Initialized
INFO - 2023-07-11 08:55:21 --> Controller Class Initialized
INFO - 2023-07-11 08:55:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 08:55:21 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 08:55:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 08:55:21 --> Final output sent to browser
DEBUG - 2023-07-11 08:55:21 --> Total execution time: 0.0593
INFO - 2023-07-11 08:55:21 --> Config Class Initialized
INFO - 2023-07-11 08:55:21 --> Hooks Class Initialized
INFO - 2023-07-11 08:55:21 --> Config Class Initialized
INFO - 2023-07-11 08:55:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:21 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:21 --> URI Class Initialized
DEBUG - 2023-07-11 08:55:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:21 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:21 --> Router Class Initialized
INFO - 2023-07-11 08:55:21 --> URI Class Initialized
INFO - 2023-07-11 08:55:21 --> Output Class Initialized
INFO - 2023-07-11 08:55:21 --> Router Class Initialized
INFO - 2023-07-11 08:55:21 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:21 --> Input Class Initialized
INFO - 2023-07-11 08:55:21 --> Output Class Initialized
INFO - 2023-07-11 08:55:21 --> Language Class Initialized
INFO - 2023-07-11 08:55:21 --> Security Class Initialized
ERROR - 2023-07-11 08:55:21 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:21 --> Input Class Initialized
INFO - 2023-07-11 08:55:21 --> Language Class Initialized
ERROR - 2023-07-11 08:55:21 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 08:55:21 --> Config Class Initialized
INFO - 2023-07-11 08:55:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 08:55:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 08:55:21 --> Utf8 Class Initialized
INFO - 2023-07-11 08:55:21 --> URI Class Initialized
INFO - 2023-07-11 08:55:21 --> Router Class Initialized
INFO - 2023-07-11 08:55:21 --> Output Class Initialized
INFO - 2023-07-11 08:55:21 --> Security Class Initialized
DEBUG - 2023-07-11 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 08:55:21 --> Input Class Initialized
INFO - 2023-07-11 08:55:21 --> Language Class Initialized
ERROR - 2023-07-11 08:55:21 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 09:01:06 --> Config Class Initialized
INFO - 2023-07-11 09:01:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:01:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:01:06 --> Utf8 Class Initialized
INFO - 2023-07-11 09:01:06 --> URI Class Initialized
INFO - 2023-07-11 09:01:06 --> Router Class Initialized
INFO - 2023-07-11 09:01:06 --> Output Class Initialized
INFO - 2023-07-11 09:01:06 --> Security Class Initialized
DEBUG - 2023-07-11 09:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:01:07 --> Input Class Initialized
INFO - 2023-07-11 09:01:07 --> Language Class Initialized
INFO - 2023-07-11 09:01:07 --> Loader Class Initialized
INFO - 2023-07-11 09:01:07 --> Helper loaded: url_helper
INFO - 2023-07-11 09:01:07 --> Database Driver Class Initialized
INFO - 2023-07-11 09:01:07 --> Controller Class Initialized
INFO - 2023-07-11 09:01:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:01:07 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:01:07 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:01:07 --> Final output sent to browser
DEBUG - 2023-07-11 09:01:07 --> Total execution time: 0.1048
INFO - 2023-07-11 09:01:07 --> Config Class Initialized
INFO - 2023-07-11 09:01:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:01:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:01:07 --> Utf8 Class Initialized
INFO - 2023-07-11 09:01:07 --> URI Class Initialized
INFO - 2023-07-11 09:01:07 --> Router Class Initialized
INFO - 2023-07-11 09:01:07 --> Output Class Initialized
INFO - 2023-07-11 09:01:07 --> Security Class Initialized
DEBUG - 2023-07-11 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:01:07 --> Input Class Initialized
INFO - 2023-07-11 09:01:07 --> Language Class Initialized
ERROR - 2023-07-11 09:01:07 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:01:07 --> Config Class Initialized
INFO - 2023-07-11 09:01:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:01:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:01:07 --> Utf8 Class Initialized
INFO - 2023-07-11 09:01:07 --> URI Class Initialized
INFO - 2023-07-11 09:01:07 --> Router Class Initialized
INFO - 2023-07-11 09:01:07 --> Output Class Initialized
INFO - 2023-07-11 09:01:07 --> Security Class Initialized
DEBUG - 2023-07-11 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:01:07 --> Input Class Initialized
INFO - 2023-07-11 09:01:07 --> Language Class Initialized
ERROR - 2023-07-11 09:01:07 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:01:23 --> Config Class Initialized
INFO - 2023-07-11 09:01:23 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:01:23 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:01:23 --> Utf8 Class Initialized
INFO - 2023-07-11 09:01:23 --> URI Class Initialized
INFO - 2023-07-11 09:01:23 --> Router Class Initialized
INFO - 2023-07-11 09:01:23 --> Output Class Initialized
INFO - 2023-07-11 09:01:23 --> Security Class Initialized
DEBUG - 2023-07-11 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:01:23 --> Input Class Initialized
INFO - 2023-07-11 09:01:23 --> Language Class Initialized
INFO - 2023-07-11 09:01:23 --> Loader Class Initialized
INFO - 2023-07-11 09:01:23 --> Helper loaded: url_helper
INFO - 2023-07-11 09:01:23 --> Database Driver Class Initialized
INFO - 2023-07-11 09:01:23 --> Controller Class Initialized
INFO - 2023-07-11 09:01:23 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:01:23 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:01:23 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:01:23 --> Final output sent to browser
DEBUG - 2023-07-11 09:01:23 --> Total execution time: 0.0936
INFO - 2023-07-11 09:01:23 --> Config Class Initialized
INFO - 2023-07-11 09:01:23 --> Config Class Initialized
INFO - 2023-07-11 09:01:23 --> Hooks Class Initialized
INFO - 2023-07-11 09:01:23 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:01:23 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:01:23 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:01:23 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:01:23 --> Utf8 Class Initialized
INFO - 2023-07-11 09:01:23 --> URI Class Initialized
INFO - 2023-07-11 09:01:23 --> URI Class Initialized
INFO - 2023-07-11 09:01:23 --> Router Class Initialized
INFO - 2023-07-11 09:01:23 --> Router Class Initialized
INFO - 2023-07-11 09:01:23 --> Output Class Initialized
INFO - 2023-07-11 09:01:23 --> Output Class Initialized
INFO - 2023-07-11 09:01:23 --> Security Class Initialized
INFO - 2023-07-11 09:01:23 --> Security Class Initialized
DEBUG - 2023-07-11 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:01:23 --> Input Class Initialized
DEBUG - 2023-07-11 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:01:23 --> Input Class Initialized
INFO - 2023-07-11 09:01:23 --> Language Class Initialized
INFO - 2023-07-11 09:01:23 --> Language Class Initialized
ERROR - 2023-07-11 09:01:23 --> 404 Page Not Found: Indexjs/index
ERROR - 2023-07-11 09:01:23 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:03:46 --> Config Class Initialized
INFO - 2023-07-11 09:03:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:03:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:03:46 --> Utf8 Class Initialized
INFO - 2023-07-11 09:03:46 --> URI Class Initialized
INFO - 2023-07-11 09:03:46 --> Router Class Initialized
INFO - 2023-07-11 09:03:46 --> Output Class Initialized
INFO - 2023-07-11 09:03:46 --> Security Class Initialized
DEBUG - 2023-07-11 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:03:46 --> Input Class Initialized
INFO - 2023-07-11 09:03:46 --> Language Class Initialized
INFO - 2023-07-11 09:03:46 --> Loader Class Initialized
INFO - 2023-07-11 09:03:46 --> Helper loaded: url_helper
INFO - 2023-07-11 09:03:46 --> Database Driver Class Initialized
INFO - 2023-07-11 09:03:46 --> Controller Class Initialized
INFO - 2023-07-11 09:03:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:03:46 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:03:46 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:03:46 --> Final output sent to browser
DEBUG - 2023-07-11 09:03:46 --> Total execution time: 0.1078
INFO - 2023-07-11 09:03:46 --> Config Class Initialized
INFO - 2023-07-11 09:03:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:03:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:03:46 --> Utf8 Class Initialized
INFO - 2023-07-11 09:03:46 --> URI Class Initialized
INFO - 2023-07-11 09:03:46 --> Config Class Initialized
INFO - 2023-07-11 09:03:46 --> Hooks Class Initialized
INFO - 2023-07-11 09:03:46 --> Router Class Initialized
DEBUG - 2023-07-11 09:03:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:03:46 --> Utf8 Class Initialized
INFO - 2023-07-11 09:03:46 --> Output Class Initialized
INFO - 2023-07-11 09:03:46 --> URI Class Initialized
INFO - 2023-07-11 09:03:46 --> Router Class Initialized
INFO - 2023-07-11 09:03:46 --> Security Class Initialized
INFO - 2023-07-11 09:03:46 --> Output Class Initialized
DEBUG - 2023-07-11 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:03:46 --> Input Class Initialized
INFO - 2023-07-11 09:03:46 --> Language Class Initialized
INFO - 2023-07-11 09:03:46 --> Security Class Initialized
ERROR - 2023-07-11 09:03:46 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:03:46 --> Input Class Initialized
INFO - 2023-07-11 09:03:46 --> Language Class Initialized
ERROR - 2023-07-11 09:03:46 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:03:46 --> Config Class Initialized
INFO - 2023-07-11 09:03:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:03:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:03:46 --> Utf8 Class Initialized
INFO - 2023-07-11 09:03:46 --> URI Class Initialized
INFO - 2023-07-11 09:03:46 --> Router Class Initialized
INFO - 2023-07-11 09:03:46 --> Output Class Initialized
INFO - 2023-07-11 09:03:46 --> Security Class Initialized
DEBUG - 2023-07-11 09:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:03:47 --> Input Class Initialized
INFO - 2023-07-11 09:03:47 --> Language Class Initialized
ERROR - 2023-07-11 09:03:47 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 09:04:01 --> Config Class Initialized
INFO - 2023-07-11 09:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:01 --> URI Class Initialized
INFO - 2023-07-11 09:04:01 --> Router Class Initialized
INFO - 2023-07-11 09:04:01 --> Output Class Initialized
INFO - 2023-07-11 09:04:01 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:01 --> Input Class Initialized
INFO - 2023-07-11 09:04:01 --> Language Class Initialized
INFO - 2023-07-11 09:04:01 --> Loader Class Initialized
INFO - 2023-07-11 09:04:01 --> Helper loaded: url_helper
INFO - 2023-07-11 09:04:01 --> Database Driver Class Initialized
INFO - 2023-07-11 09:04:01 --> Controller Class Initialized
INFO - 2023-07-11 09:04:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:04:01 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:04:01 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:04:01 --> Final output sent to browser
DEBUG - 2023-07-11 09:04:01 --> Total execution time: 0.0883
INFO - 2023-07-11 09:04:01 --> Config Class Initialized
INFO - 2023-07-11 09:04:01 --> Hooks Class Initialized
INFO - 2023-07-11 09:04:01 --> Config Class Initialized
INFO - 2023-07-11 09:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:01 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:01 --> URI Class Initialized
INFO - 2023-07-11 09:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:01 --> URI Class Initialized
INFO - 2023-07-11 09:04:01 --> Router Class Initialized
INFO - 2023-07-11 09:04:01 --> Router Class Initialized
INFO - 2023-07-11 09:04:01 --> Output Class Initialized
INFO - 2023-07-11 09:04:01 --> Output Class Initialized
INFO - 2023-07-11 09:04:01 --> Security Class Initialized
INFO - 2023-07-11 09:04:01 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:01 --> Input Class Initialized
DEBUG - 2023-07-11 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:01 --> Input Class Initialized
INFO - 2023-07-11 09:04:01 --> Language Class Initialized
INFO - 2023-07-11 09:04:01 --> Language Class Initialized
ERROR - 2023-07-11 09:04:01 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 09:04:01 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:04:01 --> Config Class Initialized
INFO - 2023-07-11 09:04:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:01 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:01 --> URI Class Initialized
INFO - 2023-07-11 09:04:01 --> Router Class Initialized
INFO - 2023-07-11 09:04:01 --> Output Class Initialized
INFO - 2023-07-11 09:04:01 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:01 --> Input Class Initialized
INFO - 2023-07-11 09:04:01 --> Language Class Initialized
ERROR - 2023-07-11 09:04:01 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 09:04:19 --> Config Class Initialized
INFO - 2023-07-11 09:04:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:19 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:19 --> URI Class Initialized
INFO - 2023-07-11 09:04:19 --> Router Class Initialized
INFO - 2023-07-11 09:04:19 --> Output Class Initialized
INFO - 2023-07-11 09:04:19 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:19 --> Input Class Initialized
INFO - 2023-07-11 09:04:19 --> Language Class Initialized
INFO - 2023-07-11 09:04:19 --> Loader Class Initialized
INFO - 2023-07-11 09:04:19 --> Helper loaded: url_helper
INFO - 2023-07-11 09:04:19 --> Database Driver Class Initialized
INFO - 2023-07-11 09:04:19 --> Controller Class Initialized
INFO - 2023-07-11 09:04:19 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:04:19 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:04:19 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:04:19 --> Final output sent to browser
DEBUG - 2023-07-11 09:04:19 --> Total execution time: 0.0995
INFO - 2023-07-11 09:04:19 --> Config Class Initialized
INFO - 2023-07-11 09:04:19 --> Hooks Class Initialized
INFO - 2023-07-11 09:04:19 --> Config Class Initialized
INFO - 2023-07-11 09:04:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:19 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:19 --> URI Class Initialized
DEBUG - 2023-07-11 09:04:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:19 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:19 --> Router Class Initialized
INFO - 2023-07-11 09:04:19 --> URI Class Initialized
INFO - 2023-07-11 09:04:19 --> Output Class Initialized
INFO - 2023-07-11 09:04:19 --> Router Class Initialized
INFO - 2023-07-11 09:04:19 --> Security Class Initialized
INFO - 2023-07-11 09:04:19 --> Output Class Initialized
DEBUG - 2023-07-11 09:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:19 --> Input Class Initialized
INFO - 2023-07-11 09:04:19 --> Security Class Initialized
INFO - 2023-07-11 09:04:19 --> Language Class Initialized
ERROR - 2023-07-11 09:04:19 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 09:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:19 --> Input Class Initialized
INFO - 2023-07-11 09:04:19 --> Language Class Initialized
ERROR - 2023-07-11 09:04:19 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:04:19 --> Config Class Initialized
INFO - 2023-07-11 09:04:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:19 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:19 --> URI Class Initialized
INFO - 2023-07-11 09:04:19 --> Router Class Initialized
INFO - 2023-07-11 09:04:19 --> Output Class Initialized
INFO - 2023-07-11 09:04:19 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:19 --> Input Class Initialized
INFO - 2023-07-11 09:04:19 --> Language Class Initialized
ERROR - 2023-07-11 09:04:19 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:04:37 --> Config Class Initialized
INFO - 2023-07-11 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:37 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:37 --> URI Class Initialized
INFO - 2023-07-11 09:04:37 --> Router Class Initialized
INFO - 2023-07-11 09:04:37 --> Output Class Initialized
INFO - 2023-07-11 09:04:37 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:37 --> Input Class Initialized
INFO - 2023-07-11 09:04:37 --> Language Class Initialized
INFO - 2023-07-11 09:04:37 --> Loader Class Initialized
INFO - 2023-07-11 09:04:37 --> Helper loaded: url_helper
INFO - 2023-07-11 09:04:37 --> Database Driver Class Initialized
INFO - 2023-07-11 09:04:37 --> Controller Class Initialized
INFO - 2023-07-11 09:04:37 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:04:37 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:04:37 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:04:37 --> Final output sent to browser
DEBUG - 2023-07-11 09:04:37 --> Total execution time: 0.0851
INFO - 2023-07-11 09:04:37 --> Config Class Initialized
INFO - 2023-07-11 09:04:37 --> Hooks Class Initialized
INFO - 2023-07-11 09:04:37 --> Config Class Initialized
DEBUG - 2023-07-11 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:37 --> Hooks Class Initialized
INFO - 2023-07-11 09:04:37 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:37 --> URI Class Initialized
INFO - 2023-07-11 09:04:37 --> Router Class Initialized
DEBUG - 2023-07-11 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:37 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:37 --> URI Class Initialized
INFO - 2023-07-11 09:04:37 --> Output Class Initialized
INFO - 2023-07-11 09:04:37 --> Security Class Initialized
INFO - 2023-07-11 09:04:37 --> Router Class Initialized
DEBUG - 2023-07-11 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:37 --> Output Class Initialized
INFO - 2023-07-11 09:04:37 --> Input Class Initialized
INFO - 2023-07-11 09:04:37 --> Language Class Initialized
ERROR - 2023-07-11 09:04:37 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:04:37 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:37 --> Input Class Initialized
INFO - 2023-07-11 09:04:37 --> Language Class Initialized
ERROR - 2023-07-11 09:04:37 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:04:37 --> Config Class Initialized
INFO - 2023-07-11 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:37 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:37 --> URI Class Initialized
INFO - 2023-07-11 09:04:37 --> Router Class Initialized
INFO - 2023-07-11 09:04:37 --> Output Class Initialized
INFO - 2023-07-11 09:04:37 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:37 --> Input Class Initialized
INFO - 2023-07-11 09:04:37 --> Language Class Initialized
ERROR - 2023-07-11 09:04:37 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:04:54 --> Config Class Initialized
INFO - 2023-07-11 09:04:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:54 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:54 --> URI Class Initialized
INFO - 2023-07-11 09:04:54 --> Router Class Initialized
INFO - 2023-07-11 09:04:54 --> Output Class Initialized
INFO - 2023-07-11 09:04:54 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:54 --> Input Class Initialized
INFO - 2023-07-11 09:04:54 --> Language Class Initialized
INFO - 2023-07-11 09:04:54 --> Loader Class Initialized
INFO - 2023-07-11 09:04:54 --> Helper loaded: url_helper
INFO - 2023-07-11 09:04:54 --> Database Driver Class Initialized
INFO - 2023-07-11 09:04:54 --> Controller Class Initialized
INFO - 2023-07-11 09:04:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:04:54 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:04:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:04:54 --> Final output sent to browser
DEBUG - 2023-07-11 09:04:54 --> Total execution time: 0.0891
INFO - 2023-07-11 09:04:54 --> Config Class Initialized
INFO - 2023-07-11 09:04:54 --> Hooks Class Initialized
INFO - 2023-07-11 09:04:54 --> Config Class Initialized
INFO - 2023-07-11 09:04:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:54 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:54 --> URI Class Initialized
INFO - 2023-07-11 09:04:54 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:54 --> URI Class Initialized
INFO - 2023-07-11 09:04:54 --> Router Class Initialized
INFO - 2023-07-11 09:04:54 --> Router Class Initialized
INFO - 2023-07-11 09:04:54 --> Output Class Initialized
INFO - 2023-07-11 09:04:54 --> Output Class Initialized
INFO - 2023-07-11 09:04:54 --> Security Class Initialized
INFO - 2023-07-11 09:04:54 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 09:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:54 --> Input Class Initialized
INFO - 2023-07-11 09:04:54 --> Input Class Initialized
INFO - 2023-07-11 09:04:54 --> Language Class Initialized
INFO - 2023-07-11 09:04:54 --> Language Class Initialized
ERROR - 2023-07-11 09:04:54 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 09:04:54 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:04:54 --> Config Class Initialized
INFO - 2023-07-11 09:04:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:04:54 --> Utf8 Class Initialized
INFO - 2023-07-11 09:04:54 --> URI Class Initialized
INFO - 2023-07-11 09:04:54 --> Router Class Initialized
INFO - 2023-07-11 09:04:54 --> Output Class Initialized
INFO - 2023-07-11 09:04:54 --> Security Class Initialized
DEBUG - 2023-07-11 09:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:04:54 --> Input Class Initialized
INFO - 2023-07-11 09:04:54 --> Language Class Initialized
ERROR - 2023-07-11 09:04:54 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:06:18 --> Config Class Initialized
INFO - 2023-07-11 09:06:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:18 --> URI Class Initialized
INFO - 2023-07-11 09:06:18 --> Router Class Initialized
INFO - 2023-07-11 09:06:18 --> Output Class Initialized
INFO - 2023-07-11 09:06:18 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:18 --> Input Class Initialized
INFO - 2023-07-11 09:06:18 --> Language Class Initialized
INFO - 2023-07-11 09:06:18 --> Loader Class Initialized
INFO - 2023-07-11 09:06:18 --> Helper loaded: url_helper
INFO - 2023-07-11 09:06:18 --> Database Driver Class Initialized
INFO - 2023-07-11 09:06:18 --> Controller Class Initialized
INFO - 2023-07-11 09:06:18 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:06:18 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:06:18 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:06:18 --> Final output sent to browser
DEBUG - 2023-07-11 09:06:18 --> Total execution time: 0.0984
INFO - 2023-07-11 09:06:18 --> Config Class Initialized
INFO - 2023-07-11 09:06:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:18 --> Config Class Initialized
INFO - 2023-07-11 09:06:18 --> Hooks Class Initialized
INFO - 2023-07-11 09:06:18 --> URI Class Initialized
DEBUG - 2023-07-11 09:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:18 --> Router Class Initialized
INFO - 2023-07-11 09:06:18 --> URI Class Initialized
INFO - 2023-07-11 09:06:18 --> Output Class Initialized
INFO - 2023-07-11 09:06:18 --> Router Class Initialized
INFO - 2023-07-11 09:06:18 --> Security Class Initialized
INFO - 2023-07-11 09:06:18 --> Output Class Initialized
INFO - 2023-07-11 09:06:18 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:18 --> Input Class Initialized
INFO - 2023-07-11 09:06:18 --> Language Class Initialized
DEBUG - 2023-07-11 09:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:18 --> Input Class Initialized
INFO - 2023-07-11 09:06:18 --> Language Class Initialized
ERROR - 2023-07-11 09:06:18 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 09:06:18 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:06:18 --> Config Class Initialized
INFO - 2023-07-11 09:06:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:18 --> URI Class Initialized
INFO - 2023-07-11 09:06:18 --> Router Class Initialized
INFO - 2023-07-11 09:06:18 --> Output Class Initialized
INFO - 2023-07-11 09:06:18 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:18 --> Input Class Initialized
INFO - 2023-07-11 09:06:18 --> Language Class Initialized
ERROR - 2023-07-11 09:06:18 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:06:21 --> Config Class Initialized
INFO - 2023-07-11 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:21 --> URI Class Initialized
INFO - 2023-07-11 09:06:21 --> Router Class Initialized
INFO - 2023-07-11 09:06:21 --> Output Class Initialized
INFO - 2023-07-11 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:21 --> Input Class Initialized
INFO - 2023-07-11 09:06:21 --> Language Class Initialized
INFO - 2023-07-11 09:06:21 --> Loader Class Initialized
INFO - 2023-07-11 09:06:21 --> Helper loaded: url_helper
INFO - 2023-07-11 09:06:21 --> Database Driver Class Initialized
INFO - 2023-07-11 09:06:21 --> Controller Class Initialized
INFO - 2023-07-11 09:06:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:06:21 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:06:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:06:21 --> Final output sent to browser
DEBUG - 2023-07-11 09:06:21 --> Total execution time: 0.0665
INFO - 2023-07-11 09:06:21 --> Config Class Initialized
INFO - 2023-07-11 09:06:21 --> Hooks Class Initialized
INFO - 2023-07-11 09:06:21 --> Config Class Initialized
INFO - 2023-07-11 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:21 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:21 --> URI Class Initialized
INFO - 2023-07-11 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:21 --> URI Class Initialized
INFO - 2023-07-11 09:06:21 --> Router Class Initialized
INFO - 2023-07-11 09:06:21 --> Router Class Initialized
INFO - 2023-07-11 09:06:21 --> Output Class Initialized
INFO - 2023-07-11 09:06:21 --> Output Class Initialized
INFO - 2023-07-11 09:06:21 --> Security Class Initialized
INFO - 2023-07-11 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:21 --> Input Class Initialized
DEBUG - 2023-07-11 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:21 --> Input Class Initialized
INFO - 2023-07-11 09:06:21 --> Language Class Initialized
INFO - 2023-07-11 09:06:21 --> Language Class Initialized
ERROR - 2023-07-11 09:06:21 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 09:06:21 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:06:21 --> Config Class Initialized
INFO - 2023-07-11 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:21 --> URI Class Initialized
INFO - 2023-07-11 09:06:21 --> Router Class Initialized
INFO - 2023-07-11 09:06:21 --> Output Class Initialized
INFO - 2023-07-11 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:21 --> Input Class Initialized
INFO - 2023-07-11 09:06:21 --> Language Class Initialized
ERROR - 2023-07-11 09:06:21 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:06:30 --> Config Class Initialized
INFO - 2023-07-11 09:06:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:30 --> URI Class Initialized
INFO - 2023-07-11 09:06:30 --> Router Class Initialized
INFO - 2023-07-11 09:06:30 --> Output Class Initialized
INFO - 2023-07-11 09:06:30 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:30 --> Input Class Initialized
INFO - 2023-07-11 09:06:30 --> Language Class Initialized
INFO - 2023-07-11 09:06:30 --> Loader Class Initialized
INFO - 2023-07-11 09:06:30 --> Helper loaded: url_helper
INFO - 2023-07-11 09:06:30 --> Database Driver Class Initialized
INFO - 2023-07-11 09:06:30 --> Controller Class Initialized
INFO - 2023-07-11 09:06:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:06:31 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:06:31 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:06:31 --> Final output sent to browser
DEBUG - 2023-07-11 09:06:31 --> Total execution time: 0.0801
INFO - 2023-07-11 09:06:31 --> Config Class Initialized
INFO - 2023-07-11 09:06:31 --> Config Class Initialized
INFO - 2023-07-11 09:06:31 --> Hooks Class Initialized
INFO - 2023-07-11 09:06:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:31 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:06:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:31 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:31 --> URI Class Initialized
INFO - 2023-07-11 09:06:31 --> URI Class Initialized
INFO - 2023-07-11 09:06:31 --> Router Class Initialized
INFO - 2023-07-11 09:06:31 --> Router Class Initialized
INFO - 2023-07-11 09:06:31 --> Output Class Initialized
INFO - 2023-07-11 09:06:31 --> Output Class Initialized
INFO - 2023-07-11 09:06:31 --> Security Class Initialized
INFO - 2023-07-11 09:06:31 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:31 --> Input Class Initialized
INFO - 2023-07-11 09:06:31 --> Language Class Initialized
DEBUG - 2023-07-11 09:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:31 --> Input Class Initialized
INFO - 2023-07-11 09:06:31 --> Language Class Initialized
ERROR - 2023-07-11 09:06:31 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 09:06:31 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:06:31 --> Config Class Initialized
INFO - 2023-07-11 09:06:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:31 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:31 --> URI Class Initialized
INFO - 2023-07-11 09:06:31 --> Router Class Initialized
INFO - 2023-07-11 09:06:31 --> Output Class Initialized
INFO - 2023-07-11 09:06:31 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:31 --> Input Class Initialized
INFO - 2023-07-11 09:06:31 --> Language Class Initialized
ERROR - 2023-07-11 09:06:31 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:06:44 --> Config Class Initialized
INFO - 2023-07-11 09:06:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:44 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:44 --> URI Class Initialized
INFO - 2023-07-11 09:06:44 --> Router Class Initialized
INFO - 2023-07-11 09:06:44 --> Output Class Initialized
INFO - 2023-07-11 09:06:44 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:44 --> Input Class Initialized
INFO - 2023-07-11 09:06:44 --> Language Class Initialized
INFO - 2023-07-11 09:06:44 --> Loader Class Initialized
INFO - 2023-07-11 09:06:44 --> Helper loaded: url_helper
INFO - 2023-07-11 09:06:44 --> Database Driver Class Initialized
INFO - 2023-07-11 09:06:44 --> Controller Class Initialized
INFO - 2023-07-11 09:06:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:06:44 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:06:44 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:06:44 --> Final output sent to browser
DEBUG - 2023-07-11 09:06:44 --> Total execution time: 0.0827
INFO - 2023-07-11 09:06:44 --> Config Class Initialized
INFO - 2023-07-11 09:06:44 --> Hooks Class Initialized
INFO - 2023-07-11 09:06:44 --> Config Class Initialized
INFO - 2023-07-11 09:06:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:44 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:44 --> URI Class Initialized
DEBUG - 2023-07-11 09:06:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:44 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:44 --> Router Class Initialized
INFO - 2023-07-11 09:06:44 --> URI Class Initialized
INFO - 2023-07-11 09:06:44 --> Output Class Initialized
INFO - 2023-07-11 09:06:44 --> Router Class Initialized
INFO - 2023-07-11 09:06:44 --> Security Class Initialized
INFO - 2023-07-11 09:06:44 --> Output Class Initialized
DEBUG - 2023-07-11 09:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:44 --> Input Class Initialized
INFO - 2023-07-11 09:06:44 --> Security Class Initialized
INFO - 2023-07-11 09:06:44 --> Language Class Initialized
ERROR - 2023-07-11 09:06:44 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 09:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:44 --> Input Class Initialized
INFO - 2023-07-11 09:06:44 --> Language Class Initialized
ERROR - 2023-07-11 09:06:44 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:06:44 --> Config Class Initialized
INFO - 2023-07-11 09:06:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:06:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:06:44 --> Utf8 Class Initialized
INFO - 2023-07-11 09:06:44 --> URI Class Initialized
INFO - 2023-07-11 09:06:44 --> Router Class Initialized
INFO - 2023-07-11 09:06:44 --> Output Class Initialized
INFO - 2023-07-11 09:06:44 --> Security Class Initialized
DEBUG - 2023-07-11 09:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:06:44 --> Input Class Initialized
INFO - 2023-07-11 09:06:44 --> Language Class Initialized
ERROR - 2023-07-11 09:06:44 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:07:39 --> Config Class Initialized
INFO - 2023-07-11 09:07:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:07:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:39 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:39 --> URI Class Initialized
INFO - 2023-07-11 09:07:39 --> Router Class Initialized
INFO - 2023-07-11 09:07:39 --> Output Class Initialized
INFO - 2023-07-11 09:07:39 --> Security Class Initialized
DEBUG - 2023-07-11 09:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:39 --> Input Class Initialized
INFO - 2023-07-11 09:07:39 --> Language Class Initialized
INFO - 2023-07-11 09:07:39 --> Loader Class Initialized
INFO - 2023-07-11 09:07:39 --> Helper loaded: url_helper
INFO - 2023-07-11 09:07:39 --> Database Driver Class Initialized
INFO - 2023-07-11 09:07:39 --> Controller Class Initialized
INFO - 2023-07-11 09:07:39 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:07:39 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:07:39 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:07:39 --> Final output sent to browser
DEBUG - 2023-07-11 09:07:39 --> Total execution time: 0.0875
INFO - 2023-07-11 09:07:40 --> Config Class Initialized
INFO - 2023-07-11 09:07:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:07:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:40 --> Config Class Initialized
INFO - 2023-07-11 09:07:40 --> Hooks Class Initialized
INFO - 2023-07-11 09:07:40 --> URI Class Initialized
INFO - 2023-07-11 09:07:40 --> Router Class Initialized
DEBUG - 2023-07-11 09:07:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:40 --> Output Class Initialized
INFO - 2023-07-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:40 --> Security Class Initialized
INFO - 2023-07-11 09:07:40 --> URI Class Initialized
DEBUG - 2023-07-11 09:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:40 --> Input Class Initialized
INFO - 2023-07-11 09:07:40 --> Router Class Initialized
INFO - 2023-07-11 09:07:40 --> Language Class Initialized
INFO - 2023-07-11 09:07:40 --> Output Class Initialized
ERROR - 2023-07-11 09:07:40 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:07:40 --> Security Class Initialized
DEBUG - 2023-07-11 09:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:40 --> Input Class Initialized
INFO - 2023-07-11 09:07:40 --> Language Class Initialized
ERROR - 2023-07-11 09:07:40 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:07:40 --> Config Class Initialized
INFO - 2023-07-11 09:07:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:07:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:40 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:40 --> URI Class Initialized
INFO - 2023-07-11 09:07:40 --> Router Class Initialized
INFO - 2023-07-11 09:07:40 --> Output Class Initialized
INFO - 2023-07-11 09:07:40 --> Security Class Initialized
DEBUG - 2023-07-11 09:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:40 --> Input Class Initialized
INFO - 2023-07-11 09:07:40 --> Language Class Initialized
ERROR - 2023-07-11 09:07:40 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:07:53 --> Config Class Initialized
INFO - 2023-07-11 09:07:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:07:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:53 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:53 --> URI Class Initialized
INFO - 2023-07-11 09:07:53 --> Router Class Initialized
INFO - 2023-07-11 09:07:53 --> Output Class Initialized
INFO - 2023-07-11 09:07:53 --> Security Class Initialized
DEBUG - 2023-07-11 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:53 --> Input Class Initialized
INFO - 2023-07-11 09:07:53 --> Language Class Initialized
INFO - 2023-07-11 09:07:53 --> Loader Class Initialized
INFO - 2023-07-11 09:07:53 --> Helper loaded: url_helper
INFO - 2023-07-11 09:07:53 --> Database Driver Class Initialized
INFO - 2023-07-11 09:07:53 --> Controller Class Initialized
INFO - 2023-07-11 09:07:53 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:07:53 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:07:53 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:07:53 --> Final output sent to browser
DEBUG - 2023-07-11 09:07:53 --> Total execution time: 0.0626
INFO - 2023-07-11 09:07:53 --> Config Class Initialized
INFO - 2023-07-11 09:07:53 --> Hooks Class Initialized
INFO - 2023-07-11 09:07:53 --> Config Class Initialized
INFO - 2023-07-11 09:07:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:07:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:53 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:53 --> URI Class Initialized
INFO - 2023-07-11 09:07:53 --> Router Class Initialized
DEBUG - 2023-07-11 09:07:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:53 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:53 --> URI Class Initialized
INFO - 2023-07-11 09:07:53 --> Output Class Initialized
INFO - 2023-07-11 09:07:53 --> Router Class Initialized
INFO - 2023-07-11 09:07:53 --> Security Class Initialized
DEBUG - 2023-07-11 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:53 --> Output Class Initialized
INFO - 2023-07-11 09:07:53 --> Input Class Initialized
INFO - 2023-07-11 09:07:53 --> Language Class Initialized
INFO - 2023-07-11 09:07:53 --> Security Class Initialized
ERROR - 2023-07-11 09:07:53 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:53 --> Input Class Initialized
INFO - 2023-07-11 09:07:53 --> Language Class Initialized
ERROR - 2023-07-11 09:07:53 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:07:53 --> Config Class Initialized
INFO - 2023-07-11 09:07:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:07:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:07:53 --> Utf8 Class Initialized
INFO - 2023-07-11 09:07:53 --> URI Class Initialized
INFO - 2023-07-11 09:07:53 --> Router Class Initialized
INFO - 2023-07-11 09:07:53 --> Output Class Initialized
INFO - 2023-07-11 09:07:53 --> Security Class Initialized
DEBUG - 2023-07-11 09:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:07:53 --> Input Class Initialized
INFO - 2023-07-11 09:07:53 --> Language Class Initialized
ERROR - 2023-07-11 09:07:53 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:08:18 --> Config Class Initialized
INFO - 2023-07-11 09:08:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:08:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:08:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:08:18 --> URI Class Initialized
INFO - 2023-07-11 09:08:18 --> Router Class Initialized
INFO - 2023-07-11 09:08:18 --> Output Class Initialized
INFO - 2023-07-11 09:08:18 --> Security Class Initialized
DEBUG - 2023-07-11 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:08:18 --> Input Class Initialized
INFO - 2023-07-11 09:08:18 --> Language Class Initialized
INFO - 2023-07-11 09:08:18 --> Loader Class Initialized
INFO - 2023-07-11 09:08:18 --> Helper loaded: url_helper
INFO - 2023-07-11 09:08:18 --> Database Driver Class Initialized
INFO - 2023-07-11 09:08:18 --> Controller Class Initialized
INFO - 2023-07-11 09:08:18 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:08:18 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 09:08:18 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:08:18 --> Final output sent to browser
DEBUG - 2023-07-11 09:08:18 --> Total execution time: 0.0584
INFO - 2023-07-11 09:08:18 --> Config Class Initialized
INFO - 2023-07-11 09:08:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:08:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:08:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:08:18 --> Config Class Initialized
INFO - 2023-07-11 09:08:18 --> URI Class Initialized
INFO - 2023-07-11 09:08:18 --> Hooks Class Initialized
INFO - 2023-07-11 09:08:18 --> Router Class Initialized
DEBUG - 2023-07-11 09:08:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:08:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:08:18 --> Output Class Initialized
INFO - 2023-07-11 09:08:18 --> URI Class Initialized
INFO - 2023-07-11 09:08:18 --> Security Class Initialized
INFO - 2023-07-11 09:08:18 --> Router Class Initialized
DEBUG - 2023-07-11 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:08:18 --> Output Class Initialized
INFO - 2023-07-11 09:08:18 --> Input Class Initialized
INFO - 2023-07-11 09:08:18 --> Language Class Initialized
INFO - 2023-07-11 09:08:18 --> Security Class Initialized
ERROR - 2023-07-11 09:08:18 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:08:18 --> Input Class Initialized
INFO - 2023-07-11 09:08:18 --> Language Class Initialized
ERROR - 2023-07-11 09:08:18 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:08:18 --> Config Class Initialized
INFO - 2023-07-11 09:08:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:08:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:08:18 --> Utf8 Class Initialized
INFO - 2023-07-11 09:08:18 --> URI Class Initialized
INFO - 2023-07-11 09:08:18 --> Router Class Initialized
INFO - 2023-07-11 09:08:18 --> Output Class Initialized
INFO - 2023-07-11 09:08:18 --> Security Class Initialized
DEBUG - 2023-07-11 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:08:18 --> Input Class Initialized
INFO - 2023-07-11 09:08:18 --> Language Class Initialized
ERROR - 2023-07-11 09:08:18 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:08:25 --> Config Class Initialized
INFO - 2023-07-11 09:08:25 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:08:25 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:08:25 --> Utf8 Class Initialized
INFO - 2023-07-11 09:08:25 --> URI Class Initialized
INFO - 2023-07-11 09:08:25 --> Router Class Initialized
INFO - 2023-07-11 09:08:25 --> Output Class Initialized
INFO - 2023-07-11 09:08:25 --> Security Class Initialized
DEBUG - 2023-07-11 09:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:08:25 --> Input Class Initialized
INFO - 2023-07-11 09:08:25 --> Language Class Initialized
ERROR - 2023-07-11 09:08:25 --> 404 Page Not Found: About/index
INFO - 2023-07-11 09:09:39 --> Config Class Initialized
INFO - 2023-07-11 09:09:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:09:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:09:39 --> Utf8 Class Initialized
INFO - 2023-07-11 09:09:39 --> URI Class Initialized
INFO - 2023-07-11 09:09:39 --> Router Class Initialized
INFO - 2023-07-11 09:09:39 --> Output Class Initialized
INFO - 2023-07-11 09:09:39 --> Security Class Initialized
DEBUG - 2023-07-11 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:09:39 --> Input Class Initialized
INFO - 2023-07-11 09:09:39 --> Language Class Initialized
INFO - 2023-07-11 09:09:39 --> Loader Class Initialized
INFO - 2023-07-11 09:09:39 --> Helper loaded: url_helper
INFO - 2023-07-11 09:09:39 --> Database Driver Class Initialized
INFO - 2023-07-11 09:09:39 --> Controller Class Initialized
INFO - 2023-07-11 09:09:39 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:09:39 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 09:09:39 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:09:39 --> Final output sent to browser
DEBUG - 2023-07-11 09:09:39 --> Total execution time: 0.0638
INFO - 2023-07-11 09:09:39 --> Config Class Initialized
INFO - 2023-07-11 09:09:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:09:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:09:39 --> Utf8 Class Initialized
INFO - 2023-07-11 09:09:39 --> URI Class Initialized
INFO - 2023-07-11 09:09:39 --> Router Class Initialized
INFO - 2023-07-11 09:09:39 --> Config Class Initialized
INFO - 2023-07-11 09:09:39 --> Hooks Class Initialized
INFO - 2023-07-11 09:09:39 --> Output Class Initialized
DEBUG - 2023-07-11 09:09:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:09:39 --> Security Class Initialized
INFO - 2023-07-11 09:09:39 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:09:39 --> URI Class Initialized
INFO - 2023-07-11 09:09:39 --> Input Class Initialized
INFO - 2023-07-11 09:09:39 --> Language Class Initialized
INFO - 2023-07-11 09:09:39 --> Router Class Initialized
ERROR - 2023-07-11 09:09:39 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:09:39 --> Output Class Initialized
INFO - 2023-07-11 09:09:39 --> Security Class Initialized
DEBUG - 2023-07-11 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:09:39 --> Input Class Initialized
INFO - 2023-07-11 09:09:39 --> Language Class Initialized
ERROR - 2023-07-11 09:09:39 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:09:39 --> Config Class Initialized
INFO - 2023-07-11 09:09:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:09:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:09:39 --> Utf8 Class Initialized
INFO - 2023-07-11 09:09:39 --> URI Class Initialized
INFO - 2023-07-11 09:09:39 --> Router Class Initialized
INFO - 2023-07-11 09:09:39 --> Output Class Initialized
INFO - 2023-07-11 09:09:39 --> Security Class Initialized
DEBUG - 2023-07-11 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:09:39 --> Input Class Initialized
INFO - 2023-07-11 09:09:39 --> Language Class Initialized
ERROR - 2023-07-11 09:09:39 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:10:42 --> Config Class Initialized
INFO - 2023-07-11 09:10:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:10:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:10:42 --> Utf8 Class Initialized
INFO - 2023-07-11 09:10:42 --> URI Class Initialized
INFO - 2023-07-11 09:10:42 --> Router Class Initialized
INFO - 2023-07-11 09:10:43 --> Output Class Initialized
INFO - 2023-07-11 09:10:43 --> Security Class Initialized
DEBUG - 2023-07-11 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:10:43 --> Input Class Initialized
INFO - 2023-07-11 09:10:43 --> Language Class Initialized
INFO - 2023-07-11 09:10:43 --> Loader Class Initialized
INFO - 2023-07-11 09:10:43 --> Helper loaded: url_helper
INFO - 2023-07-11 09:10:43 --> Database Driver Class Initialized
INFO - 2023-07-11 09:10:43 --> Controller Class Initialized
INFO - 2023-07-11 09:10:43 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:10:43 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 09:10:43 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:10:43 --> Final output sent to browser
DEBUG - 2023-07-11 09:10:43 --> Total execution time: 0.0886
INFO - 2023-07-11 09:10:43 --> Config Class Initialized
INFO - 2023-07-11 09:10:43 --> Hooks Class Initialized
INFO - 2023-07-11 09:10:43 --> Config Class Initialized
INFO - 2023-07-11 09:10:43 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:10:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:10:43 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:10:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:10:43 --> Utf8 Class Initialized
INFO - 2023-07-11 09:10:43 --> URI Class Initialized
INFO - 2023-07-11 09:10:43 --> URI Class Initialized
INFO - 2023-07-11 09:10:43 --> Router Class Initialized
INFO - 2023-07-11 09:10:43 --> Router Class Initialized
INFO - 2023-07-11 09:10:43 --> Output Class Initialized
INFO - 2023-07-11 09:10:43 --> Security Class Initialized
INFO - 2023-07-11 09:10:43 --> Output Class Initialized
DEBUG - 2023-07-11 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:10:43 --> Input Class Initialized
INFO - 2023-07-11 09:10:43 --> Language Class Initialized
INFO - 2023-07-11 09:10:43 --> Security Class Initialized
ERROR - 2023-07-11 09:10:43 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:10:43 --> Input Class Initialized
INFO - 2023-07-11 09:10:43 --> Language Class Initialized
ERROR - 2023-07-11 09:10:43 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:10:43 --> Config Class Initialized
INFO - 2023-07-11 09:10:43 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:10:43 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:10:43 --> Utf8 Class Initialized
INFO - 2023-07-11 09:10:43 --> URI Class Initialized
INFO - 2023-07-11 09:10:43 --> Router Class Initialized
INFO - 2023-07-11 09:10:43 --> Output Class Initialized
INFO - 2023-07-11 09:10:43 --> Security Class Initialized
DEBUG - 2023-07-11 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:10:43 --> Input Class Initialized
INFO - 2023-07-11 09:10:43 --> Language Class Initialized
ERROR - 2023-07-11 09:10:43 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:11:11 --> Config Class Initialized
INFO - 2023-07-11 09:11:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:11:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:11:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:11:11 --> URI Class Initialized
INFO - 2023-07-11 09:11:11 --> Router Class Initialized
INFO - 2023-07-11 09:11:11 --> Output Class Initialized
INFO - 2023-07-11 09:11:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:11:11 --> Input Class Initialized
INFO - 2023-07-11 09:11:11 --> Language Class Initialized
INFO - 2023-07-11 09:11:11 --> Loader Class Initialized
INFO - 2023-07-11 09:11:11 --> Helper loaded: url_helper
INFO - 2023-07-11 09:11:11 --> Database Driver Class Initialized
INFO - 2023-07-11 09:11:11 --> Controller Class Initialized
INFO - 2023-07-11 09:11:11 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:11:11 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 09:11:11 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:11:11 --> Final output sent to browser
DEBUG - 2023-07-11 09:11:11 --> Total execution time: 0.0902
INFO - 2023-07-11 09:11:11 --> Config Class Initialized
INFO - 2023-07-11 09:11:11 --> Config Class Initialized
INFO - 2023-07-11 09:11:11 --> Hooks Class Initialized
INFO - 2023-07-11 09:11:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 09:11:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:11:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:11:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:11:11 --> URI Class Initialized
INFO - 2023-07-11 09:11:11 --> URI Class Initialized
INFO - 2023-07-11 09:11:11 --> Router Class Initialized
INFO - 2023-07-11 09:11:11 --> Router Class Initialized
INFO - 2023-07-11 09:11:11 --> Output Class Initialized
INFO - 2023-07-11 09:11:11 --> Output Class Initialized
INFO - 2023-07-11 09:11:11 --> Security Class Initialized
INFO - 2023-07-11 09:11:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:11:11 --> Input Class Initialized
DEBUG - 2023-07-11 09:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:11:11 --> Input Class Initialized
INFO - 2023-07-11 09:11:11 --> Language Class Initialized
INFO - 2023-07-11 09:11:11 --> Language Class Initialized
ERROR - 2023-07-11 09:11:11 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 09:11:11 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:11:11 --> Config Class Initialized
INFO - 2023-07-11 09:11:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:11:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:11:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:11:11 --> URI Class Initialized
INFO - 2023-07-11 09:11:12 --> Router Class Initialized
INFO - 2023-07-11 09:11:12 --> Output Class Initialized
INFO - 2023-07-11 09:11:12 --> Security Class Initialized
DEBUG - 2023-07-11 09:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:11:12 --> Input Class Initialized
INFO - 2023-07-11 09:11:12 --> Language Class Initialized
ERROR - 2023-07-11 09:11:12 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:11:32 --> Config Class Initialized
INFO - 2023-07-11 09:11:32 --> Hooks Class Initialized
INFO - 2023-07-11 09:11:32 --> Config Class Initialized
INFO - 2023-07-11 09:11:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:11:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:11:32 --> Utf8 Class Initialized
INFO - 2023-07-11 09:11:32 --> URI Class Initialized
DEBUG - 2023-07-11 09:11:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:11:32 --> Utf8 Class Initialized
INFO - 2023-07-11 09:11:32 --> URI Class Initialized
INFO - 2023-07-11 09:11:32 --> Router Class Initialized
INFO - 2023-07-11 09:11:32 --> Output Class Initialized
INFO - 2023-07-11 09:11:32 --> Security Class Initialized
DEBUG - 2023-07-11 09:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:11:32 --> Input Class Initialized
INFO - 2023-07-11 09:11:32 --> Language Class Initialized
ERROR - 2023-07-11 09:11:32 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:11:32 --> Router Class Initialized
INFO - 2023-07-11 09:11:32 --> Output Class Initialized
INFO - 2023-07-11 09:11:32 --> Security Class Initialized
DEBUG - 2023-07-11 09:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:11:32 --> Input Class Initialized
INFO - 2023-07-11 09:11:32 --> Language Class Initialized
ERROR - 2023-07-11 09:11:32 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:12:34 --> Config Class Initialized
INFO - 2023-07-11 09:12:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:34 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:34 --> URI Class Initialized
INFO - 2023-07-11 09:12:34 --> Router Class Initialized
INFO - 2023-07-11 09:12:34 --> Output Class Initialized
INFO - 2023-07-11 09:12:34 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:34 --> Input Class Initialized
INFO - 2023-07-11 09:12:34 --> Language Class Initialized
INFO - 2023-07-11 09:12:34 --> Loader Class Initialized
INFO - 2023-07-11 09:12:34 --> Helper loaded: url_helper
INFO - 2023-07-11 09:12:34 --> Database Driver Class Initialized
INFO - 2023-07-11 09:12:34 --> Controller Class Initialized
INFO - 2023-07-11 09:12:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:12:34 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 09:12:34 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:12:34 --> Final output sent to browser
DEBUG - 2023-07-11 09:12:34 --> Total execution time: 0.0802
INFO - 2023-07-11 09:12:34 --> Config Class Initialized
INFO - 2023-07-11 09:12:34 --> Config Class Initialized
INFO - 2023-07-11 09:12:34 --> Hooks Class Initialized
INFO - 2023-07-11 09:12:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:34 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:12:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:34 --> URI Class Initialized
INFO - 2023-07-11 09:12:34 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:34 --> URI Class Initialized
INFO - 2023-07-11 09:12:34 --> Router Class Initialized
INFO - 2023-07-11 09:12:34 --> Router Class Initialized
INFO - 2023-07-11 09:12:34 --> Output Class Initialized
INFO - 2023-07-11 09:12:34 --> Output Class Initialized
INFO - 2023-07-11 09:12:34 --> Security Class Initialized
INFO - 2023-07-11 09:12:34 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:34 --> Input Class Initialized
INFO - 2023-07-11 09:12:34 --> Language Class Initialized
DEBUG - 2023-07-11 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:34 --> Input Class Initialized
INFO - 2023-07-11 09:12:34 --> Language Class Initialized
ERROR - 2023-07-11 09:12:34 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 09:12:34 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:12:35 --> Config Class Initialized
INFO - 2023-07-11 09:12:35 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:35 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:35 --> URI Class Initialized
INFO - 2023-07-11 09:12:35 --> Router Class Initialized
INFO - 2023-07-11 09:12:35 --> Output Class Initialized
INFO - 2023-07-11 09:12:35 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:35 --> Input Class Initialized
INFO - 2023-07-11 09:12:35 --> Language Class Initialized
ERROR - 2023-07-11 09:12:35 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:12:49 --> Config Class Initialized
INFO - 2023-07-11 09:12:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:49 --> URI Class Initialized
INFO - 2023-07-11 09:12:49 --> Router Class Initialized
INFO - 2023-07-11 09:12:49 --> Output Class Initialized
INFO - 2023-07-11 09:12:49 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:49 --> Input Class Initialized
INFO - 2023-07-11 09:12:49 --> Language Class Initialized
INFO - 2023-07-11 09:12:49 --> Loader Class Initialized
INFO - 2023-07-11 09:12:49 --> Helper loaded: url_helper
INFO - 2023-07-11 09:12:49 --> Database Driver Class Initialized
INFO - 2023-07-11 09:12:49 --> Controller Class Initialized
INFO - 2023-07-11 09:12:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:12:49 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 09:12:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:12:49 --> Final output sent to browser
DEBUG - 2023-07-11 09:12:49 --> Total execution time: 0.0568
INFO - 2023-07-11 09:12:49 --> Config Class Initialized
INFO - 2023-07-11 09:12:49 --> Config Class Initialized
INFO - 2023-07-11 09:12:49 --> Hooks Class Initialized
INFO - 2023-07-11 09:12:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 09:12:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:49 --> URI Class Initialized
INFO - 2023-07-11 09:12:49 --> URI Class Initialized
INFO - 2023-07-11 09:12:49 --> Router Class Initialized
INFO - 2023-07-11 09:12:49 --> Router Class Initialized
INFO - 2023-07-11 09:12:49 --> Output Class Initialized
INFO - 2023-07-11 09:12:49 --> Output Class Initialized
INFO - 2023-07-11 09:12:49 --> Security Class Initialized
INFO - 2023-07-11 09:12:49 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:49 --> Input Class Initialized
DEBUG - 2023-07-11 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:49 --> Input Class Initialized
INFO - 2023-07-11 09:12:49 --> Language Class Initialized
INFO - 2023-07-11 09:12:49 --> Language Class Initialized
ERROR - 2023-07-11 09:12:49 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 09:12:49 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:12:49 --> Config Class Initialized
INFO - 2023-07-11 09:12:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:49 --> URI Class Initialized
INFO - 2023-07-11 09:12:49 --> Router Class Initialized
INFO - 2023-07-11 09:12:49 --> Output Class Initialized
INFO - 2023-07-11 09:12:49 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:49 --> Input Class Initialized
INFO - 2023-07-11 09:12:49 --> Language Class Initialized
ERROR - 2023-07-11 09:12:49 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:12:50 --> Config Class Initialized
INFO - 2023-07-11 09:12:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:50 --> URI Class Initialized
INFO - 2023-07-11 09:12:50 --> Router Class Initialized
INFO - 2023-07-11 09:12:50 --> Output Class Initialized
INFO - 2023-07-11 09:12:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:50 --> Input Class Initialized
INFO - 2023-07-11 09:12:50 --> Language Class Initialized
INFO - 2023-07-11 09:12:50 --> Loader Class Initialized
INFO - 2023-07-11 09:12:50 --> Helper loaded: url_helper
INFO - 2023-07-11 09:12:50 --> Database Driver Class Initialized
INFO - 2023-07-11 09:12:50 --> Controller Class Initialized
INFO - 2023-07-11 09:12:50 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:12:50 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:12:50 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:12:50 --> Final output sent to browser
DEBUG - 2023-07-11 09:12:50 --> Total execution time: 0.0603
INFO - 2023-07-11 09:12:50 --> Config Class Initialized
INFO - 2023-07-11 09:12:50 --> Hooks Class Initialized
INFO - 2023-07-11 09:12:50 --> Config Class Initialized
INFO - 2023-07-11 09:12:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:50 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:12:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:50 --> URI Class Initialized
INFO - 2023-07-11 09:12:50 --> URI Class Initialized
INFO - 2023-07-11 09:12:50 --> Router Class Initialized
INFO - 2023-07-11 09:12:50 --> Router Class Initialized
INFO - 2023-07-11 09:12:50 --> Output Class Initialized
INFO - 2023-07-11 09:12:50 --> Output Class Initialized
INFO - 2023-07-11 09:12:50 --> Security Class Initialized
INFO - 2023-07-11 09:12:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:50 --> Input Class Initialized
DEBUG - 2023-07-11 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:50 --> Input Class Initialized
INFO - 2023-07-11 09:12:50 --> Language Class Initialized
INFO - 2023-07-11 09:12:50 --> Language Class Initialized
ERROR - 2023-07-11 09:12:50 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 09:12:50 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:12:50 --> Config Class Initialized
INFO - 2023-07-11 09:12:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:12:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:12:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:12:50 --> URI Class Initialized
INFO - 2023-07-11 09:12:50 --> Router Class Initialized
INFO - 2023-07-11 09:12:50 --> Output Class Initialized
INFO - 2023-07-11 09:12:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:12:50 --> Input Class Initialized
INFO - 2023-07-11 09:12:50 --> Language Class Initialized
ERROR - 2023-07-11 09:12:50 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:17:11 --> Config Class Initialized
INFO - 2023-07-11 09:17:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:17:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:17:11 --> URI Class Initialized
INFO - 2023-07-11 09:17:11 --> Router Class Initialized
INFO - 2023-07-11 09:17:11 --> Output Class Initialized
INFO - 2023-07-11 09:17:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:11 --> Input Class Initialized
INFO - 2023-07-11 09:17:11 --> Language Class Initialized
INFO - 2023-07-11 09:17:11 --> Loader Class Initialized
INFO - 2023-07-11 09:17:11 --> Helper loaded: url_helper
INFO - 2023-07-11 09:17:11 --> Database Driver Class Initialized
INFO - 2023-07-11 09:17:11 --> Controller Class Initialized
INFO - 2023-07-11 09:17:11 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:17:11 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:17:11 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:17:11 --> Final output sent to browser
DEBUG - 2023-07-11 09:17:11 --> Total execution time: 0.0639
INFO - 2023-07-11 09:17:11 --> Config Class Initialized
INFO - 2023-07-11 09:17:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:17:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:17:11 --> URI Class Initialized
INFO - 2023-07-11 09:17:11 --> Config Class Initialized
INFO - 2023-07-11 09:17:11 --> Hooks Class Initialized
INFO - 2023-07-11 09:17:11 --> Router Class Initialized
INFO - 2023-07-11 09:17:11 --> Output Class Initialized
DEBUG - 2023-07-11 09:17:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:17:11 --> Security Class Initialized
INFO - 2023-07-11 09:17:11 --> URI Class Initialized
DEBUG - 2023-07-11 09:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:11 --> Input Class Initialized
INFO - 2023-07-11 09:17:11 --> Router Class Initialized
INFO - 2023-07-11 09:17:11 --> Language Class Initialized
ERROR - 2023-07-11 09:17:11 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:17:11 --> Output Class Initialized
INFO - 2023-07-11 09:17:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:11 --> Input Class Initialized
INFO - 2023-07-11 09:17:11 --> Language Class Initialized
ERROR - 2023-07-11 09:17:11 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:17:11 --> Config Class Initialized
INFO - 2023-07-11 09:17:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:17:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:17:11 --> URI Class Initialized
INFO - 2023-07-11 09:17:11 --> Router Class Initialized
INFO - 2023-07-11 09:17:11 --> Output Class Initialized
INFO - 2023-07-11 09:17:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:11 --> Input Class Initialized
INFO - 2023-07-11 09:17:11 --> Language Class Initialized
ERROR - 2023-07-11 09:17:11 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:17:13 --> Config Class Initialized
INFO - 2023-07-11 09:17:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:17:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:13 --> Utf8 Class Initialized
INFO - 2023-07-11 09:17:13 --> URI Class Initialized
INFO - 2023-07-11 09:17:13 --> Router Class Initialized
INFO - 2023-07-11 09:17:13 --> Output Class Initialized
INFO - 2023-07-11 09:17:13 --> Security Class Initialized
DEBUG - 2023-07-11 09:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:13 --> Input Class Initialized
INFO - 2023-07-11 09:17:13 --> Language Class Initialized
INFO - 2023-07-11 09:17:13 --> Loader Class Initialized
INFO - 2023-07-11 09:17:13 --> Helper loaded: url_helper
INFO - 2023-07-11 09:17:13 --> Database Driver Class Initialized
INFO - 2023-07-11 09:17:13 --> Controller Class Initialized
INFO - 2023-07-11 09:17:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:17:13 --> File loaded: C:\xampp\htdocs\code\application\views\/addUser.php
INFO - 2023-07-11 09:17:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:17:13 --> Final output sent to browser
DEBUG - 2023-07-11 09:17:13 --> Total execution time: 0.0567
INFO - 2023-07-11 09:17:13 --> Config Class Initialized
INFO - 2023-07-11 09:17:13 --> Hooks Class Initialized
INFO - 2023-07-11 09:17:13 --> Config Class Initialized
INFO - 2023-07-11 09:17:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:17:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:13 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:17:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:13 --> Utf8 Class Initialized
INFO - 2023-07-11 09:17:13 --> URI Class Initialized
INFO - 2023-07-11 09:17:13 --> URI Class Initialized
INFO - 2023-07-11 09:17:13 --> Router Class Initialized
INFO - 2023-07-11 09:17:13 --> Router Class Initialized
INFO - 2023-07-11 09:17:13 --> Output Class Initialized
INFO - 2023-07-11 09:17:13 --> Output Class Initialized
INFO - 2023-07-11 09:17:13 --> Security Class Initialized
DEBUG - 2023-07-11 09:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:13 --> Security Class Initialized
INFO - 2023-07-11 09:17:13 --> Input Class Initialized
INFO - 2023-07-11 09:17:13 --> Language Class Initialized
DEBUG - 2023-07-11 09:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:13 --> Input Class Initialized
INFO - 2023-07-11 09:17:13 --> Language Class Initialized
ERROR - 2023-07-11 09:17:13 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 09:17:13 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:17:13 --> Config Class Initialized
INFO - 2023-07-11 09:17:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:17:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:17:13 --> Utf8 Class Initialized
INFO - 2023-07-11 09:17:13 --> URI Class Initialized
INFO - 2023-07-11 09:17:13 --> Router Class Initialized
INFO - 2023-07-11 09:17:13 --> Output Class Initialized
INFO - 2023-07-11 09:17:13 --> Security Class Initialized
DEBUG - 2023-07-11 09:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:17:13 --> Input Class Initialized
INFO - 2023-07-11 09:17:13 --> Language Class Initialized
ERROR - 2023-07-11 09:17:13 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:21:27 --> Config Class Initialized
INFO - 2023-07-11 09:21:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:27 --> URI Class Initialized
INFO - 2023-07-11 09:21:27 --> Router Class Initialized
INFO - 2023-07-11 09:21:27 --> Output Class Initialized
INFO - 2023-07-11 09:21:27 --> Security Class Initialized
DEBUG - 2023-07-11 09:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:27 --> Input Class Initialized
INFO - 2023-07-11 09:21:27 --> Language Class Initialized
INFO - 2023-07-11 09:21:27 --> Loader Class Initialized
INFO - 2023-07-11 09:21:27 --> Helper loaded: url_helper
INFO - 2023-07-11 09:21:27 --> Database Driver Class Initialized
INFO - 2023-07-11 09:21:27 --> Controller Class Initialized
INFO - 2023-07-11 09:21:27 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:21:27 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 09:21:27 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:21:27 --> Final output sent to browser
DEBUG - 2023-07-11 09:21:27 --> Total execution time: 0.0708
INFO - 2023-07-11 09:21:27 --> Config Class Initialized
INFO - 2023-07-11 09:21:27 --> Hooks Class Initialized
INFO - 2023-07-11 09:21:27 --> Config Class Initialized
INFO - 2023-07-11 09:21:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 09:21:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:27 --> URI Class Initialized
INFO - 2023-07-11 09:21:27 --> URI Class Initialized
INFO - 2023-07-11 09:21:27 --> Router Class Initialized
INFO - 2023-07-11 09:21:27 --> Router Class Initialized
INFO - 2023-07-11 09:21:27 --> Output Class Initialized
INFO - 2023-07-11 09:21:27 --> Output Class Initialized
INFO - 2023-07-11 09:21:27 --> Security Class Initialized
INFO - 2023-07-11 09:21:27 --> Security Class Initialized
DEBUG - 2023-07-11 09:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 09:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:27 --> Input Class Initialized
INFO - 2023-07-11 09:21:27 --> Input Class Initialized
INFO - 2023-07-11 09:21:27 --> Language Class Initialized
INFO - 2023-07-11 09:21:27 --> Language Class Initialized
ERROR - 2023-07-11 09:21:27 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 09:21:27 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:21:27 --> Config Class Initialized
INFO - 2023-07-11 09:21:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:27 --> URI Class Initialized
INFO - 2023-07-11 09:21:27 --> Router Class Initialized
INFO - 2023-07-11 09:21:27 --> Output Class Initialized
INFO - 2023-07-11 09:21:27 --> Security Class Initialized
DEBUG - 2023-07-11 09:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:27 --> Input Class Initialized
INFO - 2023-07-11 09:21:27 --> Language Class Initialized
ERROR - 2023-07-11 09:21:27 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
INFO - 2023-07-11 09:21:30 --> Loader Class Initialized
INFO - 2023-07-11 09:21:30 --> Helper loaded: url_helper
INFO - 2023-07-11 09:21:30 --> Database Driver Class Initialized
INFO - 2023-07-11 09:21:30 --> Controller Class Initialized
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:21:30 --> Final output sent to browser
DEBUG - 2023-07-11 09:21:30 --> Total execution time: 0.0615
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
ERROR - 2023-07-11 09:21:30 --> 404 Page Not Found: Assest/fonts
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
INFO - 2023-07-11 09:21:30 --> Loader Class Initialized
INFO - 2023-07-11 09:21:30 --> Helper loaded: url_helper
INFO - 2023-07-11 09:21:30 --> Loader Class Initialized
INFO - 2023-07-11 09:21:30 --> Helper loaded: url_helper
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Database Driver Class Initialized
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> Controller Class Initialized
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 09:21:30 --> Database Driver Class Initialized
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
INFO - 2023-07-11 09:21:30 --> Controller Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:21:30 --> Final output sent to browser
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
DEBUG - 2023-07-11 09:21:30 --> Total execution time: 0.1105
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
INFO - 2023-07-11 09:21:30 --> Loader Class Initialized
INFO - 2023-07-11 09:21:30 --> Loader Class Initialized
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
INFO - 2023-07-11 09:21:30 --> Helper loaded: url_helper
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
INFO - 2023-07-11 09:21:30 --> Helper loaded: url_helper
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
INFO - 2023-07-11 09:21:30 --> Loader Class Initialized
INFO - 2023-07-11 09:21:30 --> Database Driver Class Initialized
INFO - 2023-07-11 09:21:30 --> Helper loaded: url_helper
INFO - 2023-07-11 09:21:30 --> Database Driver Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
INFO - 2023-07-11 09:21:30 --> Controller Class Initialized
INFO - 2023-07-11 09:21:30 --> Database Driver Class Initialized
INFO - 2023-07-11 09:21:30 --> Controller Class Initialized
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 09:21:30 --> Controller Class Initialized
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
INFO - 2023-07-11 09:21:30 --> Final output sent to browser
DEBUG - 2023-07-11 09:21:30 --> Total execution time: 0.1880
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 09:21:30 --> Final output sent to browser
DEBUG - 2023-07-11 09:21:30 --> Total execution time: 0.2416
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:21:30 --> Final output sent to browser
DEBUG - 2023-07-11 09:21:30 --> Total execution time: 0.1727
INFO - 2023-07-11 09:21:30 --> Final output sent to browser
DEBUG - 2023-07-11 09:21:30 --> Total execution time: 0.1766
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
ERROR - 2023-07-11 09:21:30 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:21:30 --> Config Class Initialized
INFO - 2023-07-11 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:21:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:21:30 --> URI Class Initialized
INFO - 2023-07-11 09:21:30 --> Router Class Initialized
INFO - 2023-07-11 09:21:30 --> Output Class Initialized
INFO - 2023-07-11 09:21:30 --> Security Class Initialized
DEBUG - 2023-07-11 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:21:30 --> Input Class Initialized
INFO - 2023-07-11 09:21:30 --> Language Class Initialized
INFO - 2023-07-11 09:21:30 --> Loader Class Initialized
INFO - 2023-07-11 09:21:30 --> Helper loaded: url_helper
INFO - 2023-07-11 09:21:30 --> Database Driver Class Initialized
INFO - 2023-07-11 09:21:30 --> Controller Class Initialized
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 09:21:30 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 09:21:30 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:21:30 --> Final output sent to browser
DEBUG - 2023-07-11 09:21:30 --> Total execution time: 0.0883
INFO - 2023-07-11 09:40:04 --> Config Class Initialized
INFO - 2023-07-11 09:40:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:04 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:04 --> URI Class Initialized
INFO - 2023-07-11 09:40:04 --> Router Class Initialized
INFO - 2023-07-11 09:40:05 --> Output Class Initialized
INFO - 2023-07-11 09:40:05 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:05 --> Input Class Initialized
INFO - 2023-07-11 09:40:05 --> Language Class Initialized
ERROR - 2023-07-11 09:40:05 --> 404 Page Not Found: About/index
INFO - 2023-07-11 09:40:09 --> Config Class Initialized
INFO - 2023-07-11 09:40:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:09 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:09 --> URI Class Initialized
INFO - 2023-07-11 09:40:09 --> Router Class Initialized
INFO - 2023-07-11 09:40:09 --> Output Class Initialized
INFO - 2023-07-11 09:40:09 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:09 --> Input Class Initialized
INFO - 2023-07-11 09:40:09 --> Language Class Initialized
INFO - 2023-07-11 09:40:09 --> Loader Class Initialized
INFO - 2023-07-11 09:40:09 --> Helper loaded: url_helper
INFO - 2023-07-11 09:40:09 --> Database Driver Class Initialized
INFO - 2023-07-11 09:40:09 --> Controller Class Initialized
INFO - 2023-07-11 09:40:09 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:40:09 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 09:40:09 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:40:09 --> Final output sent to browser
DEBUG - 2023-07-11 09:40:09 --> Total execution time: 0.2391
INFO - 2023-07-11 09:40:09 --> Config Class Initialized
INFO - 2023-07-11 09:40:09 --> Hooks Class Initialized
INFO - 2023-07-11 09:40:09 --> Config Class Initialized
INFO - 2023-07-11 09:40:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:09 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:09 --> URI Class Initialized
INFO - 2023-07-11 09:40:09 --> Router Class Initialized
DEBUG - 2023-07-11 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:09 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:09 --> Output Class Initialized
INFO - 2023-07-11 09:40:09 --> URI Class Initialized
INFO - 2023-07-11 09:40:09 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:09 --> Input Class Initialized
INFO - 2023-07-11 09:40:09 --> Router Class Initialized
INFO - 2023-07-11 09:40:09 --> Language Class Initialized
ERROR - 2023-07-11 09:40:09 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:40:09 --> Output Class Initialized
INFO - 2023-07-11 09:40:09 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:09 --> Input Class Initialized
INFO - 2023-07-11 09:40:09 --> Language Class Initialized
ERROR - 2023-07-11 09:40:09 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:40:10 --> Config Class Initialized
INFO - 2023-07-11 09:40:10 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:10 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:10 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:10 --> URI Class Initialized
INFO - 2023-07-11 09:40:10 --> Router Class Initialized
INFO - 2023-07-11 09:40:10 --> Output Class Initialized
INFO - 2023-07-11 09:40:10 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:10 --> Input Class Initialized
INFO - 2023-07-11 09:40:10 --> Language Class Initialized
ERROR - 2023-07-11 09:40:10 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:40:27 --> Config Class Initialized
INFO - 2023-07-11 09:40:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:27 --> URI Class Initialized
INFO - 2023-07-11 09:40:27 --> Router Class Initialized
INFO - 2023-07-11 09:40:27 --> Output Class Initialized
INFO - 2023-07-11 09:40:27 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:27 --> Input Class Initialized
INFO - 2023-07-11 09:40:27 --> Language Class Initialized
INFO - 2023-07-11 09:40:27 --> Loader Class Initialized
INFO - 2023-07-11 09:40:27 --> Helper loaded: url_helper
INFO - 2023-07-11 09:40:27 --> Database Driver Class Initialized
INFO - 2023-07-11 09:40:27 --> Controller Class Initialized
INFO - 2023-07-11 09:40:27 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 09:40:27 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:40:27 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 09:40:27 --> Final output sent to browser
DEBUG - 2023-07-11 09:40:27 --> Total execution time: 0.1923
INFO - 2023-07-11 09:40:27 --> Config Class Initialized
INFO - 2023-07-11 09:40:27 --> Hooks Class Initialized
INFO - 2023-07-11 09:40:27 --> Config Class Initialized
INFO - 2023-07-11 09:40:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:27 --> Utf8 Class Initialized
DEBUG - 2023-07-11 09:40:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:27 --> URI Class Initialized
INFO - 2023-07-11 09:40:27 --> URI Class Initialized
INFO - 2023-07-11 09:40:27 --> Router Class Initialized
INFO - 2023-07-11 09:40:27 --> Router Class Initialized
INFO - 2023-07-11 09:40:27 --> Output Class Initialized
INFO - 2023-07-11 09:40:27 --> Output Class Initialized
INFO - 2023-07-11 09:40:28 --> Security Class Initialized
INFO - 2023-07-11 09:40:28 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:28 --> Input Class Initialized
INFO - 2023-07-11 09:40:28 --> Language Class Initialized
DEBUG - 2023-07-11 09:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:28 --> Input Class Initialized
ERROR - 2023-07-11 09:40:28 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 09:40:28 --> Language Class Initialized
ERROR - 2023-07-11 09:40:28 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 09:40:28 --> Config Class Initialized
INFO - 2023-07-11 09:40:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:28 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:28 --> URI Class Initialized
INFO - 2023-07-11 09:40:28 --> Router Class Initialized
INFO - 2023-07-11 09:40:28 --> Output Class Initialized
INFO - 2023-07-11 09:40:28 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:28 --> Input Class Initialized
INFO - 2023-07-11 09:40:28 --> Language Class Initialized
ERROR - 2023-07-11 09:40:28 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:40:28 --> Config Class Initialized
INFO - 2023-07-11 09:40:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:40:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:40:28 --> Utf8 Class Initialized
INFO - 2023-07-11 09:40:28 --> URI Class Initialized
INFO - 2023-07-11 09:40:28 --> Router Class Initialized
INFO - 2023-07-11 09:40:28 --> Output Class Initialized
INFO - 2023-07-11 09:40:28 --> Security Class Initialized
DEBUG - 2023-07-11 09:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:40:28 --> Input Class Initialized
INFO - 2023-07-11 09:40:28 --> Language Class Initialized
ERROR - 2023-07-11 09:40:28 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 09:41:00 --> Config Class Initialized
INFO - 2023-07-11 09:41:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:41:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:41:00 --> Utf8 Class Initialized
INFO - 2023-07-11 09:41:00 --> URI Class Initialized
INFO - 2023-07-11 09:41:00 --> Router Class Initialized
INFO - 2023-07-11 09:41:00 --> Output Class Initialized
INFO - 2023-07-11 09:41:00 --> Security Class Initialized
DEBUG - 2023-07-11 09:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:41:00 --> Input Class Initialized
INFO - 2023-07-11 09:41:00 --> Language Class Initialized
INFO - 2023-07-11 09:41:00 --> Loader Class Initialized
INFO - 2023-07-11 09:41:00 --> Helper loaded: url_helper
INFO - 2023-07-11 09:41:00 --> Database Driver Class Initialized
INFO - 2023-07-11 09:41:00 --> Controller Class Initialized
INFO - 2023-07-11 09:41:00 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:41:00 --> Final output sent to browser
DEBUG - 2023-07-11 09:41:00 --> Total execution time: 0.0913
INFO - 2023-07-11 09:41:00 --> Config Class Initialized
INFO - 2023-07-11 09:41:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:41:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:41:00 --> Utf8 Class Initialized
INFO - 2023-07-11 09:41:00 --> URI Class Initialized
INFO - 2023-07-11 09:41:00 --> Router Class Initialized
INFO - 2023-07-11 09:41:00 --> Output Class Initialized
INFO - 2023-07-11 09:41:00 --> Security Class Initialized
DEBUG - 2023-07-11 09:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:41:00 --> Input Class Initialized
INFO - 2023-07-11 09:41:00 --> Language Class Initialized
ERROR - 2023-07-11 09:41:00 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:41:40 --> Config Class Initialized
INFO - 2023-07-11 09:41:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:41:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:41:40 --> Utf8 Class Initialized
INFO - 2023-07-11 09:41:40 --> URI Class Initialized
INFO - 2023-07-11 09:41:40 --> Router Class Initialized
INFO - 2023-07-11 09:41:40 --> Output Class Initialized
INFO - 2023-07-11 09:41:40 --> Security Class Initialized
DEBUG - 2023-07-11 09:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:41:40 --> Input Class Initialized
INFO - 2023-07-11 09:41:40 --> Language Class Initialized
INFO - 2023-07-11 09:41:40 --> Loader Class Initialized
INFO - 2023-07-11 09:41:40 --> Helper loaded: url_helper
INFO - 2023-07-11 09:41:40 --> Database Driver Class Initialized
INFO - 2023-07-11 09:41:40 --> Controller Class Initialized
INFO - 2023-07-11 09:41:40 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:41:40 --> Final output sent to browser
DEBUG - 2023-07-11 09:41:40 --> Total execution time: 0.0895
INFO - 2023-07-11 09:41:40 --> Config Class Initialized
INFO - 2023-07-11 09:41:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:41:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:41:40 --> Utf8 Class Initialized
INFO - 2023-07-11 09:41:40 --> URI Class Initialized
INFO - 2023-07-11 09:41:40 --> Router Class Initialized
INFO - 2023-07-11 09:41:40 --> Output Class Initialized
INFO - 2023-07-11 09:41:40 --> Security Class Initialized
DEBUG - 2023-07-11 09:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:41:40 --> Input Class Initialized
INFO - 2023-07-11 09:41:40 --> Language Class Initialized
ERROR - 2023-07-11 09:41:40 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:44:36 --> Config Class Initialized
INFO - 2023-07-11 09:44:36 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:44:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:44:36 --> Utf8 Class Initialized
INFO - 2023-07-11 09:44:36 --> URI Class Initialized
INFO - 2023-07-11 09:44:36 --> Router Class Initialized
INFO - 2023-07-11 09:44:36 --> Output Class Initialized
INFO - 2023-07-11 09:44:36 --> Security Class Initialized
DEBUG - 2023-07-11 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:44:36 --> Input Class Initialized
INFO - 2023-07-11 09:44:36 --> Language Class Initialized
INFO - 2023-07-11 09:44:36 --> Loader Class Initialized
INFO - 2023-07-11 09:44:36 --> Helper loaded: url_helper
INFO - 2023-07-11 09:44:36 --> Database Driver Class Initialized
INFO - 2023-07-11 09:44:36 --> Controller Class Initialized
INFO - 2023-07-11 09:44:36 --> File loaded: C:\xampp\htdocs\code\application\views\/login.php
INFO - 2023-07-11 09:44:36 --> Final output sent to browser
DEBUG - 2023-07-11 09:44:36 --> Total execution time: 0.1359
INFO - 2023-07-11 09:44:36 --> Config Class Initialized
INFO - 2023-07-11 09:44:36 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:44:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:44:36 --> Utf8 Class Initialized
INFO - 2023-07-11 09:44:36 --> URI Class Initialized
INFO - 2023-07-11 09:44:36 --> Router Class Initialized
INFO - 2023-07-11 09:44:36 --> Output Class Initialized
INFO - 2023-07-11 09:44:36 --> Security Class Initialized
DEBUG - 2023-07-11 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:44:36 --> Input Class Initialized
INFO - 2023-07-11 09:44:36 --> Language Class Initialized
ERROR - 2023-07-11 09:44:36 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:44:51 --> Config Class Initialized
INFO - 2023-07-11 09:44:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:44:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:44:51 --> Utf8 Class Initialized
INFO - 2023-07-11 09:44:51 --> URI Class Initialized
INFO - 2023-07-11 09:44:51 --> Router Class Initialized
INFO - 2023-07-11 09:44:51 --> Output Class Initialized
INFO - 2023-07-11 09:44:51 --> Security Class Initialized
DEBUG - 2023-07-11 09:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:44:51 --> Input Class Initialized
INFO - 2023-07-11 09:44:51 --> Language Class Initialized
INFO - 2023-07-11 09:44:51 --> Loader Class Initialized
INFO - 2023-07-11 09:44:51 --> Helper loaded: url_helper
INFO - 2023-07-11 09:44:51 --> Database Driver Class Initialized
INFO - 2023-07-11 09:44:51 --> Controller Class Initialized
INFO - 2023-07-11 09:44:51 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:44:51 --> Final output sent to browser
DEBUG - 2023-07-11 09:44:51 --> Total execution time: 0.0539
INFO - 2023-07-11 09:44:51 --> Config Class Initialized
INFO - 2023-07-11 09:44:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:44:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:44:51 --> Utf8 Class Initialized
INFO - 2023-07-11 09:44:51 --> URI Class Initialized
INFO - 2023-07-11 09:44:51 --> Router Class Initialized
INFO - 2023-07-11 09:44:51 --> Output Class Initialized
INFO - 2023-07-11 09:44:51 --> Security Class Initialized
DEBUG - 2023-07-11 09:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:44:51 --> Input Class Initialized
INFO - 2023-07-11 09:44:51 --> Language Class Initialized
ERROR - 2023-07-11 09:44:51 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:33 --> Config Class Initialized
INFO - 2023-07-11 09:45:33 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:33 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:33 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:33 --> URI Class Initialized
INFO - 2023-07-11 09:45:33 --> Router Class Initialized
INFO - 2023-07-11 09:45:33 --> Output Class Initialized
INFO - 2023-07-11 09:45:33 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:33 --> Input Class Initialized
INFO - 2023-07-11 09:45:33 --> Language Class Initialized
INFO - 2023-07-11 09:45:33 --> Loader Class Initialized
INFO - 2023-07-11 09:45:33 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:33 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:33 --> Controller Class Initialized
INFO - 2023-07-11 09:45:33 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:33 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:33 --> Total execution time: 0.0726
INFO - 2023-07-11 09:45:33 --> Config Class Initialized
INFO - 2023-07-11 09:45:33 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:33 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:33 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:33 --> URI Class Initialized
INFO - 2023-07-11 09:45:33 --> Router Class Initialized
INFO - 2023-07-11 09:45:33 --> Output Class Initialized
INFO - 2023-07-11 09:45:33 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:33 --> Input Class Initialized
INFO - 2023-07-11 09:45:33 --> Language Class Initialized
ERROR - 2023-07-11 09:45:33 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:49 --> Config Class Initialized
INFO - 2023-07-11 09:45:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:49 --> URI Class Initialized
INFO - 2023-07-11 09:45:49 --> Router Class Initialized
INFO - 2023-07-11 09:45:49 --> Output Class Initialized
INFO - 2023-07-11 09:45:49 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:49 --> Input Class Initialized
INFO - 2023-07-11 09:45:49 --> Language Class Initialized
INFO - 2023-07-11 09:45:49 --> Loader Class Initialized
INFO - 2023-07-11 09:45:49 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:49 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:49 --> Controller Class Initialized
INFO - 2023-07-11 09:45:49 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:49 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:49 --> Total execution time: 0.0550
INFO - 2023-07-11 09:45:49 --> Config Class Initialized
INFO - 2023-07-11 09:45:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:49 --> URI Class Initialized
INFO - 2023-07-11 09:45:49 --> Router Class Initialized
INFO - 2023-07-11 09:45:49 --> Output Class Initialized
INFO - 2023-07-11 09:45:49 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:49 --> Input Class Initialized
INFO - 2023-07-11 09:45:49 --> Language Class Initialized
ERROR - 2023-07-11 09:45:49 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:50 --> Config Class Initialized
INFO - 2023-07-11 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:50 --> URI Class Initialized
INFO - 2023-07-11 09:45:50 --> Router Class Initialized
INFO - 2023-07-11 09:45:50 --> Output Class Initialized
INFO - 2023-07-11 09:45:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:50 --> Input Class Initialized
INFO - 2023-07-11 09:45:50 --> Language Class Initialized
INFO - 2023-07-11 09:45:50 --> Loader Class Initialized
INFO - 2023-07-11 09:45:50 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:50 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:50 --> Controller Class Initialized
INFO - 2023-07-11 09:45:50 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:50 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:50 --> Total execution time: 0.0592
INFO - 2023-07-11 09:45:50 --> Config Class Initialized
INFO - 2023-07-11 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:50 --> URI Class Initialized
INFO - 2023-07-11 09:45:50 --> Router Class Initialized
INFO - 2023-07-11 09:45:50 --> Output Class Initialized
INFO - 2023-07-11 09:45:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:50 --> Input Class Initialized
INFO - 2023-07-11 09:45:50 --> Language Class Initialized
ERROR - 2023-07-11 09:45:50 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:50 --> Config Class Initialized
INFO - 2023-07-11 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:50 --> URI Class Initialized
INFO - 2023-07-11 09:45:50 --> Router Class Initialized
INFO - 2023-07-11 09:45:50 --> Output Class Initialized
INFO - 2023-07-11 09:45:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:50 --> Input Class Initialized
INFO - 2023-07-11 09:45:50 --> Language Class Initialized
INFO - 2023-07-11 09:45:50 --> Loader Class Initialized
INFO - 2023-07-11 09:45:50 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:50 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:50 --> Controller Class Initialized
INFO - 2023-07-11 09:45:50 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:50 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:50 --> Total execution time: 0.0555
INFO - 2023-07-11 09:45:50 --> Config Class Initialized
INFO - 2023-07-11 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:50 --> URI Class Initialized
INFO - 2023-07-11 09:45:50 --> Router Class Initialized
INFO - 2023-07-11 09:45:50 --> Output Class Initialized
INFO - 2023-07-11 09:45:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:50 --> Input Class Initialized
INFO - 2023-07-11 09:45:50 --> Language Class Initialized
ERROR - 2023-07-11 09:45:50 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:50 --> Config Class Initialized
INFO - 2023-07-11 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:50 --> URI Class Initialized
INFO - 2023-07-11 09:45:50 --> Router Class Initialized
INFO - 2023-07-11 09:45:50 --> Output Class Initialized
INFO - 2023-07-11 09:45:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:50 --> Input Class Initialized
INFO - 2023-07-11 09:45:50 --> Language Class Initialized
INFO - 2023-07-11 09:45:50 --> Loader Class Initialized
INFO - 2023-07-11 09:45:50 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:50 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:50 --> Controller Class Initialized
INFO - 2023-07-11 09:45:50 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:50 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:50 --> Total execution time: 0.0550
INFO - 2023-07-11 09:45:50 --> Config Class Initialized
INFO - 2023-07-11 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:50 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:50 --> URI Class Initialized
INFO - 2023-07-11 09:45:50 --> Router Class Initialized
INFO - 2023-07-11 09:45:50 --> Output Class Initialized
INFO - 2023-07-11 09:45:50 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:50 --> Input Class Initialized
INFO - 2023-07-11 09:45:50 --> Language Class Initialized
ERROR - 2023-07-11 09:45:50 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:51 --> Config Class Initialized
INFO - 2023-07-11 09:45:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:51 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:51 --> URI Class Initialized
INFO - 2023-07-11 09:45:51 --> Router Class Initialized
INFO - 2023-07-11 09:45:51 --> Output Class Initialized
INFO - 2023-07-11 09:45:51 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:51 --> Input Class Initialized
INFO - 2023-07-11 09:45:51 --> Language Class Initialized
INFO - 2023-07-11 09:45:51 --> Loader Class Initialized
INFO - 2023-07-11 09:45:51 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:51 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:51 --> Controller Class Initialized
INFO - 2023-07-11 09:45:51 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:51 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:51 --> Total execution time: 0.0569
INFO - 2023-07-11 09:45:51 --> Config Class Initialized
INFO - 2023-07-11 09:45:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:51 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:51 --> URI Class Initialized
INFO - 2023-07-11 09:45:51 --> Router Class Initialized
INFO - 2023-07-11 09:45:51 --> Output Class Initialized
INFO - 2023-07-11 09:45:51 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:51 --> Input Class Initialized
INFO - 2023-07-11 09:45:51 --> Language Class Initialized
ERROR - 2023-07-11 09:45:51 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:51 --> Config Class Initialized
INFO - 2023-07-11 09:45:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:51 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:51 --> URI Class Initialized
INFO - 2023-07-11 09:45:51 --> Router Class Initialized
INFO - 2023-07-11 09:45:51 --> Output Class Initialized
INFO - 2023-07-11 09:45:51 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:51 --> Input Class Initialized
INFO - 2023-07-11 09:45:51 --> Language Class Initialized
INFO - 2023-07-11 09:45:51 --> Loader Class Initialized
INFO - 2023-07-11 09:45:51 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:51 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:51 --> Controller Class Initialized
INFO - 2023-07-11 09:45:51 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:51 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:51 --> Total execution time: 0.0586
INFO - 2023-07-11 09:45:51 --> Config Class Initialized
INFO - 2023-07-11 09:45:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:51 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:51 --> URI Class Initialized
INFO - 2023-07-11 09:45:51 --> Router Class Initialized
INFO - 2023-07-11 09:45:51 --> Output Class Initialized
INFO - 2023-07-11 09:45:51 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:51 --> Input Class Initialized
INFO - 2023-07-11 09:45:51 --> Language Class Initialized
ERROR - 2023-07-11 09:45:51 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:45:51 --> Config Class Initialized
INFO - 2023-07-11 09:45:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:51 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:51 --> URI Class Initialized
INFO - 2023-07-11 09:45:51 --> Router Class Initialized
INFO - 2023-07-11 09:45:51 --> Output Class Initialized
INFO - 2023-07-11 09:45:51 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:51 --> Input Class Initialized
INFO - 2023-07-11 09:45:51 --> Language Class Initialized
INFO - 2023-07-11 09:45:51 --> Loader Class Initialized
INFO - 2023-07-11 09:45:51 --> Helper loaded: url_helper
INFO - 2023-07-11 09:45:51 --> Database Driver Class Initialized
INFO - 2023-07-11 09:45:51 --> Controller Class Initialized
INFO - 2023-07-11 09:45:51 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:45:51 --> Final output sent to browser
DEBUG - 2023-07-11 09:45:51 --> Total execution time: 0.0533
INFO - 2023-07-11 09:45:52 --> Config Class Initialized
INFO - 2023-07-11 09:45:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:45:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:45:52 --> Utf8 Class Initialized
INFO - 2023-07-11 09:45:52 --> URI Class Initialized
INFO - 2023-07-11 09:45:52 --> Router Class Initialized
INFO - 2023-07-11 09:45:52 --> Output Class Initialized
INFO - 2023-07-11 09:45:52 --> Security Class Initialized
DEBUG - 2023-07-11 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:45:52 --> Input Class Initialized
INFO - 2023-07-11 09:45:52 --> Language Class Initialized
ERROR - 2023-07-11 09:45:52 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:46:49 --> Config Class Initialized
INFO - 2023-07-11 09:46:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:46:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:46:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:46:49 --> URI Class Initialized
INFO - 2023-07-11 09:46:49 --> Router Class Initialized
INFO - 2023-07-11 09:46:49 --> Output Class Initialized
INFO - 2023-07-11 09:46:49 --> Security Class Initialized
DEBUG - 2023-07-11 09:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:46:49 --> Input Class Initialized
INFO - 2023-07-11 09:46:49 --> Language Class Initialized
INFO - 2023-07-11 09:46:49 --> Loader Class Initialized
INFO - 2023-07-11 09:46:49 --> Helper loaded: url_helper
INFO - 2023-07-11 09:46:49 --> Database Driver Class Initialized
INFO - 2023-07-11 09:46:49 --> Controller Class Initialized
INFO - 2023-07-11 09:46:49 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:46:49 --> Final output sent to browser
DEBUG - 2023-07-11 09:46:49 --> Total execution time: 0.0659
INFO - 2023-07-11 09:46:49 --> Config Class Initialized
INFO - 2023-07-11 09:46:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:46:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:46:49 --> Utf8 Class Initialized
INFO - 2023-07-11 09:46:49 --> URI Class Initialized
INFO - 2023-07-11 09:46:49 --> Router Class Initialized
INFO - 2023-07-11 09:46:49 --> Output Class Initialized
INFO - 2023-07-11 09:46:49 --> Security Class Initialized
DEBUG - 2023-07-11 09:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:46:49 --> Input Class Initialized
INFO - 2023-07-11 09:46:49 --> Language Class Initialized
ERROR - 2023-07-11 09:46:49 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:47:16 --> Config Class Initialized
INFO - 2023-07-11 09:47:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:47:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:47:16 --> Utf8 Class Initialized
INFO - 2023-07-11 09:47:16 --> URI Class Initialized
INFO - 2023-07-11 09:47:16 --> Router Class Initialized
INFO - 2023-07-11 09:47:16 --> Output Class Initialized
INFO - 2023-07-11 09:47:16 --> Security Class Initialized
DEBUG - 2023-07-11 09:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:47:16 --> Input Class Initialized
INFO - 2023-07-11 09:47:16 --> Language Class Initialized
INFO - 2023-07-11 09:47:16 --> Loader Class Initialized
INFO - 2023-07-11 09:47:16 --> Helper loaded: url_helper
INFO - 2023-07-11 09:47:16 --> Database Driver Class Initialized
INFO - 2023-07-11 09:47:16 --> Controller Class Initialized
INFO - 2023-07-11 09:47:16 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:47:16 --> Final output sent to browser
DEBUG - 2023-07-11 09:47:16 --> Total execution time: 0.0664
INFO - 2023-07-11 09:47:16 --> Config Class Initialized
INFO - 2023-07-11 09:47:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:47:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:47:16 --> Utf8 Class Initialized
INFO - 2023-07-11 09:47:16 --> URI Class Initialized
INFO - 2023-07-11 09:47:16 --> Router Class Initialized
INFO - 2023-07-11 09:47:16 --> Output Class Initialized
INFO - 2023-07-11 09:47:16 --> Security Class Initialized
DEBUG - 2023-07-11 09:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:47:16 --> Input Class Initialized
INFO - 2023-07-11 09:47:16 --> Language Class Initialized
ERROR - 2023-07-11 09:47:16 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:48:52 --> Config Class Initialized
INFO - 2023-07-11 09:48:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:48:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:48:52 --> Utf8 Class Initialized
INFO - 2023-07-11 09:48:52 --> URI Class Initialized
INFO - 2023-07-11 09:48:52 --> Router Class Initialized
INFO - 2023-07-11 09:48:52 --> Output Class Initialized
INFO - 2023-07-11 09:48:52 --> Security Class Initialized
DEBUG - 2023-07-11 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:48:52 --> Input Class Initialized
INFO - 2023-07-11 09:48:52 --> Language Class Initialized
INFO - 2023-07-11 09:48:52 --> Loader Class Initialized
INFO - 2023-07-11 09:48:52 --> Helper loaded: url_helper
INFO - 2023-07-11 09:48:52 --> Database Driver Class Initialized
INFO - 2023-07-11 09:48:52 --> Controller Class Initialized
INFO - 2023-07-11 09:48:52 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:48:52 --> Final output sent to browser
DEBUG - 2023-07-11 09:48:52 --> Total execution time: 0.0690
INFO - 2023-07-11 09:48:52 --> Config Class Initialized
INFO - 2023-07-11 09:48:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:48:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:48:52 --> Utf8 Class Initialized
INFO - 2023-07-11 09:48:52 --> URI Class Initialized
INFO - 2023-07-11 09:48:52 --> Router Class Initialized
INFO - 2023-07-11 09:48:52 --> Output Class Initialized
INFO - 2023-07-11 09:48:52 --> Security Class Initialized
DEBUG - 2023-07-11 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:48:52 --> Input Class Initialized
INFO - 2023-07-11 09:48:52 --> Language Class Initialized
ERROR - 2023-07-11 09:48:52 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:49:12 --> Config Class Initialized
INFO - 2023-07-11 09:49:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:49:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:49:12 --> Utf8 Class Initialized
INFO - 2023-07-11 09:49:12 --> URI Class Initialized
INFO - 2023-07-11 09:49:12 --> Router Class Initialized
INFO - 2023-07-11 09:49:12 --> Output Class Initialized
INFO - 2023-07-11 09:49:12 --> Security Class Initialized
DEBUG - 2023-07-11 09:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:49:12 --> Input Class Initialized
INFO - 2023-07-11 09:49:12 --> Language Class Initialized
INFO - 2023-07-11 09:49:12 --> Loader Class Initialized
INFO - 2023-07-11 09:49:12 --> Helper loaded: url_helper
INFO - 2023-07-11 09:49:12 --> Database Driver Class Initialized
INFO - 2023-07-11 09:49:12 --> Controller Class Initialized
INFO - 2023-07-11 09:49:12 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:49:12 --> Final output sent to browser
DEBUG - 2023-07-11 09:49:12 --> Total execution time: 0.0617
INFO - 2023-07-11 09:49:12 --> Config Class Initialized
INFO - 2023-07-11 09:49:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:49:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:49:12 --> Utf8 Class Initialized
INFO - 2023-07-11 09:49:12 --> URI Class Initialized
INFO - 2023-07-11 09:49:12 --> Router Class Initialized
INFO - 2023-07-11 09:49:12 --> Output Class Initialized
INFO - 2023-07-11 09:49:12 --> Security Class Initialized
DEBUG - 2023-07-11 09:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:49:12 --> Input Class Initialized
INFO - 2023-07-11 09:49:12 --> Language Class Initialized
ERROR - 2023-07-11 09:49:12 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:49:52 --> Config Class Initialized
INFO - 2023-07-11 09:49:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:49:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:49:52 --> Utf8 Class Initialized
INFO - 2023-07-11 09:49:52 --> URI Class Initialized
INFO - 2023-07-11 09:49:52 --> Router Class Initialized
INFO - 2023-07-11 09:49:52 --> Output Class Initialized
INFO - 2023-07-11 09:49:52 --> Security Class Initialized
DEBUG - 2023-07-11 09:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:49:52 --> Input Class Initialized
INFO - 2023-07-11 09:49:52 --> Language Class Initialized
INFO - 2023-07-11 09:49:52 --> Loader Class Initialized
INFO - 2023-07-11 09:49:52 --> Helper loaded: url_helper
INFO - 2023-07-11 09:49:52 --> Database Driver Class Initialized
INFO - 2023-07-11 09:49:52 --> Controller Class Initialized
INFO - 2023-07-11 09:49:52 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:49:52 --> Final output sent to browser
DEBUG - 2023-07-11 09:49:52 --> Total execution time: 0.0711
INFO - 2023-07-11 09:49:52 --> Config Class Initialized
INFO - 2023-07-11 09:49:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:49:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:49:52 --> Utf8 Class Initialized
INFO - 2023-07-11 09:49:52 --> URI Class Initialized
INFO - 2023-07-11 09:49:52 --> Router Class Initialized
INFO - 2023-07-11 09:49:52 --> Output Class Initialized
INFO - 2023-07-11 09:49:52 --> Security Class Initialized
DEBUG - 2023-07-11 09:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:49:52 --> Input Class Initialized
INFO - 2023-07-11 09:49:52 --> Language Class Initialized
ERROR - 2023-07-11 09:49:52 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:51:33 --> Config Class Initialized
INFO - 2023-07-11 09:51:33 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:51:33 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:51:33 --> Utf8 Class Initialized
INFO - 2023-07-11 09:51:33 --> URI Class Initialized
INFO - 2023-07-11 09:51:33 --> Router Class Initialized
INFO - 2023-07-11 09:51:33 --> Output Class Initialized
INFO - 2023-07-11 09:51:33 --> Security Class Initialized
DEBUG - 2023-07-11 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:51:33 --> Input Class Initialized
INFO - 2023-07-11 09:51:33 --> Language Class Initialized
INFO - 2023-07-11 09:51:33 --> Loader Class Initialized
INFO - 2023-07-11 09:51:33 --> Helper loaded: url_helper
INFO - 2023-07-11 09:51:33 --> Database Driver Class Initialized
INFO - 2023-07-11 09:51:33 --> Controller Class Initialized
INFO - 2023-07-11 09:51:33 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:51:33 --> Final output sent to browser
DEBUG - 2023-07-11 09:51:33 --> Total execution time: 0.0807
INFO - 2023-07-11 09:51:33 --> Config Class Initialized
INFO - 2023-07-11 09:51:33 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:51:33 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:51:33 --> Utf8 Class Initialized
INFO - 2023-07-11 09:51:33 --> URI Class Initialized
INFO - 2023-07-11 09:51:33 --> Router Class Initialized
INFO - 2023-07-11 09:51:33 --> Output Class Initialized
INFO - 2023-07-11 09:51:33 --> Security Class Initialized
DEBUG - 2023-07-11 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:51:33 --> Input Class Initialized
INFO - 2023-07-11 09:51:33 --> Language Class Initialized
ERROR - 2023-07-11 09:51:33 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:51:56 --> Config Class Initialized
INFO - 2023-07-11 09:51:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:51:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:51:56 --> Utf8 Class Initialized
INFO - 2023-07-11 09:51:56 --> URI Class Initialized
INFO - 2023-07-11 09:51:56 --> Router Class Initialized
INFO - 2023-07-11 09:51:56 --> Output Class Initialized
INFO - 2023-07-11 09:51:56 --> Security Class Initialized
DEBUG - 2023-07-11 09:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:51:56 --> Input Class Initialized
INFO - 2023-07-11 09:51:56 --> Language Class Initialized
INFO - 2023-07-11 09:51:56 --> Loader Class Initialized
INFO - 2023-07-11 09:51:56 --> Helper loaded: url_helper
INFO - 2023-07-11 09:51:56 --> Database Driver Class Initialized
INFO - 2023-07-11 09:51:56 --> Controller Class Initialized
INFO - 2023-07-11 09:51:56 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:51:56 --> Final output sent to browser
DEBUG - 2023-07-11 09:51:56 --> Total execution time: 0.0725
INFO - 2023-07-11 09:51:56 --> Config Class Initialized
INFO - 2023-07-11 09:51:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:51:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:51:56 --> Utf8 Class Initialized
INFO - 2023-07-11 09:51:56 --> URI Class Initialized
INFO - 2023-07-11 09:51:56 --> Router Class Initialized
INFO - 2023-07-11 09:51:56 --> Output Class Initialized
INFO - 2023-07-11 09:51:56 --> Security Class Initialized
DEBUG - 2023-07-11 09:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:51:56 --> Input Class Initialized
INFO - 2023-07-11 09:51:56 --> Language Class Initialized
ERROR - 2023-07-11 09:51:56 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:53:06 --> Config Class Initialized
INFO - 2023-07-11 09:53:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:06 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:06 --> URI Class Initialized
INFO - 2023-07-11 09:53:06 --> Router Class Initialized
INFO - 2023-07-11 09:53:06 --> Output Class Initialized
INFO - 2023-07-11 09:53:06 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:06 --> Input Class Initialized
INFO - 2023-07-11 09:53:06 --> Language Class Initialized
INFO - 2023-07-11 09:53:06 --> Loader Class Initialized
INFO - 2023-07-11 09:53:06 --> Helper loaded: url_helper
INFO - 2023-07-11 09:53:06 --> Database Driver Class Initialized
INFO - 2023-07-11 09:53:06 --> Controller Class Initialized
INFO - 2023-07-11 09:53:06 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:53:06 --> Final output sent to browser
DEBUG - 2023-07-11 09:53:06 --> Total execution time: 0.0725
INFO - 2023-07-11 09:53:06 --> Config Class Initialized
INFO - 2023-07-11 09:53:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:06 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:06 --> URI Class Initialized
INFO - 2023-07-11 09:53:06 --> Router Class Initialized
INFO - 2023-07-11 09:53:06 --> Output Class Initialized
INFO - 2023-07-11 09:53:06 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:06 --> Input Class Initialized
INFO - 2023-07-11 09:53:06 --> Language Class Initialized
ERROR - 2023-07-11 09:53:06 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:53:07 --> Config Class Initialized
INFO - 2023-07-11 09:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:07 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:07 --> URI Class Initialized
INFO - 2023-07-11 09:53:07 --> Router Class Initialized
INFO - 2023-07-11 09:53:07 --> Output Class Initialized
INFO - 2023-07-11 09:53:07 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:07 --> Input Class Initialized
INFO - 2023-07-11 09:53:07 --> Language Class Initialized
INFO - 2023-07-11 09:53:07 --> Loader Class Initialized
INFO - 2023-07-11 09:53:07 --> Helper loaded: url_helper
INFO - 2023-07-11 09:53:07 --> Database Driver Class Initialized
INFO - 2023-07-11 09:53:07 --> Controller Class Initialized
INFO - 2023-07-11 09:53:07 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:53:07 --> Final output sent to browser
DEBUG - 2023-07-11 09:53:07 --> Total execution time: 0.0582
INFO - 2023-07-11 09:53:07 --> Config Class Initialized
INFO - 2023-07-11 09:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:07 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:07 --> URI Class Initialized
INFO - 2023-07-11 09:53:07 --> Router Class Initialized
INFO - 2023-07-11 09:53:07 --> Output Class Initialized
INFO - 2023-07-11 09:53:07 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:07 --> Input Class Initialized
INFO - 2023-07-11 09:53:07 --> Language Class Initialized
ERROR - 2023-07-11 09:53:07 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:53:07 --> Config Class Initialized
INFO - 2023-07-11 09:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:07 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:07 --> URI Class Initialized
INFO - 2023-07-11 09:53:07 --> Router Class Initialized
INFO - 2023-07-11 09:53:07 --> Output Class Initialized
INFO - 2023-07-11 09:53:07 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:07 --> Input Class Initialized
INFO - 2023-07-11 09:53:07 --> Language Class Initialized
INFO - 2023-07-11 09:53:07 --> Loader Class Initialized
INFO - 2023-07-11 09:53:07 --> Helper loaded: url_helper
INFO - 2023-07-11 09:53:07 --> Database Driver Class Initialized
INFO - 2023-07-11 09:53:07 --> Controller Class Initialized
INFO - 2023-07-11 09:53:07 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:53:07 --> Final output sent to browser
DEBUG - 2023-07-11 09:53:07 --> Total execution time: 0.0522
INFO - 2023-07-11 09:53:07 --> Config Class Initialized
INFO - 2023-07-11 09:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:07 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:07 --> URI Class Initialized
INFO - 2023-07-11 09:53:07 --> Router Class Initialized
INFO - 2023-07-11 09:53:07 --> Output Class Initialized
INFO - 2023-07-11 09:53:07 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:07 --> Input Class Initialized
INFO - 2023-07-11 09:53:07 --> Language Class Initialized
ERROR - 2023-07-11 09:53:07 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:53:09 --> Config Class Initialized
INFO - 2023-07-11 09:53:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:09 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:09 --> URI Class Initialized
INFO - 2023-07-11 09:53:09 --> Router Class Initialized
INFO - 2023-07-11 09:53:09 --> Output Class Initialized
INFO - 2023-07-11 09:53:09 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:09 --> Input Class Initialized
INFO - 2023-07-11 09:53:09 --> Language Class Initialized
INFO - 2023-07-11 09:53:09 --> Loader Class Initialized
INFO - 2023-07-11 09:53:09 --> Helper loaded: url_helper
INFO - 2023-07-11 09:53:09 --> Database Driver Class Initialized
INFO - 2023-07-11 09:53:09 --> Controller Class Initialized
INFO - 2023-07-11 09:53:09 --> File loaded: C:\xampp\htdocs\code\application\views\/login.php
INFO - 2023-07-11 09:53:09 --> Final output sent to browser
DEBUG - 2023-07-11 09:53:09 --> Total execution time: 0.0549
INFO - 2023-07-11 09:53:09 --> Config Class Initialized
INFO - 2023-07-11 09:53:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:09 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:09 --> URI Class Initialized
INFO - 2023-07-11 09:53:09 --> Router Class Initialized
INFO - 2023-07-11 09:53:09 --> Output Class Initialized
INFO - 2023-07-11 09:53:09 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:09 --> Input Class Initialized
INFO - 2023-07-11 09:53:09 --> Language Class Initialized
ERROR - 2023-07-11 09:53:09 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:53:56 --> Config Class Initialized
INFO - 2023-07-11 09:53:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:56 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:56 --> URI Class Initialized
INFO - 2023-07-11 09:53:56 --> Router Class Initialized
INFO - 2023-07-11 09:53:56 --> Output Class Initialized
INFO - 2023-07-11 09:53:56 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:56 --> Input Class Initialized
INFO - 2023-07-11 09:53:56 --> Language Class Initialized
INFO - 2023-07-11 09:53:56 --> Loader Class Initialized
INFO - 2023-07-11 09:53:56 --> Helper loaded: url_helper
INFO - 2023-07-11 09:53:56 --> Database Driver Class Initialized
INFO - 2023-07-11 09:53:56 --> Controller Class Initialized
INFO - 2023-07-11 09:53:56 --> File loaded: C:\xampp\htdocs\code\application\views\/login.php
INFO - 2023-07-11 09:53:56 --> Final output sent to browser
DEBUG - 2023-07-11 09:53:56 --> Total execution time: 0.0610
INFO - 2023-07-11 09:53:56 --> Config Class Initialized
INFO - 2023-07-11 09:53:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:53:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:53:56 --> Utf8 Class Initialized
INFO - 2023-07-11 09:53:56 --> URI Class Initialized
INFO - 2023-07-11 09:53:56 --> Router Class Initialized
INFO - 2023-07-11 09:53:56 --> Output Class Initialized
INFO - 2023-07-11 09:53:56 --> Security Class Initialized
DEBUG - 2023-07-11 09:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:53:56 --> Input Class Initialized
INFO - 2023-07-11 09:53:56 --> Language Class Initialized
ERROR - 2023-07-11 09:53:56 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:54:34 --> Config Class Initialized
INFO - 2023-07-11 09:54:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:34 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:34 --> URI Class Initialized
INFO - 2023-07-11 09:54:34 --> Router Class Initialized
INFO - 2023-07-11 09:54:34 --> Output Class Initialized
INFO - 2023-07-11 09:54:34 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:34 --> Input Class Initialized
INFO - 2023-07-11 09:54:34 --> Language Class Initialized
INFO - 2023-07-11 09:54:34 --> Loader Class Initialized
INFO - 2023-07-11 09:54:35 --> Helper loaded: url_helper
INFO - 2023-07-11 09:54:35 --> Database Driver Class Initialized
INFO - 2023-07-11 09:54:35 --> Controller Class Initialized
INFO - 2023-07-11 09:54:35 --> File loaded: C:\xampp\htdocs\code\application\views\/login.php
INFO - 2023-07-11 09:54:35 --> Final output sent to browser
DEBUG - 2023-07-11 09:54:35 --> Total execution time: 0.0695
INFO - 2023-07-11 09:54:35 --> Config Class Initialized
INFO - 2023-07-11 09:54:35 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:35 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:35 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:35 --> URI Class Initialized
INFO - 2023-07-11 09:54:35 --> Router Class Initialized
INFO - 2023-07-11 09:54:35 --> Output Class Initialized
INFO - 2023-07-11 09:54:35 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:35 --> Input Class Initialized
INFO - 2023-07-11 09:54:35 --> Language Class Initialized
ERROR - 2023-07-11 09:54:35 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:54:37 --> Config Class Initialized
INFO - 2023-07-11 09:54:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:37 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:37 --> URI Class Initialized
INFO - 2023-07-11 09:54:37 --> Router Class Initialized
INFO - 2023-07-11 09:54:37 --> Output Class Initialized
INFO - 2023-07-11 09:54:37 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:37 --> Input Class Initialized
INFO - 2023-07-11 09:54:37 --> Language Class Initialized
INFO - 2023-07-11 09:54:37 --> Loader Class Initialized
INFO - 2023-07-11 09:54:37 --> Helper loaded: url_helper
INFO - 2023-07-11 09:54:37 --> Database Driver Class Initialized
INFO - 2023-07-11 09:54:37 --> Controller Class Initialized
INFO - 2023-07-11 09:54:37 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:54:37 --> Final output sent to browser
DEBUG - 2023-07-11 09:54:37 --> Total execution time: 0.0673
INFO - 2023-07-11 09:54:37 --> Config Class Initialized
INFO - 2023-07-11 09:54:37 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:37 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:37 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:37 --> URI Class Initialized
INFO - 2023-07-11 09:54:37 --> Router Class Initialized
INFO - 2023-07-11 09:54:37 --> Output Class Initialized
INFO - 2023-07-11 09:54:37 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:37 --> Input Class Initialized
INFO - 2023-07-11 09:54:37 --> Language Class Initialized
ERROR - 2023-07-11 09:54:37 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:54:45 --> Config Class Initialized
INFO - 2023-07-11 09:54:45 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:45 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:45 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:45 --> URI Class Initialized
INFO - 2023-07-11 09:54:45 --> Router Class Initialized
INFO - 2023-07-11 09:54:45 --> Output Class Initialized
INFO - 2023-07-11 09:54:45 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:45 --> Input Class Initialized
INFO - 2023-07-11 09:54:45 --> Language Class Initialized
INFO - 2023-07-11 09:54:45 --> Loader Class Initialized
INFO - 2023-07-11 09:54:45 --> Helper loaded: url_helper
INFO - 2023-07-11 09:54:46 --> Database Driver Class Initialized
INFO - 2023-07-11 09:54:46 --> Controller Class Initialized
INFO - 2023-07-11 09:54:46 --> File loaded: C:\xampp\htdocs\code\application\views\/login.php
INFO - 2023-07-11 09:54:46 --> Final output sent to browser
DEBUG - 2023-07-11 09:54:46 --> Total execution time: 0.0518
INFO - 2023-07-11 09:54:46 --> Config Class Initialized
INFO - 2023-07-11 09:54:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:46 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:46 --> URI Class Initialized
INFO - 2023-07-11 09:54:46 --> Router Class Initialized
INFO - 2023-07-11 09:54:46 --> Output Class Initialized
INFO - 2023-07-11 09:54:46 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:46 --> Input Class Initialized
INFO - 2023-07-11 09:54:46 --> Language Class Initialized
ERROR - 2023-07-11 09:54:46 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 09:54:47 --> Config Class Initialized
INFO - 2023-07-11 09:54:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:47 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:47 --> URI Class Initialized
INFO - 2023-07-11 09:54:47 --> Router Class Initialized
INFO - 2023-07-11 09:54:47 --> Output Class Initialized
INFO - 2023-07-11 09:54:47 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:47 --> Input Class Initialized
INFO - 2023-07-11 09:54:47 --> Language Class Initialized
INFO - 2023-07-11 09:54:47 --> Loader Class Initialized
INFO - 2023-07-11 09:54:47 --> Helper loaded: url_helper
INFO - 2023-07-11 09:54:47 --> Database Driver Class Initialized
INFO - 2023-07-11 09:54:47 --> Controller Class Initialized
INFO - 2023-07-11 09:54:47 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 09:54:47 --> Final output sent to browser
DEBUG - 2023-07-11 09:54:47 --> Total execution time: 0.0549
INFO - 2023-07-11 09:54:48 --> Config Class Initialized
INFO - 2023-07-11 09:54:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:54:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:54:48 --> Utf8 Class Initialized
INFO - 2023-07-11 09:54:48 --> URI Class Initialized
INFO - 2023-07-11 09:54:48 --> Router Class Initialized
INFO - 2023-07-11 09:54:48 --> Output Class Initialized
INFO - 2023-07-11 09:54:48 --> Security Class Initialized
DEBUG - 2023-07-11 09:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:54:48 --> Input Class Initialized
INFO - 2023-07-11 09:54:48 --> Language Class Initialized
ERROR - 2023-07-11 09:54:48 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:30:05 --> Config Class Initialized
INFO - 2023-07-11 10:30:05 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:30:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:30:06 --> Utf8 Class Initialized
INFO - 2023-07-11 10:30:06 --> URI Class Initialized
INFO - 2023-07-11 10:30:06 --> Router Class Initialized
INFO - 2023-07-11 10:30:06 --> Output Class Initialized
INFO - 2023-07-11 10:30:06 --> Security Class Initialized
DEBUG - 2023-07-11 10:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:30:06 --> Input Class Initialized
INFO - 2023-07-11 10:30:06 --> Language Class Initialized
INFO - 2023-07-11 10:30:06 --> Loader Class Initialized
INFO - 2023-07-11 10:30:06 --> Helper loaded: url_helper
INFO - 2023-07-11 10:30:06 --> Database Driver Class Initialized
INFO - 2023-07-11 10:30:06 --> Controller Class Initialized
INFO - 2023-07-11 10:30:06 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:30:06 --> Final output sent to browser
DEBUG - 2023-07-11 10:30:06 --> Total execution time: 0.5194
INFO - 2023-07-11 10:30:07 --> Config Class Initialized
INFO - 2023-07-11 10:30:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:30:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:30:07 --> Utf8 Class Initialized
INFO - 2023-07-11 10:30:07 --> URI Class Initialized
INFO - 2023-07-11 10:30:07 --> Router Class Initialized
INFO - 2023-07-11 10:30:07 --> Output Class Initialized
INFO - 2023-07-11 10:30:07 --> Security Class Initialized
DEBUG - 2023-07-11 10:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:30:07 --> Input Class Initialized
INFO - 2023-07-11 10:30:07 --> Language Class Initialized
ERROR - 2023-07-11 10:30:07 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:31:02 --> Config Class Initialized
INFO - 2023-07-11 10:31:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:31:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:31:02 --> Utf8 Class Initialized
INFO - 2023-07-11 10:31:02 --> URI Class Initialized
INFO - 2023-07-11 10:31:02 --> Router Class Initialized
INFO - 2023-07-11 10:31:02 --> Output Class Initialized
INFO - 2023-07-11 10:31:02 --> Security Class Initialized
DEBUG - 2023-07-11 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:31:02 --> Input Class Initialized
INFO - 2023-07-11 10:31:02 --> Language Class Initialized
INFO - 2023-07-11 10:31:02 --> Loader Class Initialized
INFO - 2023-07-11 10:31:02 --> Helper loaded: url_helper
INFO - 2023-07-11 10:31:02 --> Database Driver Class Initialized
INFO - 2023-07-11 10:31:02 --> Controller Class Initialized
INFO - 2023-07-11 10:31:02 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:31:02 --> Final output sent to browser
DEBUG - 2023-07-11 10:31:02 --> Total execution time: 0.7781
INFO - 2023-07-11 10:31:02 --> Config Class Initialized
INFO - 2023-07-11 10:31:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:31:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:31:02 --> Utf8 Class Initialized
INFO - 2023-07-11 10:31:02 --> URI Class Initialized
INFO - 2023-07-11 10:31:02 --> Router Class Initialized
INFO - 2023-07-11 10:31:02 --> Output Class Initialized
INFO - 2023-07-11 10:31:02 --> Security Class Initialized
DEBUG - 2023-07-11 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:31:02 --> Input Class Initialized
INFO - 2023-07-11 10:31:02 --> Language Class Initialized
ERROR - 2023-07-11 10:31:02 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:32:53 --> Config Class Initialized
INFO - 2023-07-11 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:53 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:53 --> URI Class Initialized
INFO - 2023-07-11 10:32:53 --> Router Class Initialized
INFO - 2023-07-11 10:32:53 --> Output Class Initialized
INFO - 2023-07-11 10:32:53 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:53 --> Input Class Initialized
INFO - 2023-07-11 10:32:53 --> Language Class Initialized
INFO - 2023-07-11 10:32:53 --> Loader Class Initialized
INFO - 2023-07-11 10:32:53 --> Helper loaded: url_helper
INFO - 2023-07-11 10:32:53 --> Database Driver Class Initialized
INFO - 2023-07-11 10:32:53 --> Controller Class Initialized
INFO - 2023-07-11 10:32:53 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:32:53 --> Final output sent to browser
DEBUG - 2023-07-11 10:32:53 --> Total execution time: 0.0676
INFO - 2023-07-11 10:32:53 --> Config Class Initialized
INFO - 2023-07-11 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:53 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:53 --> URI Class Initialized
INFO - 2023-07-11 10:32:53 --> Router Class Initialized
INFO - 2023-07-11 10:32:53 --> Output Class Initialized
INFO - 2023-07-11 10:32:53 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:53 --> Input Class Initialized
INFO - 2023-07-11 10:32:53 --> Language Class Initialized
ERROR - 2023-07-11 10:32:53 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:32:53 --> Config Class Initialized
INFO - 2023-07-11 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:53 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:53 --> URI Class Initialized
INFO - 2023-07-11 10:32:53 --> Router Class Initialized
INFO - 2023-07-11 10:32:53 --> Output Class Initialized
INFO - 2023-07-11 10:32:53 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:53 --> Input Class Initialized
INFO - 2023-07-11 10:32:53 --> Language Class Initialized
INFO - 2023-07-11 10:32:53 --> Loader Class Initialized
INFO - 2023-07-11 10:32:53 --> Helper loaded: url_helper
INFO - 2023-07-11 10:32:53 --> Database Driver Class Initialized
INFO - 2023-07-11 10:32:53 --> Controller Class Initialized
INFO - 2023-07-11 10:32:53 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:32:53 --> Final output sent to browser
DEBUG - 2023-07-11 10:32:53 --> Total execution time: 0.0547
INFO - 2023-07-11 10:32:53 --> Config Class Initialized
INFO - 2023-07-11 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:53 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:53 --> URI Class Initialized
INFO - 2023-07-11 10:32:53 --> Router Class Initialized
INFO - 2023-07-11 10:32:53 --> Output Class Initialized
INFO - 2023-07-11 10:32:53 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:53 --> Input Class Initialized
INFO - 2023-07-11 10:32:53 --> Language Class Initialized
ERROR - 2023-07-11 10:32:53 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:32:53 --> Config Class Initialized
INFO - 2023-07-11 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:53 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:53 --> URI Class Initialized
INFO - 2023-07-11 10:32:53 --> Router Class Initialized
INFO - 2023-07-11 10:32:53 --> Output Class Initialized
INFO - 2023-07-11 10:32:53 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:53 --> Input Class Initialized
INFO - 2023-07-11 10:32:53 --> Language Class Initialized
INFO - 2023-07-11 10:32:53 --> Loader Class Initialized
INFO - 2023-07-11 10:32:53 --> Helper loaded: url_helper
INFO - 2023-07-11 10:32:53 --> Database Driver Class Initialized
INFO - 2023-07-11 10:32:53 --> Controller Class Initialized
INFO - 2023-07-11 10:32:53 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:32:53 --> Final output sent to browser
DEBUG - 2023-07-11 10:32:53 --> Total execution time: 0.0499
INFO - 2023-07-11 10:32:53 --> Config Class Initialized
INFO - 2023-07-11 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:53 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:53 --> URI Class Initialized
INFO - 2023-07-11 10:32:53 --> Router Class Initialized
INFO - 2023-07-11 10:32:53 --> Output Class Initialized
INFO - 2023-07-11 10:32:53 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:54 --> Input Class Initialized
INFO - 2023-07-11 10:32:54 --> Language Class Initialized
ERROR - 2023-07-11 10:32:54 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:32:54 --> Config Class Initialized
INFO - 2023-07-11 10:32:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:54 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:54 --> URI Class Initialized
INFO - 2023-07-11 10:32:54 --> Router Class Initialized
INFO - 2023-07-11 10:32:54 --> Output Class Initialized
INFO - 2023-07-11 10:32:54 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:54 --> Input Class Initialized
INFO - 2023-07-11 10:32:54 --> Language Class Initialized
INFO - 2023-07-11 10:32:54 --> Loader Class Initialized
INFO - 2023-07-11 10:32:54 --> Helper loaded: url_helper
INFO - 2023-07-11 10:32:54 --> Database Driver Class Initialized
INFO - 2023-07-11 10:32:54 --> Controller Class Initialized
INFO - 2023-07-11 10:32:54 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:32:54 --> Final output sent to browser
DEBUG - 2023-07-11 10:32:54 --> Total execution time: 0.0665
INFO - 2023-07-11 10:32:54 --> Config Class Initialized
INFO - 2023-07-11 10:32:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:32:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:32:54 --> Utf8 Class Initialized
INFO - 2023-07-11 10:32:54 --> URI Class Initialized
INFO - 2023-07-11 10:32:54 --> Router Class Initialized
INFO - 2023-07-11 10:32:54 --> Output Class Initialized
INFO - 2023-07-11 10:32:54 --> Security Class Initialized
DEBUG - 2023-07-11 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:32:54 --> Input Class Initialized
INFO - 2023-07-11 10:32:54 --> Language Class Initialized
ERROR - 2023-07-11 10:32:54 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:33:06 --> Config Class Initialized
INFO - 2023-07-11 10:33:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:33:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:33:06 --> Utf8 Class Initialized
INFO - 2023-07-11 10:33:06 --> URI Class Initialized
INFO - 2023-07-11 10:33:06 --> Router Class Initialized
INFO - 2023-07-11 10:33:06 --> Output Class Initialized
INFO - 2023-07-11 10:33:06 --> Security Class Initialized
DEBUG - 2023-07-11 10:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:33:06 --> Input Class Initialized
INFO - 2023-07-11 10:33:06 --> Language Class Initialized
INFO - 2023-07-11 10:33:06 --> Loader Class Initialized
INFO - 2023-07-11 10:33:06 --> Helper loaded: url_helper
INFO - 2023-07-11 10:33:06 --> Database Driver Class Initialized
INFO - 2023-07-11 10:33:06 --> Controller Class Initialized
INFO - 2023-07-11 10:33:06 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:33:06 --> Final output sent to browser
DEBUG - 2023-07-11 10:33:06 --> Total execution time: 0.0576
INFO - 2023-07-11 10:33:07 --> Config Class Initialized
INFO - 2023-07-11 10:33:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:33:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:33:07 --> Utf8 Class Initialized
INFO - 2023-07-11 10:33:07 --> URI Class Initialized
INFO - 2023-07-11 10:33:07 --> Router Class Initialized
INFO - 2023-07-11 10:33:07 --> Output Class Initialized
INFO - 2023-07-11 10:33:07 --> Security Class Initialized
DEBUG - 2023-07-11 10:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:33:07 --> Input Class Initialized
INFO - 2023-07-11 10:33:07 --> Language Class Initialized
ERROR - 2023-07-11 10:33:07 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:34:57 --> Config Class Initialized
INFO - 2023-07-11 10:34:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:34:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:34:57 --> Utf8 Class Initialized
INFO - 2023-07-11 10:34:57 --> URI Class Initialized
INFO - 2023-07-11 10:34:57 --> Router Class Initialized
INFO - 2023-07-11 10:34:57 --> Output Class Initialized
INFO - 2023-07-11 10:34:57 --> Security Class Initialized
DEBUG - 2023-07-11 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:34:57 --> Input Class Initialized
INFO - 2023-07-11 10:34:57 --> Language Class Initialized
INFO - 2023-07-11 10:34:57 --> Loader Class Initialized
INFO - 2023-07-11 10:34:57 --> Helper loaded: url_helper
INFO - 2023-07-11 10:34:57 --> Database Driver Class Initialized
INFO - 2023-07-11 10:34:57 --> Controller Class Initialized
INFO - 2023-07-11 10:34:57 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:34:57 --> Final output sent to browser
DEBUG - 2023-07-11 10:34:57 --> Total execution time: 0.0706
INFO - 2023-07-11 10:34:57 --> Config Class Initialized
INFO - 2023-07-11 10:34:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:34:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:34:57 --> Utf8 Class Initialized
INFO - 2023-07-11 10:34:57 --> URI Class Initialized
INFO - 2023-07-11 10:34:57 --> Router Class Initialized
INFO - 2023-07-11 10:34:57 --> Output Class Initialized
INFO - 2023-07-11 10:34:57 --> Security Class Initialized
DEBUG - 2023-07-11 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:34:57 --> Input Class Initialized
INFO - 2023-07-11 10:34:57 --> Language Class Initialized
ERROR - 2023-07-11 10:34:57 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:35:18 --> Config Class Initialized
INFO - 2023-07-11 10:35:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:35:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:35:18 --> Utf8 Class Initialized
INFO - 2023-07-11 10:35:18 --> URI Class Initialized
INFO - 2023-07-11 10:35:18 --> Router Class Initialized
INFO - 2023-07-11 10:35:18 --> Output Class Initialized
INFO - 2023-07-11 10:35:18 --> Security Class Initialized
DEBUG - 2023-07-11 10:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:35:18 --> Input Class Initialized
INFO - 2023-07-11 10:35:18 --> Language Class Initialized
INFO - 2023-07-11 10:35:18 --> Loader Class Initialized
INFO - 2023-07-11 10:35:18 --> Helper loaded: url_helper
INFO - 2023-07-11 10:35:18 --> Database Driver Class Initialized
INFO - 2023-07-11 10:35:18 --> Controller Class Initialized
INFO - 2023-07-11 10:35:18 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:35:18 --> Final output sent to browser
DEBUG - 2023-07-11 10:35:18 --> Total execution time: 0.0682
INFO - 2023-07-11 10:35:18 --> Config Class Initialized
INFO - 2023-07-11 10:35:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:35:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:35:18 --> Utf8 Class Initialized
INFO - 2023-07-11 10:35:18 --> URI Class Initialized
INFO - 2023-07-11 10:35:18 --> Router Class Initialized
INFO - 2023-07-11 10:35:18 --> Output Class Initialized
INFO - 2023-07-11 10:35:18 --> Security Class Initialized
DEBUG - 2023-07-11 10:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:35:18 --> Input Class Initialized
INFO - 2023-07-11 10:35:18 --> Language Class Initialized
ERROR - 2023-07-11 10:35:18 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:35:27 --> Config Class Initialized
INFO - 2023-07-11 10:35:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:35:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:35:27 --> Utf8 Class Initialized
INFO - 2023-07-11 10:35:27 --> URI Class Initialized
INFO - 2023-07-11 10:35:27 --> Router Class Initialized
INFO - 2023-07-11 10:35:27 --> Output Class Initialized
INFO - 2023-07-11 10:35:27 --> Security Class Initialized
DEBUG - 2023-07-11 10:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:35:27 --> Input Class Initialized
INFO - 2023-07-11 10:35:27 --> Language Class Initialized
INFO - 2023-07-11 10:35:27 --> Loader Class Initialized
INFO - 2023-07-11 10:35:27 --> Helper loaded: url_helper
INFO - 2023-07-11 10:35:27 --> Database Driver Class Initialized
INFO - 2023-07-11 10:35:27 --> Controller Class Initialized
INFO - 2023-07-11 10:35:27 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:35:27 --> Final output sent to browser
DEBUG - 2023-07-11 10:35:27 --> Total execution time: 0.0496
INFO - 2023-07-11 10:35:27 --> Config Class Initialized
INFO - 2023-07-11 10:35:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:35:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:35:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:35:28 --> URI Class Initialized
INFO - 2023-07-11 10:35:28 --> Router Class Initialized
INFO - 2023-07-11 10:35:28 --> Output Class Initialized
INFO - 2023-07-11 10:35:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:35:28 --> Input Class Initialized
INFO - 2023-07-11 10:35:28 --> Language Class Initialized
ERROR - 2023-07-11 10:35:28 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:35:28 --> Config Class Initialized
INFO - 2023-07-11 10:35:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:35:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:35:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:35:28 --> URI Class Initialized
INFO - 2023-07-11 10:35:28 --> Router Class Initialized
INFO - 2023-07-11 10:35:28 --> Output Class Initialized
INFO - 2023-07-11 10:35:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:35:28 --> Input Class Initialized
INFO - 2023-07-11 10:35:28 --> Language Class Initialized
INFO - 2023-07-11 10:35:29 --> Loader Class Initialized
INFO - 2023-07-11 10:35:29 --> Helper loaded: url_helper
INFO - 2023-07-11 10:35:29 --> Database Driver Class Initialized
INFO - 2023-07-11 10:35:29 --> Controller Class Initialized
INFO - 2023-07-11 10:35:29 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:35:29 --> Final output sent to browser
DEBUG - 2023-07-11 10:35:29 --> Total execution time: 0.0539
INFO - 2023-07-11 10:35:29 --> Config Class Initialized
INFO - 2023-07-11 10:35:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:35:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:35:29 --> Utf8 Class Initialized
INFO - 2023-07-11 10:35:29 --> URI Class Initialized
INFO - 2023-07-11 10:35:29 --> Router Class Initialized
INFO - 2023-07-11 10:35:29 --> Output Class Initialized
INFO - 2023-07-11 10:35:29 --> Security Class Initialized
DEBUG - 2023-07-11 10:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:35:29 --> Input Class Initialized
INFO - 2023-07-11 10:35:29 --> Language Class Initialized
ERROR - 2023-07-11 10:35:29 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:35:32 --> Config Class Initialized
INFO - 2023-07-11 10:35:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:35:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:35:32 --> Utf8 Class Initialized
INFO - 2023-07-11 10:35:32 --> URI Class Initialized
INFO - 2023-07-11 10:35:32 --> Router Class Initialized
INFO - 2023-07-11 10:35:32 --> Output Class Initialized
INFO - 2023-07-11 10:35:32 --> Security Class Initialized
DEBUG - 2023-07-11 10:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:35:32 --> Input Class Initialized
INFO - 2023-07-11 10:35:32 --> Language Class Initialized
ERROR - 2023-07-11 10:35:32 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:36:17 --> Config Class Initialized
INFO - 2023-07-11 10:36:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:17 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:17 --> URI Class Initialized
INFO - 2023-07-11 10:36:17 --> Router Class Initialized
INFO - 2023-07-11 10:36:17 --> Output Class Initialized
INFO - 2023-07-11 10:36:17 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:17 --> Input Class Initialized
INFO - 2023-07-11 10:36:17 --> Language Class Initialized
INFO - 2023-07-11 10:36:17 --> Loader Class Initialized
INFO - 2023-07-11 10:36:17 --> Helper loaded: url_helper
INFO - 2023-07-11 10:36:17 --> Database Driver Class Initialized
INFO - 2023-07-11 10:36:17 --> Controller Class Initialized
INFO - 2023-07-11 10:36:17 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:36:17 --> Final output sent to browser
DEBUG - 2023-07-11 10:36:17 --> Total execution time: 0.0583
INFO - 2023-07-11 10:36:17 --> Config Class Initialized
INFO - 2023-07-11 10:36:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:17 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:17 --> URI Class Initialized
INFO - 2023-07-11 10:36:17 --> Router Class Initialized
INFO - 2023-07-11 10:36:17 --> Output Class Initialized
INFO - 2023-07-11 10:36:17 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:17 --> Input Class Initialized
INFO - 2023-07-11 10:36:17 --> Language Class Initialized
ERROR - 2023-07-11 10:36:17 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:36:26 --> Config Class Initialized
INFO - 2023-07-11 10:36:26 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:26 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:26 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:26 --> URI Class Initialized
INFO - 2023-07-11 10:36:26 --> Router Class Initialized
INFO - 2023-07-11 10:36:26 --> Output Class Initialized
INFO - 2023-07-11 10:36:26 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:26 --> Input Class Initialized
INFO - 2023-07-11 10:36:26 --> Language Class Initialized
INFO - 2023-07-11 10:36:26 --> Loader Class Initialized
INFO - 2023-07-11 10:36:26 --> Helper loaded: url_helper
INFO - 2023-07-11 10:36:26 --> Database Driver Class Initialized
INFO - 2023-07-11 10:36:26 --> Controller Class Initialized
INFO - 2023-07-11 10:36:26 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:36:26 --> Final output sent to browser
DEBUG - 2023-07-11 10:36:26 --> Total execution time: 0.0574
INFO - 2023-07-11 10:36:26 --> Config Class Initialized
INFO - 2023-07-11 10:36:26 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:26 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:26 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:26 --> URI Class Initialized
INFO - 2023-07-11 10:36:26 --> Router Class Initialized
INFO - 2023-07-11 10:36:26 --> Output Class Initialized
INFO - 2023-07-11 10:36:26 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:26 --> Input Class Initialized
INFO - 2023-07-11 10:36:26 --> Language Class Initialized
ERROR - 2023-07-11 10:36:26 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:28 --> Language Class Initialized
INFO - 2023-07-11 10:36:28 --> Loader Class Initialized
INFO - 2023-07-11 10:36:28 --> Helper loaded: url_helper
INFO - 2023-07-11 10:36:28 --> Database Driver Class Initialized
INFO - 2023-07-11 10:36:28 --> Controller Class Initialized
INFO - 2023-07-11 10:36:28 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:36:28 --> Final output sent to browser
DEBUG - 2023-07-11 10:36:28 --> Total execution time: 0.0538
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:28 --> Language Class Initialized
ERROR - 2023-07-11 10:36:28 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:28 --> Language Class Initialized
INFO - 2023-07-11 10:36:28 --> Loader Class Initialized
INFO - 2023-07-11 10:36:28 --> Helper loaded: url_helper
INFO - 2023-07-11 10:36:28 --> Database Driver Class Initialized
INFO - 2023-07-11 10:36:28 --> Controller Class Initialized
INFO - 2023-07-11 10:36:28 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:36:28 --> Final output sent to browser
DEBUG - 2023-07-11 10:36:28 --> Total execution time: 0.0508
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:28 --> Language Class Initialized
ERROR - 2023-07-11 10:36:28 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:28 --> Language Class Initialized
INFO - 2023-07-11 10:36:28 --> Loader Class Initialized
INFO - 2023-07-11 10:36:28 --> Helper loaded: url_helper
INFO - 2023-07-11 10:36:28 --> Database Driver Class Initialized
INFO - 2023-07-11 10:36:28 --> Controller Class Initialized
INFO - 2023-07-11 10:36:28 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:36:28 --> Final output sent to browser
DEBUG - 2023-07-11 10:36:28 --> Total execution time: 0.0480
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:28 --> Language Class Initialized
ERROR - 2023-07-11 10:36:28 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:28 --> Language Class Initialized
INFO - 2023-07-11 10:36:28 --> Loader Class Initialized
INFO - 2023-07-11 10:36:28 --> Helper loaded: url_helper
INFO - 2023-07-11 10:36:28 --> Database Driver Class Initialized
INFO - 2023-07-11 10:36:28 --> Controller Class Initialized
INFO - 2023-07-11 10:36:28 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:36:28 --> Final output sent to browser
DEBUG - 2023-07-11 10:36:28 --> Total execution time: 0.0558
INFO - 2023-07-11 10:36:28 --> Config Class Initialized
INFO - 2023-07-11 10:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:28 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:28 --> URI Class Initialized
INFO - 2023-07-11 10:36:28 --> Router Class Initialized
INFO - 2023-07-11 10:36:28 --> Output Class Initialized
INFO - 2023-07-11 10:36:28 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:28 --> Input Class Initialized
INFO - 2023-07-11 10:36:29 --> Language Class Initialized
ERROR - 2023-07-11 10:36:29 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:36:41 --> Config Class Initialized
INFO - 2023-07-11 10:36:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:41 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:41 --> URI Class Initialized
INFO - 2023-07-11 10:36:41 --> Router Class Initialized
INFO - 2023-07-11 10:36:41 --> Output Class Initialized
INFO - 2023-07-11 10:36:41 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:41 --> Input Class Initialized
INFO - 2023-07-11 10:36:41 --> Language Class Initialized
INFO - 2023-07-11 10:36:41 --> Loader Class Initialized
INFO - 2023-07-11 10:36:41 --> Helper loaded: url_helper
INFO - 2023-07-11 10:36:41 --> Database Driver Class Initialized
INFO - 2023-07-11 10:36:41 --> Controller Class Initialized
INFO - 2023-07-11 10:36:41 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:36:41 --> Final output sent to browser
DEBUG - 2023-07-11 10:36:41 --> Total execution time: 0.0503
INFO - 2023-07-11 10:36:41 --> Config Class Initialized
INFO - 2023-07-11 10:36:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:36:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:36:41 --> Utf8 Class Initialized
INFO - 2023-07-11 10:36:41 --> URI Class Initialized
INFO - 2023-07-11 10:36:41 --> Router Class Initialized
INFO - 2023-07-11 10:36:41 --> Output Class Initialized
INFO - 2023-07-11 10:36:41 --> Security Class Initialized
DEBUG - 2023-07-11 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:36:41 --> Input Class Initialized
INFO - 2023-07-11 10:36:41 --> Language Class Initialized
ERROR - 2023-07-11 10:36:41 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:39:57 --> Config Class Initialized
INFO - 2023-07-11 10:39:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:39:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:39:57 --> Utf8 Class Initialized
INFO - 2023-07-11 10:39:57 --> URI Class Initialized
INFO - 2023-07-11 10:39:57 --> Router Class Initialized
INFO - 2023-07-11 10:39:57 --> Output Class Initialized
INFO - 2023-07-11 10:39:57 --> Security Class Initialized
DEBUG - 2023-07-11 10:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:39:57 --> Input Class Initialized
INFO - 2023-07-11 10:39:57 --> Language Class Initialized
INFO - 2023-07-11 10:39:57 --> Loader Class Initialized
INFO - 2023-07-11 10:39:57 --> Helper loaded: url_helper
INFO - 2023-07-11 10:39:57 --> Database Driver Class Initialized
INFO - 2023-07-11 10:39:57 --> Controller Class Initialized
INFO - 2023-07-11 10:39:57 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:39:57 --> Final output sent to browser
DEBUG - 2023-07-11 10:39:57 --> Total execution time: 0.4251
INFO - 2023-07-11 10:39:57 --> Config Class Initialized
INFO - 2023-07-11 10:39:57 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:39:57 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:39:57 --> Utf8 Class Initialized
INFO - 2023-07-11 10:39:58 --> URI Class Initialized
INFO - 2023-07-11 10:39:58 --> Router Class Initialized
INFO - 2023-07-11 10:39:58 --> Output Class Initialized
INFO - 2023-07-11 10:39:58 --> Security Class Initialized
DEBUG - 2023-07-11 10:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:39:58 --> Input Class Initialized
INFO - 2023-07-11 10:39:58 --> Language Class Initialized
ERROR - 2023-07-11 10:39:58 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:44:17 --> Config Class Initialized
INFO - 2023-07-11 10:44:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:44:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:44:17 --> Utf8 Class Initialized
INFO - 2023-07-11 10:44:17 --> URI Class Initialized
INFO - 2023-07-11 10:44:17 --> Router Class Initialized
INFO - 2023-07-11 10:44:17 --> Output Class Initialized
INFO - 2023-07-11 10:44:17 --> Security Class Initialized
DEBUG - 2023-07-11 10:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:44:17 --> Input Class Initialized
INFO - 2023-07-11 10:44:17 --> Language Class Initialized
INFO - 2023-07-11 10:44:17 --> Loader Class Initialized
INFO - 2023-07-11 10:44:17 --> Helper loaded: url_helper
INFO - 2023-07-11 10:44:17 --> Database Driver Class Initialized
INFO - 2023-07-11 10:44:17 --> Controller Class Initialized
INFO - 2023-07-11 10:44:17 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 10:44:18 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 10:44:18 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 10:44:18 --> Final output sent to browser
DEBUG - 2023-07-11 10:44:18 --> Total execution time: 0.3734
INFO - 2023-07-11 10:44:18 --> Config Class Initialized
INFO - 2023-07-11 10:44:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:44:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:44:18 --> Utf8 Class Initialized
INFO - 2023-07-11 10:44:18 --> URI Class Initialized
INFO - 2023-07-11 10:44:18 --> Router Class Initialized
INFO - 2023-07-11 10:44:18 --> Output Class Initialized
INFO - 2023-07-11 10:44:18 --> Security Class Initialized
DEBUG - 2023-07-11 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:44:18 --> Input Class Initialized
INFO - 2023-07-11 10:44:18 --> Language Class Initialized
ERROR - 2023-07-11 10:44:18 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 10:44:18 --> Config Class Initialized
INFO - 2023-07-11 10:44:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:44:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:44:18 --> Utf8 Class Initialized
INFO - 2023-07-11 10:44:18 --> URI Class Initialized
INFO - 2023-07-11 10:44:18 --> Router Class Initialized
INFO - 2023-07-11 10:44:18 --> Output Class Initialized
INFO - 2023-07-11 10:44:18 --> Security Class Initialized
DEBUG - 2023-07-11 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:44:18 --> Input Class Initialized
INFO - 2023-07-11 10:44:18 --> Language Class Initialized
ERROR - 2023-07-11 10:44:18 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 10:44:18 --> Config Class Initialized
INFO - 2023-07-11 10:44:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:44:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:44:18 --> Utf8 Class Initialized
INFO - 2023-07-11 10:44:18 --> URI Class Initialized
INFO - 2023-07-11 10:44:18 --> Router Class Initialized
INFO - 2023-07-11 10:44:18 --> Output Class Initialized
INFO - 2023-07-11 10:44:18 --> Security Class Initialized
DEBUG - 2023-07-11 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:44:18 --> Input Class Initialized
INFO - 2023-07-11 10:44:18 --> Language Class Initialized
ERROR - 2023-07-11 10:44:18 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 10:46:31 --> Config Class Initialized
INFO - 2023-07-11 10:46:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:46:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:46:31 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:31 --> URI Class Initialized
INFO - 2023-07-11 10:46:31 --> Router Class Initialized
INFO - 2023-07-11 10:46:31 --> Output Class Initialized
INFO - 2023-07-11 10:46:31 --> Security Class Initialized
DEBUG - 2023-07-11 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:46:31 --> Input Class Initialized
INFO - 2023-07-11 10:46:32 --> Language Class Initialized
INFO - 2023-07-11 10:46:32 --> Loader Class Initialized
INFO - 2023-07-11 10:46:32 --> Helper loaded: url_helper
INFO - 2023-07-11 10:46:32 --> Database Driver Class Initialized
INFO - 2023-07-11 10:46:32 --> Controller Class Initialized
INFO - 2023-07-11 10:46:32 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 10:46:32 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 10:46:32 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 10:46:32 --> Final output sent to browser
DEBUG - 2023-07-11 10:46:32 --> Total execution time: 0.0767
INFO - 2023-07-11 10:46:32 --> Config Class Initialized
INFO - 2023-07-11 10:46:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:46:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:46:32 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:32 --> URI Class Initialized
INFO - 2023-07-11 10:46:32 --> Config Class Initialized
INFO - 2023-07-11 10:46:32 --> Hooks Class Initialized
INFO - 2023-07-11 10:46:32 --> Router Class Initialized
DEBUG - 2023-07-11 10:46:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:46:32 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:32 --> Output Class Initialized
INFO - 2023-07-11 10:46:32 --> URI Class Initialized
INFO - 2023-07-11 10:46:32 --> Router Class Initialized
INFO - 2023-07-11 10:46:32 --> Security Class Initialized
INFO - 2023-07-11 10:46:32 --> Output Class Initialized
DEBUG - 2023-07-11 10:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:46:32 --> Input Class Initialized
INFO - 2023-07-11 10:46:32 --> Security Class Initialized
INFO - 2023-07-11 10:46:32 --> Language Class Initialized
DEBUG - 2023-07-11 10:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:46:32 --> Input Class Initialized
ERROR - 2023-07-11 10:46:32 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 10:46:32 --> Language Class Initialized
ERROR - 2023-07-11 10:46:32 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 10:46:32 --> Config Class Initialized
INFO - 2023-07-11 10:46:32 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:46:32 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:46:32 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:32 --> URI Class Initialized
INFO - 2023-07-11 10:46:32 --> Router Class Initialized
INFO - 2023-07-11 10:46:32 --> Output Class Initialized
INFO - 2023-07-11 10:46:32 --> Security Class Initialized
DEBUG - 2023-07-11 10:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:46:32 --> Input Class Initialized
INFO - 2023-07-11 10:46:32 --> Language Class Initialized
ERROR - 2023-07-11 10:46:32 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 10:46:47 --> Config Class Initialized
INFO - 2023-07-11 10:46:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:46:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:46:47 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:47 --> URI Class Initialized
INFO - 2023-07-11 10:46:47 --> Router Class Initialized
INFO - 2023-07-11 10:46:47 --> Output Class Initialized
INFO - 2023-07-11 10:46:47 --> Security Class Initialized
DEBUG - 2023-07-11 10:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:46:47 --> Input Class Initialized
INFO - 2023-07-11 10:46:47 --> Language Class Initialized
INFO - 2023-07-11 10:46:47 --> Loader Class Initialized
INFO - 2023-07-11 10:46:47 --> Helper loaded: url_helper
INFO - 2023-07-11 10:46:47 --> Database Driver Class Initialized
INFO - 2023-07-11 10:46:47 --> Controller Class Initialized
INFO - 2023-07-11 10:46:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 10:46:47 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 10:46:47 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 10:46:47 --> Final output sent to browser
DEBUG - 2023-07-11 10:46:47 --> Total execution time: 0.0808
INFO - 2023-07-11 10:46:47 --> Config Class Initialized
INFO - 2023-07-11 10:46:47 --> Hooks Class Initialized
INFO - 2023-07-11 10:46:47 --> Config Class Initialized
INFO - 2023-07-11 10:46:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:46:47 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 10:46:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:46:47 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:47 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:47 --> URI Class Initialized
INFO - 2023-07-11 10:46:47 --> URI Class Initialized
INFO - 2023-07-11 10:46:47 --> Router Class Initialized
INFO - 2023-07-11 10:46:47 --> Router Class Initialized
INFO - 2023-07-11 10:46:47 --> Output Class Initialized
INFO - 2023-07-11 10:46:47 --> Output Class Initialized
INFO - 2023-07-11 10:46:47 --> Security Class Initialized
INFO - 2023-07-11 10:46:47 --> Security Class Initialized
DEBUG - 2023-07-11 10:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 10:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:46:47 --> Input Class Initialized
INFO - 2023-07-11 10:46:47 --> Input Class Initialized
INFO - 2023-07-11 10:46:47 --> Language Class Initialized
INFO - 2023-07-11 10:46:47 --> Language Class Initialized
ERROR - 2023-07-11 10:46:47 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 10:46:47 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 10:46:47 --> Config Class Initialized
INFO - 2023-07-11 10:46:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:46:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:46:47 --> Utf8 Class Initialized
INFO - 2023-07-11 10:46:47 --> URI Class Initialized
INFO - 2023-07-11 10:46:47 --> Router Class Initialized
INFO - 2023-07-11 10:46:47 --> Output Class Initialized
INFO - 2023-07-11 10:46:47 --> Security Class Initialized
DEBUG - 2023-07-11 10:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:46:47 --> Input Class Initialized
INFO - 2023-07-11 10:46:47 --> Language Class Initialized
ERROR - 2023-07-11 10:46:47 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 10:47:49 --> Config Class Initialized
INFO - 2023-07-11 10:47:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:47:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:47:49 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:49 --> URI Class Initialized
INFO - 2023-07-11 10:47:49 --> Router Class Initialized
INFO - 2023-07-11 10:47:49 --> Output Class Initialized
INFO - 2023-07-11 10:47:49 --> Security Class Initialized
DEBUG - 2023-07-11 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:47:49 --> Input Class Initialized
INFO - 2023-07-11 10:47:49 --> Language Class Initialized
INFO - 2023-07-11 10:47:49 --> Loader Class Initialized
INFO - 2023-07-11 10:47:49 --> Helper loaded: url_helper
INFO - 2023-07-11 10:47:49 --> Database Driver Class Initialized
INFO - 2023-07-11 10:47:49 --> Controller Class Initialized
INFO - 2023-07-11 10:47:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 10:47:49 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 10:47:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 10:47:49 --> Final output sent to browser
DEBUG - 2023-07-11 10:47:49 --> Total execution time: 0.0743
INFO - 2023-07-11 10:47:49 --> Config Class Initialized
INFO - 2023-07-11 10:47:49 --> Hooks Class Initialized
INFO - 2023-07-11 10:47:49 --> Config Class Initialized
INFO - 2023-07-11 10:47:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 10:47:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:47:49 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:49 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:49 --> URI Class Initialized
INFO - 2023-07-11 10:47:49 --> URI Class Initialized
INFO - 2023-07-11 10:47:49 --> Router Class Initialized
INFO - 2023-07-11 10:47:49 --> Router Class Initialized
INFO - 2023-07-11 10:47:49 --> Output Class Initialized
INFO - 2023-07-11 10:47:49 --> Output Class Initialized
INFO - 2023-07-11 10:47:49 --> Security Class Initialized
INFO - 2023-07-11 10:47:49 --> Security Class Initialized
DEBUG - 2023-07-11 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:47:49 --> Input Class Initialized
INFO - 2023-07-11 10:47:49 --> Input Class Initialized
INFO - 2023-07-11 10:47:49 --> Language Class Initialized
INFO - 2023-07-11 10:47:49 --> Language Class Initialized
ERROR - 2023-07-11 10:47:49 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 10:47:49 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 10:47:49 --> Config Class Initialized
INFO - 2023-07-11 10:47:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:47:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:47:49 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:49 --> URI Class Initialized
INFO - 2023-07-11 10:47:49 --> Router Class Initialized
INFO - 2023-07-11 10:47:49 --> Output Class Initialized
INFO - 2023-07-11 10:47:49 --> Security Class Initialized
DEBUG - 2023-07-11 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:47:49 --> Input Class Initialized
INFO - 2023-07-11 10:47:49 --> Language Class Initialized
ERROR - 2023-07-11 10:47:49 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 10:47:51 --> Config Class Initialized
INFO - 2023-07-11 10:47:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:47:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:47:51 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:51 --> URI Class Initialized
INFO - 2023-07-11 10:47:51 --> Router Class Initialized
INFO - 2023-07-11 10:47:51 --> Output Class Initialized
INFO - 2023-07-11 10:47:51 --> Security Class Initialized
DEBUG - 2023-07-11 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:47:51 --> Input Class Initialized
INFO - 2023-07-11 10:47:51 --> Language Class Initialized
INFO - 2023-07-11 10:47:51 --> Loader Class Initialized
INFO - 2023-07-11 10:47:51 --> Helper loaded: url_helper
INFO - 2023-07-11 10:47:51 --> Database Driver Class Initialized
INFO - 2023-07-11 10:47:51 --> Controller Class Initialized
INFO - 2023-07-11 10:47:51 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:47:51 --> Final output sent to browser
DEBUG - 2023-07-11 10:47:51 --> Total execution time: 0.0662
INFO - 2023-07-11 10:47:51 --> Config Class Initialized
INFO - 2023-07-11 10:47:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:47:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:47:51 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:51 --> URI Class Initialized
INFO - 2023-07-11 10:47:51 --> Router Class Initialized
INFO - 2023-07-11 10:47:51 --> Output Class Initialized
INFO - 2023-07-11 10:47:51 --> Security Class Initialized
DEBUG - 2023-07-11 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:47:51 --> Input Class Initialized
INFO - 2023-07-11 10:47:51 --> Language Class Initialized
ERROR - 2023-07-11 10:47:51 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:47:58 --> Config Class Initialized
INFO - 2023-07-11 10:47:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:47:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:47:59 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:59 --> URI Class Initialized
INFO - 2023-07-11 10:47:59 --> Router Class Initialized
INFO - 2023-07-11 10:47:59 --> Output Class Initialized
INFO - 2023-07-11 10:47:59 --> Security Class Initialized
DEBUG - 2023-07-11 10:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:47:59 --> Input Class Initialized
INFO - 2023-07-11 10:47:59 --> Language Class Initialized
INFO - 2023-07-11 10:47:59 --> Loader Class Initialized
INFO - 2023-07-11 10:47:59 --> Helper loaded: url_helper
INFO - 2023-07-11 10:47:59 --> Database Driver Class Initialized
INFO - 2023-07-11 10:47:59 --> Controller Class Initialized
INFO - 2023-07-11 10:47:59 --> File loaded: C:\xampp\htdocs\code\application\views\/login.php
INFO - 2023-07-11 10:47:59 --> Final output sent to browser
DEBUG - 2023-07-11 10:47:59 --> Total execution time: 0.0659
INFO - 2023-07-11 10:47:59 --> Config Class Initialized
INFO - 2023-07-11 10:47:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:47:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:47:59 --> Utf8 Class Initialized
INFO - 2023-07-11 10:47:59 --> URI Class Initialized
INFO - 2023-07-11 10:47:59 --> Router Class Initialized
INFO - 2023-07-11 10:47:59 --> Output Class Initialized
INFO - 2023-07-11 10:47:59 --> Security Class Initialized
DEBUG - 2023-07-11 10:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:47:59 --> Input Class Initialized
INFO - 2023-07-11 10:47:59 --> Language Class Initialized
ERROR - 2023-07-11 10:47:59 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:48:04 --> Config Class Initialized
INFO - 2023-07-11 10:48:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:48:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:48:04 --> Utf8 Class Initialized
INFO - 2023-07-11 10:48:04 --> URI Class Initialized
INFO - 2023-07-11 10:48:04 --> Router Class Initialized
INFO - 2023-07-11 10:48:04 --> Output Class Initialized
INFO - 2023-07-11 10:48:04 --> Security Class Initialized
DEBUG - 2023-07-11 10:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:48:04 --> Input Class Initialized
INFO - 2023-07-11 10:48:04 --> Language Class Initialized
INFO - 2023-07-11 10:48:04 --> Loader Class Initialized
INFO - 2023-07-11 10:48:04 --> Helper loaded: url_helper
INFO - 2023-07-11 10:48:04 --> Database Driver Class Initialized
INFO - 2023-07-11 10:48:04 --> Controller Class Initialized
INFO - 2023-07-11 10:48:04 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:48:04 --> Final output sent to browser
DEBUG - 2023-07-11 10:48:04 --> Total execution time: 0.0546
INFO - 2023-07-11 10:48:04 --> Config Class Initialized
INFO - 2023-07-11 10:48:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:48:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:48:04 --> Utf8 Class Initialized
INFO - 2023-07-11 10:48:04 --> URI Class Initialized
INFO - 2023-07-11 10:48:04 --> Router Class Initialized
INFO - 2023-07-11 10:48:04 --> Output Class Initialized
INFO - 2023-07-11 10:48:04 --> Security Class Initialized
DEBUG - 2023-07-11 10:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:48:04 --> Input Class Initialized
INFO - 2023-07-11 10:48:04 --> Language Class Initialized
ERROR - 2023-07-11 10:48:04 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:48:16 --> Config Class Initialized
INFO - 2023-07-11 10:48:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:48:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:48:16 --> Utf8 Class Initialized
INFO - 2023-07-11 10:48:16 --> URI Class Initialized
INFO - 2023-07-11 10:48:16 --> Router Class Initialized
INFO - 2023-07-11 10:48:16 --> Output Class Initialized
INFO - 2023-07-11 10:48:16 --> Security Class Initialized
DEBUG - 2023-07-11 10:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:48:16 --> Input Class Initialized
INFO - 2023-07-11 10:48:16 --> Language Class Initialized
INFO - 2023-07-11 10:48:16 --> Loader Class Initialized
INFO - 2023-07-11 10:48:16 --> Helper loaded: url_helper
INFO - 2023-07-11 10:48:16 --> Database Driver Class Initialized
INFO - 2023-07-11 10:48:16 --> Controller Class Initialized
INFO - 2023-07-11 10:48:16 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:48:16 --> Final output sent to browser
DEBUG - 2023-07-11 10:48:16 --> Total execution time: 0.0569
INFO - 2023-07-11 10:48:16 --> Config Class Initialized
INFO - 2023-07-11 10:48:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:48:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:48:16 --> Utf8 Class Initialized
INFO - 2023-07-11 10:48:16 --> URI Class Initialized
INFO - 2023-07-11 10:48:16 --> Router Class Initialized
INFO - 2023-07-11 10:48:16 --> Output Class Initialized
INFO - 2023-07-11 10:48:16 --> Security Class Initialized
DEBUG - 2023-07-11 10:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:48:16 --> Input Class Initialized
INFO - 2023-07-11 10:48:16 --> Language Class Initialized
ERROR - 2023-07-11 10:48:16 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:49:38 --> Config Class Initialized
INFO - 2023-07-11 10:49:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:49:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:49:38 --> Utf8 Class Initialized
INFO - 2023-07-11 10:49:38 --> URI Class Initialized
INFO - 2023-07-11 10:49:38 --> Router Class Initialized
INFO - 2023-07-11 10:49:38 --> Output Class Initialized
INFO - 2023-07-11 10:49:39 --> Security Class Initialized
DEBUG - 2023-07-11 10:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:49:39 --> Input Class Initialized
INFO - 2023-07-11 10:49:39 --> Language Class Initialized
INFO - 2023-07-11 10:49:39 --> Loader Class Initialized
INFO - 2023-07-11 10:49:39 --> Helper loaded: url_helper
INFO - 2023-07-11 10:49:39 --> Database Driver Class Initialized
INFO - 2023-07-11 10:49:39 --> Controller Class Initialized
INFO - 2023-07-11 10:49:39 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:49:39 --> Final output sent to browser
DEBUG - 2023-07-11 10:49:39 --> Total execution time: 0.0713
INFO - 2023-07-11 10:49:39 --> Config Class Initialized
INFO - 2023-07-11 10:49:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:49:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:49:39 --> Utf8 Class Initialized
INFO - 2023-07-11 10:49:39 --> URI Class Initialized
INFO - 2023-07-11 10:49:39 --> Router Class Initialized
INFO - 2023-07-11 10:49:39 --> Output Class Initialized
INFO - 2023-07-11 10:49:39 --> Security Class Initialized
DEBUG - 2023-07-11 10:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:49:39 --> Input Class Initialized
INFO - 2023-07-11 10:49:39 --> Language Class Initialized
ERROR - 2023-07-11 10:49:39 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 10:49:49 --> Config Class Initialized
INFO - 2023-07-11 10:49:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:49:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:49:49 --> Utf8 Class Initialized
INFO - 2023-07-11 10:49:49 --> URI Class Initialized
INFO - 2023-07-11 10:49:49 --> Router Class Initialized
INFO - 2023-07-11 10:49:49 --> Output Class Initialized
INFO - 2023-07-11 10:49:49 --> Security Class Initialized
DEBUG - 2023-07-11 10:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:49:49 --> Input Class Initialized
INFO - 2023-07-11 10:49:49 --> Language Class Initialized
ERROR - 2023-07-11 10:49:49 --> 404 Page Not Found: Registerctr/index
INFO - 2023-07-11 10:49:58 --> Config Class Initialized
INFO - 2023-07-11 10:49:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:49:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:49:58 --> Utf8 Class Initialized
INFO - 2023-07-11 10:49:58 --> URI Class Initialized
INFO - 2023-07-11 10:49:58 --> Router Class Initialized
INFO - 2023-07-11 10:49:58 --> Output Class Initialized
INFO - 2023-07-11 10:49:58 --> Security Class Initialized
DEBUG - 2023-07-11 10:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:49:58 --> Input Class Initialized
INFO - 2023-07-11 10:49:58 --> Language Class Initialized
INFO - 2023-07-11 10:49:58 --> Loader Class Initialized
INFO - 2023-07-11 10:49:58 --> Helper loaded: url_helper
INFO - 2023-07-11 10:49:58 --> Database Driver Class Initialized
INFO - 2023-07-11 10:49:58 --> Controller Class Initialized
INFO - 2023-07-11 10:49:58 --> File loaded: C:\xampp\htdocs\code\application\views\/register.php
INFO - 2023-07-11 10:49:58 --> Final output sent to browser
DEBUG - 2023-07-11 10:49:58 --> Total execution time: 0.0535
INFO - 2023-07-11 10:49:58 --> Config Class Initialized
INFO - 2023-07-11 10:49:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:49:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:49:58 --> Utf8 Class Initialized
INFO - 2023-07-11 10:49:58 --> URI Class Initialized
INFO - 2023-07-11 10:49:58 --> Router Class Initialized
INFO - 2023-07-11 10:49:58 --> Output Class Initialized
INFO - 2023-07-11 10:49:58 --> Security Class Initialized
DEBUG - 2023-07-11 10:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:49:58 --> Input Class Initialized
INFO - 2023-07-11 10:49:58 --> Language Class Initialized
ERROR - 2023-07-11 10:49:58 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 10:50:08 --> Config Class Initialized
INFO - 2023-07-11 10:50:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:50:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:50:08 --> Utf8 Class Initialized
INFO - 2023-07-11 10:50:08 --> URI Class Initialized
INFO - 2023-07-11 10:50:08 --> Router Class Initialized
INFO - 2023-07-11 10:50:08 --> Output Class Initialized
INFO - 2023-07-11 10:50:08 --> Security Class Initialized
DEBUG - 2023-07-11 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:50:08 --> Input Class Initialized
INFO - 2023-07-11 10:50:08 --> Language Class Initialized
INFO - 2023-07-11 10:50:08 --> Loader Class Initialized
INFO - 2023-07-11 10:50:08 --> Helper loaded: url_helper
INFO - 2023-07-11 10:50:08 --> Database Driver Class Initialized
INFO - 2023-07-11 10:50:08 --> Controller Class Initialized
INFO - 2023-07-11 10:50:09 --> Config Class Initialized
INFO - 2023-07-11 10:50:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:50:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:50:09 --> Utf8 Class Initialized
INFO - 2023-07-11 10:50:09 --> URI Class Initialized
INFO - 2023-07-11 10:50:09 --> Router Class Initialized
INFO - 2023-07-11 10:50:09 --> Output Class Initialized
INFO - 2023-07-11 10:50:09 --> Security Class Initialized
DEBUG - 2023-07-11 10:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:50:09 --> Input Class Initialized
INFO - 2023-07-11 10:50:09 --> Language Class Initialized
INFO - 2023-07-11 10:50:09 --> Loader Class Initialized
INFO - 2023-07-11 10:50:09 --> Helper loaded: url_helper
INFO - 2023-07-11 10:50:09 --> Database Driver Class Initialized
INFO - 2023-07-11 10:50:09 --> Controller Class Initialized
INFO - 2023-07-11 10:50:09 --> File loaded: C:\xampp\htdocs\code\application\views\/login.php
INFO - 2023-07-11 10:50:09 --> Final output sent to browser
DEBUG - 2023-07-11 10:50:09 --> Total execution time: 0.0581
INFO - 2023-07-11 10:50:09 --> Config Class Initialized
INFO - 2023-07-11 10:50:09 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:50:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:50:09 --> Utf8 Class Initialized
INFO - 2023-07-11 10:50:09 --> URI Class Initialized
INFO - 2023-07-11 10:50:09 --> Router Class Initialized
INFO - 2023-07-11 10:50:09 --> Output Class Initialized
INFO - 2023-07-11 10:50:09 --> Security Class Initialized
DEBUG - 2023-07-11 10:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:50:09 --> Input Class Initialized
INFO - 2023-07-11 10:50:09 --> Language Class Initialized
ERROR - 2023-07-11 10:50:09 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:02:14 --> Config Class Initialized
INFO - 2023-07-11 11:02:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:02:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:02:14 --> Utf8 Class Initialized
INFO - 2023-07-11 11:02:14 --> URI Class Initialized
INFO - 2023-07-11 11:02:14 --> Router Class Initialized
INFO - 2023-07-11 11:02:15 --> Output Class Initialized
INFO - 2023-07-11 11:02:15 --> Security Class Initialized
DEBUG - 2023-07-11 11:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:02:15 --> Input Class Initialized
INFO - 2023-07-11 11:02:15 --> Language Class Initialized
ERROR - 2023-07-11 11:02:15 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:02:59 --> Config Class Initialized
INFO - 2023-07-11 11:02:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:02:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:02:59 --> Utf8 Class Initialized
INFO - 2023-07-11 11:02:59 --> URI Class Initialized
INFO - 2023-07-11 11:02:59 --> Router Class Initialized
INFO - 2023-07-11 11:02:59 --> Output Class Initialized
INFO - 2023-07-11 11:02:59 --> Security Class Initialized
DEBUG - 2023-07-11 11:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:02:59 --> Input Class Initialized
INFO - 2023-07-11 11:02:59 --> Language Class Initialized
INFO - 2023-07-11 11:03:01 --> Loader Class Initialized
INFO - 2023-07-11 11:03:01 --> Helper loaded: url_helper
INFO - 2023-07-11 11:03:01 --> Database Driver Class Initialized
INFO - 2023-07-11 11:03:01 --> Controller Class Initialized
ERROR - 2023-07-11 11:03:01 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\code\application\controllers\registerctr.php 32
INFO - 2023-07-11 11:03:02 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:03:02 --> Final output sent to browser
DEBUG - 2023-07-11 11:03:02 --> Total execution time: 3.1175
INFO - 2023-07-11 11:03:02 --> Config Class Initialized
INFO - 2023-07-11 11:03:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:03:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:03:02 --> Utf8 Class Initialized
INFO - 2023-07-11 11:03:02 --> URI Class Initialized
INFO - 2023-07-11 11:03:02 --> Router Class Initialized
INFO - 2023-07-11 11:03:02 --> Output Class Initialized
INFO - 2023-07-11 11:03:02 --> Security Class Initialized
DEBUG - 2023-07-11 11:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:03:02 --> Input Class Initialized
INFO - 2023-07-11 11:03:02 --> Language Class Initialized
ERROR - 2023-07-11 11:03:02 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:05:38 --> Config Class Initialized
INFO - 2023-07-11 11:05:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:05:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:05:38 --> Utf8 Class Initialized
INFO - 2023-07-11 11:05:38 --> URI Class Initialized
INFO - 2023-07-11 11:05:38 --> Router Class Initialized
INFO - 2023-07-11 11:05:38 --> Output Class Initialized
INFO - 2023-07-11 11:05:38 --> Security Class Initialized
DEBUG - 2023-07-11 11:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:05:38 --> Input Class Initialized
INFO - 2023-07-11 11:05:38 --> Language Class Initialized
INFO - 2023-07-11 11:05:38 --> Loader Class Initialized
INFO - 2023-07-11 11:05:38 --> Helper loaded: url_helper
INFO - 2023-07-11 11:05:38 --> Database Driver Class Initialized
INFO - 2023-07-11 11:05:38 --> Controller Class Initialized
INFO - 2023-07-11 11:05:38 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:05:38 --> Final output sent to browser
DEBUG - 2023-07-11 11:05:38 --> Total execution time: 0.1258
INFO - 2023-07-11 11:05:38 --> Config Class Initialized
INFO - 2023-07-11 11:05:38 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:05:38 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:05:38 --> Utf8 Class Initialized
INFO - 2023-07-11 11:05:38 --> URI Class Initialized
INFO - 2023-07-11 11:05:38 --> Router Class Initialized
INFO - 2023-07-11 11:05:38 --> Output Class Initialized
INFO - 2023-07-11 11:05:38 --> Security Class Initialized
DEBUG - 2023-07-11 11:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:05:38 --> Input Class Initialized
INFO - 2023-07-11 11:05:38 --> Language Class Initialized
ERROR - 2023-07-11 11:05:38 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:05:48 --> Config Class Initialized
INFO - 2023-07-11 11:05:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:05:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:05:48 --> Utf8 Class Initialized
INFO - 2023-07-11 11:05:48 --> URI Class Initialized
INFO - 2023-07-11 11:05:48 --> Router Class Initialized
INFO - 2023-07-11 11:05:48 --> Output Class Initialized
INFO - 2023-07-11 11:05:48 --> Security Class Initialized
DEBUG - 2023-07-11 11:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:05:48 --> Input Class Initialized
INFO - 2023-07-11 11:05:48 --> Language Class Initialized
INFO - 2023-07-11 11:05:48 --> Loader Class Initialized
INFO - 2023-07-11 11:05:48 --> Helper loaded: url_helper
INFO - 2023-07-11 11:05:48 --> Database Driver Class Initialized
INFO - 2023-07-11 11:05:48 --> Controller Class Initialized
INFO - 2023-07-11 11:05:48 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:05:48 --> Final output sent to browser
DEBUG - 2023-07-11 11:05:48 --> Total execution time: 0.0559
INFO - 2023-07-11 11:05:48 --> Config Class Initialized
INFO - 2023-07-11 11:05:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:05:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:05:48 --> Utf8 Class Initialized
INFO - 2023-07-11 11:05:48 --> URI Class Initialized
INFO - 2023-07-11 11:05:48 --> Router Class Initialized
INFO - 2023-07-11 11:05:48 --> Output Class Initialized
INFO - 2023-07-11 11:05:48 --> Security Class Initialized
DEBUG - 2023-07-11 11:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:05:48 --> Input Class Initialized
INFO - 2023-07-11 11:05:48 --> Language Class Initialized
ERROR - 2023-07-11 11:05:48 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:08:00 --> Config Class Initialized
INFO - 2023-07-11 11:08:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:08:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:08:00 --> Utf8 Class Initialized
INFO - 2023-07-11 11:08:00 --> URI Class Initialized
INFO - 2023-07-11 11:08:00 --> Router Class Initialized
INFO - 2023-07-11 11:08:00 --> Output Class Initialized
INFO - 2023-07-11 11:08:00 --> Security Class Initialized
DEBUG - 2023-07-11 11:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:08:00 --> Input Class Initialized
INFO - 2023-07-11 11:08:00 --> Language Class Initialized
INFO - 2023-07-11 11:08:00 --> Loader Class Initialized
INFO - 2023-07-11 11:08:00 --> Helper loaded: url_helper
INFO - 2023-07-11 11:08:00 --> Database Driver Class Initialized
INFO - 2023-07-11 11:08:00 --> Controller Class Initialized
INFO - 2023-07-11 11:08:00 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:08:00 --> Final output sent to browser
DEBUG - 2023-07-11 11:08:00 --> Total execution time: 0.0948
INFO - 2023-07-11 11:08:00 --> Config Class Initialized
INFO - 2023-07-11 11:08:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:08:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:08:00 --> Utf8 Class Initialized
INFO - 2023-07-11 11:08:00 --> URI Class Initialized
INFO - 2023-07-11 11:08:00 --> Router Class Initialized
INFO - 2023-07-11 11:08:00 --> Output Class Initialized
INFO - 2023-07-11 11:08:00 --> Security Class Initialized
DEBUG - 2023-07-11 11:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:08:00 --> Input Class Initialized
INFO - 2023-07-11 11:08:00 --> Language Class Initialized
ERROR - 2023-07-11 11:08:00 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:08:12 --> Config Class Initialized
INFO - 2023-07-11 11:08:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:08:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:08:12 --> Utf8 Class Initialized
INFO - 2023-07-11 11:08:12 --> URI Class Initialized
INFO - 2023-07-11 11:08:12 --> Router Class Initialized
INFO - 2023-07-11 11:08:12 --> Output Class Initialized
INFO - 2023-07-11 11:08:12 --> Security Class Initialized
DEBUG - 2023-07-11 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:08:12 --> Input Class Initialized
INFO - 2023-07-11 11:08:12 --> Language Class Initialized
INFO - 2023-07-11 11:08:12 --> Loader Class Initialized
INFO - 2023-07-11 11:08:12 --> Helper loaded: url_helper
INFO - 2023-07-11 11:08:12 --> Database Driver Class Initialized
INFO - 2023-07-11 11:08:12 --> Controller Class Initialized
INFO - 2023-07-11 11:08:12 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:08:12 --> Final output sent to browser
DEBUG - 2023-07-11 11:08:12 --> Total execution time: 0.0498
INFO - 2023-07-11 11:08:12 --> Config Class Initialized
INFO - 2023-07-11 11:08:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:08:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:08:12 --> Utf8 Class Initialized
INFO - 2023-07-11 11:08:12 --> URI Class Initialized
INFO - 2023-07-11 11:08:12 --> Router Class Initialized
INFO - 2023-07-11 11:08:12 --> Output Class Initialized
INFO - 2023-07-11 11:08:12 --> Security Class Initialized
DEBUG - 2023-07-11 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:08:12 --> Input Class Initialized
INFO - 2023-07-11 11:08:12 --> Language Class Initialized
ERROR - 2023-07-11 11:08:12 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:10:01 --> Config Class Initialized
INFO - 2023-07-11 11:10:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:10:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:10:01 --> Utf8 Class Initialized
INFO - 2023-07-11 11:10:01 --> URI Class Initialized
INFO - 2023-07-11 11:10:01 --> Router Class Initialized
INFO - 2023-07-11 11:10:01 --> Output Class Initialized
INFO - 2023-07-11 11:10:01 --> Security Class Initialized
DEBUG - 2023-07-11 11:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:10:01 --> Input Class Initialized
INFO - 2023-07-11 11:10:01 --> Language Class Initialized
INFO - 2023-07-11 11:10:01 --> Loader Class Initialized
INFO - 2023-07-11 11:10:01 --> Helper loaded: url_helper
INFO - 2023-07-11 11:10:01 --> Database Driver Class Initialized
INFO - 2023-07-11 11:10:01 --> Controller Class Initialized
INFO - 2023-07-11 11:10:01 --> Final output sent to browser
DEBUG - 2023-07-11 11:10:01 --> Total execution time: 0.1218
INFO - 2023-07-11 11:10:06 --> Config Class Initialized
INFO - 2023-07-11 11:10:06 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:10:06 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:10:06 --> Utf8 Class Initialized
INFO - 2023-07-11 11:10:06 --> URI Class Initialized
INFO - 2023-07-11 11:10:06 --> Router Class Initialized
INFO - 2023-07-11 11:10:06 --> Output Class Initialized
INFO - 2023-07-11 11:10:06 --> Security Class Initialized
DEBUG - 2023-07-11 11:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:10:06 --> Input Class Initialized
INFO - 2023-07-11 11:10:06 --> Language Class Initialized
INFO - 2023-07-11 11:10:06 --> Loader Class Initialized
INFO - 2023-07-11 11:10:06 --> Helper loaded: url_helper
INFO - 2023-07-11 11:10:06 --> Database Driver Class Initialized
INFO - 2023-07-11 11:10:06 --> Controller Class Initialized
INFO - 2023-07-11 11:10:06 --> Final output sent to browser
DEBUG - 2023-07-11 11:10:06 --> Total execution time: 0.0498
INFO - 2023-07-11 11:10:17 --> Config Class Initialized
INFO - 2023-07-11 11:10:17 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:10:17 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:10:17 --> Utf8 Class Initialized
INFO - 2023-07-11 11:10:17 --> URI Class Initialized
INFO - 2023-07-11 11:10:17 --> Router Class Initialized
INFO - 2023-07-11 11:10:17 --> Output Class Initialized
INFO - 2023-07-11 11:10:17 --> Security Class Initialized
DEBUG - 2023-07-11 11:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:10:17 --> Input Class Initialized
INFO - 2023-07-11 11:10:17 --> Language Class Initialized
INFO - 2023-07-11 11:10:17 --> Loader Class Initialized
INFO - 2023-07-11 11:10:17 --> Helper loaded: url_helper
INFO - 2023-07-11 11:10:17 --> Database Driver Class Initialized
INFO - 2023-07-11 11:10:17 --> Controller Class Initialized
INFO - 2023-07-11 11:10:17 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:10:17 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:10:17 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:10:17 --> Final output sent to browser
DEBUG - 2023-07-11 11:10:17 --> Total execution time: 0.1974
INFO - 2023-07-11 11:10:19 --> Config Class Initialized
INFO - 2023-07-11 11:10:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:10:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:10:19 --> Utf8 Class Initialized
INFO - 2023-07-11 11:10:19 --> URI Class Initialized
INFO - 2023-07-11 11:10:19 --> Router Class Initialized
INFO - 2023-07-11 11:10:19 --> Config Class Initialized
INFO - 2023-07-11 11:10:19 --> Hooks Class Initialized
INFO - 2023-07-11 11:10:19 --> Output Class Initialized
INFO - 2023-07-11 11:10:19 --> Security Class Initialized
DEBUG - 2023-07-11 11:10:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:10:19 --> Utf8 Class Initialized
DEBUG - 2023-07-11 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:10:19 --> Input Class Initialized
INFO - 2023-07-11 11:10:19 --> URI Class Initialized
INFO - 2023-07-11 11:10:19 --> Language Class Initialized
INFO - 2023-07-11 11:10:19 --> Router Class Initialized
ERROR - 2023-07-11 11:10:19 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 11:10:19 --> Output Class Initialized
INFO - 2023-07-11 11:10:19 --> Security Class Initialized
DEBUG - 2023-07-11 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:10:19 --> Input Class Initialized
INFO - 2023-07-11 11:10:19 --> Language Class Initialized
ERROR - 2023-07-11 11:10:19 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 11:10:19 --> Config Class Initialized
INFO - 2023-07-11 11:10:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:10:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:10:19 --> Utf8 Class Initialized
INFO - 2023-07-11 11:10:19 --> URI Class Initialized
INFO - 2023-07-11 11:10:19 --> Router Class Initialized
INFO - 2023-07-11 11:10:19 --> Output Class Initialized
INFO - 2023-07-11 11:10:19 --> Security Class Initialized
DEBUG - 2023-07-11 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:10:19 --> Input Class Initialized
INFO - 2023-07-11 11:10:19 --> Language Class Initialized
ERROR - 2023-07-11 11:10:19 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 11:10:22 --> Config Class Initialized
INFO - 2023-07-11 11:10:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:10:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:10:22 --> Utf8 Class Initialized
INFO - 2023-07-11 11:10:22 --> URI Class Initialized
INFO - 2023-07-11 11:10:22 --> Router Class Initialized
INFO - 2023-07-11 11:10:22 --> Output Class Initialized
INFO - 2023-07-11 11:10:22 --> Security Class Initialized
DEBUG - 2023-07-11 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:10:22 --> Input Class Initialized
INFO - 2023-07-11 11:10:22 --> Language Class Initialized
INFO - 2023-07-11 11:10:22 --> Loader Class Initialized
INFO - 2023-07-11 11:10:22 --> Helper loaded: url_helper
INFO - 2023-07-11 11:10:22 --> Database Driver Class Initialized
INFO - 2023-07-11 11:10:22 --> Controller Class Initialized
INFO - 2023-07-11 11:10:22 --> Final output sent to browser
DEBUG - 2023-07-11 11:10:22 --> Total execution time: 0.1449
INFO - 2023-07-11 11:11:19 --> Config Class Initialized
INFO - 2023-07-11 11:11:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:11:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:11:19 --> Utf8 Class Initialized
INFO - 2023-07-11 11:11:19 --> URI Class Initialized
INFO - 2023-07-11 11:11:19 --> Router Class Initialized
INFO - 2023-07-11 11:11:19 --> Output Class Initialized
INFO - 2023-07-11 11:11:19 --> Security Class Initialized
DEBUG - 2023-07-11 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:11:19 --> Input Class Initialized
INFO - 2023-07-11 11:11:19 --> Language Class Initialized
INFO - 2023-07-11 11:11:19 --> Loader Class Initialized
INFO - 2023-07-11 11:11:19 --> Helper loaded: url_helper
INFO - 2023-07-11 11:11:19 --> Database Driver Class Initialized
INFO - 2023-07-11 11:11:19 --> Controller Class Initialized
INFO - 2023-07-11 11:11:19 --> Final output sent to browser
DEBUG - 2023-07-11 11:11:19 --> Total execution time: 0.3331
INFO - 2023-07-11 11:11:20 --> Config Class Initialized
INFO - 2023-07-11 11:11:20 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:11:20 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:11:20 --> Utf8 Class Initialized
INFO - 2023-07-11 11:11:20 --> URI Class Initialized
INFO - 2023-07-11 11:11:20 --> Router Class Initialized
INFO - 2023-07-11 11:11:20 --> Output Class Initialized
INFO - 2023-07-11 11:11:20 --> Security Class Initialized
DEBUG - 2023-07-11 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:11:20 --> Input Class Initialized
INFO - 2023-07-11 11:11:20 --> Language Class Initialized
INFO - 2023-07-11 11:11:20 --> Loader Class Initialized
INFO - 2023-07-11 11:11:20 --> Helper loaded: url_helper
INFO - 2023-07-11 11:11:20 --> Database Driver Class Initialized
INFO - 2023-07-11 11:11:20 --> Controller Class Initialized
INFO - 2023-07-11 11:11:20 --> Final output sent to browser
DEBUG - 2023-07-11 11:11:20 --> Total execution time: 0.1484
INFO - 2023-07-11 11:11:20 --> Config Class Initialized
INFO - 2023-07-11 11:11:20 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:11:20 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:11:20 --> Utf8 Class Initialized
INFO - 2023-07-11 11:11:20 --> URI Class Initialized
INFO - 2023-07-11 11:11:20 --> Router Class Initialized
INFO - 2023-07-11 11:11:20 --> Output Class Initialized
INFO - 2023-07-11 11:11:20 --> Security Class Initialized
DEBUG - 2023-07-11 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:11:20 --> Input Class Initialized
INFO - 2023-07-11 11:11:20 --> Language Class Initialized
INFO - 2023-07-11 11:11:20 --> Loader Class Initialized
INFO - 2023-07-11 11:11:20 --> Helper loaded: url_helper
INFO - 2023-07-11 11:11:20 --> Database Driver Class Initialized
INFO - 2023-07-11 11:11:20 --> Controller Class Initialized
INFO - 2023-07-11 11:11:20 --> Final output sent to browser
DEBUG - 2023-07-11 11:11:20 --> Total execution time: 0.0521
INFO - 2023-07-11 11:11:20 --> Config Class Initialized
INFO - 2023-07-11 11:11:20 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:11:20 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:11:20 --> Utf8 Class Initialized
INFO - 2023-07-11 11:11:20 --> URI Class Initialized
INFO - 2023-07-11 11:11:20 --> Router Class Initialized
INFO - 2023-07-11 11:11:20 --> Output Class Initialized
INFO - 2023-07-11 11:11:20 --> Security Class Initialized
DEBUG - 2023-07-11 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:11:20 --> Input Class Initialized
INFO - 2023-07-11 11:11:20 --> Language Class Initialized
INFO - 2023-07-11 11:11:20 --> Loader Class Initialized
INFO - 2023-07-11 11:11:20 --> Helper loaded: url_helper
INFO - 2023-07-11 11:11:20 --> Database Driver Class Initialized
INFO - 2023-07-11 11:11:20 --> Controller Class Initialized
INFO - 2023-07-11 11:11:20 --> Final output sent to browser
DEBUG - 2023-07-11 11:11:20 --> Total execution time: 0.0514
INFO - 2023-07-11 11:11:21 --> Config Class Initialized
INFO - 2023-07-11 11:11:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:11:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:11:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:11:21 --> URI Class Initialized
INFO - 2023-07-11 11:11:21 --> Router Class Initialized
INFO - 2023-07-11 11:11:21 --> Output Class Initialized
INFO - 2023-07-11 11:11:21 --> Security Class Initialized
DEBUG - 2023-07-11 11:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:11:21 --> Input Class Initialized
INFO - 2023-07-11 11:11:21 --> Language Class Initialized
INFO - 2023-07-11 11:11:21 --> Loader Class Initialized
INFO - 2023-07-11 11:11:21 --> Helper loaded: url_helper
INFO - 2023-07-11 11:11:21 --> Database Driver Class Initialized
INFO - 2023-07-11 11:11:21 --> Controller Class Initialized
INFO - 2023-07-11 11:11:21 --> Final output sent to browser
DEBUG - 2023-07-11 11:11:21 --> Total execution time: 0.0504
INFO - 2023-07-11 11:11:40 --> Config Class Initialized
INFO - 2023-07-11 11:11:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:11:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:11:40 --> Utf8 Class Initialized
INFO - 2023-07-11 11:11:40 --> URI Class Initialized
INFO - 2023-07-11 11:11:40 --> Router Class Initialized
INFO - 2023-07-11 11:11:40 --> Output Class Initialized
INFO - 2023-07-11 11:11:40 --> Security Class Initialized
DEBUG - 2023-07-11 11:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:11:40 --> Input Class Initialized
INFO - 2023-07-11 11:11:40 --> Language Class Initialized
INFO - 2023-07-11 11:11:40 --> Loader Class Initialized
INFO - 2023-07-11 11:11:40 --> Helper loaded: url_helper
INFO - 2023-07-11 11:11:40 --> Database Driver Class Initialized
INFO - 2023-07-11 11:11:40 --> Controller Class Initialized
INFO - 2023-07-11 11:11:40 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:11:40 --> Final output sent to browser
DEBUG - 2023-07-11 11:11:40 --> Total execution time: 0.0843
INFO - 2023-07-11 11:11:40 --> Config Class Initialized
INFO - 2023-07-11 11:11:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:11:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:11:40 --> Utf8 Class Initialized
INFO - 2023-07-11 11:11:40 --> URI Class Initialized
INFO - 2023-07-11 11:11:40 --> Router Class Initialized
INFO - 2023-07-11 11:11:40 --> Output Class Initialized
INFO - 2023-07-11 11:11:40 --> Security Class Initialized
DEBUG - 2023-07-11 11:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:11:40 --> Input Class Initialized
INFO - 2023-07-11 11:11:40 --> Language Class Initialized
ERROR - 2023-07-11 11:11:40 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:13:58 --> Config Class Initialized
INFO - 2023-07-11 11:13:58 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:13:58 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:13:58 --> Utf8 Class Initialized
INFO - 2023-07-11 11:13:58 --> URI Class Initialized
INFO - 2023-07-11 11:13:58 --> Router Class Initialized
INFO - 2023-07-11 11:13:58 --> Output Class Initialized
INFO - 2023-07-11 11:13:58 --> Security Class Initialized
DEBUG - 2023-07-11 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:13:58 --> Input Class Initialized
INFO - 2023-07-11 11:13:58 --> Language Class Initialized
INFO - 2023-07-11 11:13:58 --> Loader Class Initialized
INFO - 2023-07-11 11:13:58 --> Helper loaded: url_helper
INFO - 2023-07-11 11:13:59 --> Database Driver Class Initialized
INFO - 2023-07-11 11:13:59 --> Controller Class Initialized
INFO - 2023-07-11 11:13:59 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:13:59 --> Final output sent to browser
DEBUG - 2023-07-11 11:13:59 --> Total execution time: 0.0621
INFO - 2023-07-11 11:13:59 --> Config Class Initialized
INFO - 2023-07-11 11:13:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:13:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:13:59 --> Utf8 Class Initialized
INFO - 2023-07-11 11:13:59 --> URI Class Initialized
INFO - 2023-07-11 11:13:59 --> Router Class Initialized
INFO - 2023-07-11 11:13:59 --> Output Class Initialized
INFO - 2023-07-11 11:13:59 --> Security Class Initialized
DEBUG - 2023-07-11 11:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:13:59 --> Input Class Initialized
INFO - 2023-07-11 11:13:59 --> Language Class Initialized
ERROR - 2023-07-11 11:13:59 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:13:59 --> Config Class Initialized
INFO - 2023-07-11 11:13:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:13:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:13:59 --> Utf8 Class Initialized
INFO - 2023-07-11 11:13:59 --> URI Class Initialized
INFO - 2023-07-11 11:13:59 --> Router Class Initialized
INFO - 2023-07-11 11:13:59 --> Output Class Initialized
INFO - 2023-07-11 11:13:59 --> Security Class Initialized
DEBUG - 2023-07-11 11:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:13:59 --> Input Class Initialized
INFO - 2023-07-11 11:13:59 --> Language Class Initialized
INFO - 2023-07-11 11:13:59 --> Loader Class Initialized
INFO - 2023-07-11 11:13:59 --> Helper loaded: url_helper
INFO - 2023-07-11 11:13:59 --> Database Driver Class Initialized
INFO - 2023-07-11 11:13:59 --> Controller Class Initialized
INFO - 2023-07-11 11:13:59 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:13:59 --> Final output sent to browser
DEBUG - 2023-07-11 11:13:59 --> Total execution time: 0.0502
INFO - 2023-07-11 11:13:59 --> Config Class Initialized
INFO - 2023-07-11 11:13:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:13:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:13:59 --> Utf8 Class Initialized
INFO - 2023-07-11 11:13:59 --> URI Class Initialized
INFO - 2023-07-11 11:13:59 --> Router Class Initialized
INFO - 2023-07-11 11:13:59 --> Output Class Initialized
INFO - 2023-07-11 11:13:59 --> Security Class Initialized
DEBUG - 2023-07-11 11:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:13:59 --> Input Class Initialized
INFO - 2023-07-11 11:13:59 --> Language Class Initialized
ERROR - 2023-07-11 11:13:59 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:15:51 --> Config Class Initialized
INFO - 2023-07-11 11:15:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:15:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:15:51 --> Utf8 Class Initialized
INFO - 2023-07-11 11:15:51 --> URI Class Initialized
INFO - 2023-07-11 11:15:51 --> Router Class Initialized
INFO - 2023-07-11 11:15:51 --> Output Class Initialized
INFO - 2023-07-11 11:15:51 --> Security Class Initialized
DEBUG - 2023-07-11 11:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:15:51 --> Input Class Initialized
INFO - 2023-07-11 11:15:51 --> Language Class Initialized
INFO - 2023-07-11 11:15:51 --> Loader Class Initialized
INFO - 2023-07-11 11:15:51 --> Helper loaded: url_helper
INFO - 2023-07-11 11:15:51 --> Database Driver Class Initialized
INFO - 2023-07-11 11:15:51 --> Controller Class Initialized
ERROR - 2023-07-11 11:15:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\code\application\controllers\registerctr.php 50
INFO - 2023-07-11 11:15:51 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:15:51 --> Final output sent to browser
DEBUG - 2023-07-11 11:15:51 --> Total execution time: 0.0931
INFO - 2023-07-11 11:15:51 --> Config Class Initialized
INFO - 2023-07-11 11:15:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:15:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:15:52 --> Utf8 Class Initialized
INFO - 2023-07-11 11:15:52 --> URI Class Initialized
INFO - 2023-07-11 11:15:52 --> Router Class Initialized
INFO - 2023-07-11 11:15:52 --> Output Class Initialized
INFO - 2023-07-11 11:15:52 --> Security Class Initialized
DEBUG - 2023-07-11 11:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:15:52 --> Input Class Initialized
INFO - 2023-07-11 11:15:52 --> Language Class Initialized
ERROR - 2023-07-11 11:15:52 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:16:10 --> Config Class Initialized
INFO - 2023-07-11 11:16:10 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:10 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:10 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:10 --> URI Class Initialized
INFO - 2023-07-11 11:16:10 --> Router Class Initialized
INFO - 2023-07-11 11:16:10 --> Output Class Initialized
INFO - 2023-07-11 11:16:10 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:10 --> Input Class Initialized
INFO - 2023-07-11 11:16:10 --> Language Class Initialized
INFO - 2023-07-11 11:16:10 --> Loader Class Initialized
INFO - 2023-07-11 11:16:10 --> Helper loaded: url_helper
INFO - 2023-07-11 11:16:10 --> Database Driver Class Initialized
INFO - 2023-07-11 11:16:10 --> Controller Class Initialized
INFO - 2023-07-11 11:16:10 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:16:10 --> Final output sent to browser
DEBUG - 2023-07-11 11:16:10 --> Total execution time: 0.0771
INFO - 2023-07-11 11:16:10 --> Config Class Initialized
INFO - 2023-07-11 11:16:10 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:10 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:10 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:10 --> URI Class Initialized
INFO - 2023-07-11 11:16:10 --> Router Class Initialized
INFO - 2023-07-11 11:16:10 --> Output Class Initialized
INFO - 2023-07-11 11:16:10 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:10 --> Input Class Initialized
INFO - 2023-07-11 11:16:10 --> Language Class Initialized
ERROR - 2023-07-11 11:16:10 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:16:20 --> Config Class Initialized
INFO - 2023-07-11 11:16:20 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:21 --> URI Class Initialized
INFO - 2023-07-11 11:16:21 --> Router Class Initialized
INFO - 2023-07-11 11:16:21 --> Output Class Initialized
INFO - 2023-07-11 11:16:21 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:21 --> Input Class Initialized
INFO - 2023-07-11 11:16:21 --> Language Class Initialized
INFO - 2023-07-11 11:16:21 --> Loader Class Initialized
INFO - 2023-07-11 11:16:21 --> Helper loaded: url_helper
INFO - 2023-07-11 11:16:21 --> Database Driver Class Initialized
INFO - 2023-07-11 11:16:21 --> Controller Class Initialized
INFO - 2023-07-11 11:16:21 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:16:21 --> Final output sent to browser
DEBUG - 2023-07-11 11:16:21 --> Total execution time: 0.0841
INFO - 2023-07-11 11:16:21 --> Config Class Initialized
INFO - 2023-07-11 11:16:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:21 --> URI Class Initialized
INFO - 2023-07-11 11:16:21 --> Router Class Initialized
INFO - 2023-07-11 11:16:21 --> Output Class Initialized
INFO - 2023-07-11 11:16:21 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:21 --> Input Class Initialized
INFO - 2023-07-11 11:16:21 --> Language Class Initialized
ERROR - 2023-07-11 11:16:21 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:16:21 --> Config Class Initialized
INFO - 2023-07-11 11:16:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:21 --> URI Class Initialized
INFO - 2023-07-11 11:16:21 --> Router Class Initialized
INFO - 2023-07-11 11:16:21 --> Output Class Initialized
INFO - 2023-07-11 11:16:21 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:21 --> Input Class Initialized
INFO - 2023-07-11 11:16:21 --> Language Class Initialized
INFO - 2023-07-11 11:16:22 --> Loader Class Initialized
INFO - 2023-07-11 11:16:22 --> Helper loaded: url_helper
INFO - 2023-07-11 11:16:22 --> Database Driver Class Initialized
INFO - 2023-07-11 11:16:22 --> Controller Class Initialized
INFO - 2023-07-11 11:16:22 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:16:22 --> Final output sent to browser
DEBUG - 2023-07-11 11:16:22 --> Total execution time: 0.0626
INFO - 2023-07-11 11:16:22 --> Config Class Initialized
INFO - 2023-07-11 11:16:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:22 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:22 --> URI Class Initialized
INFO - 2023-07-11 11:16:22 --> Router Class Initialized
INFO - 2023-07-11 11:16:22 --> Output Class Initialized
INFO - 2023-07-11 11:16:22 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:22 --> Input Class Initialized
INFO - 2023-07-11 11:16:22 --> Language Class Initialized
ERROR - 2023-07-11 11:16:22 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:16:22 --> Config Class Initialized
INFO - 2023-07-11 11:16:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:22 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:22 --> URI Class Initialized
INFO - 2023-07-11 11:16:22 --> Router Class Initialized
INFO - 2023-07-11 11:16:22 --> Output Class Initialized
INFO - 2023-07-11 11:16:22 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:22 --> Input Class Initialized
INFO - 2023-07-11 11:16:22 --> Language Class Initialized
INFO - 2023-07-11 11:16:22 --> Loader Class Initialized
INFO - 2023-07-11 11:16:22 --> Helper loaded: url_helper
INFO - 2023-07-11 11:16:22 --> Database Driver Class Initialized
INFO - 2023-07-11 11:16:22 --> Controller Class Initialized
INFO - 2023-07-11 11:16:22 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:16:22 --> Final output sent to browser
DEBUG - 2023-07-11 11:16:22 --> Total execution time: 0.0554
INFO - 2023-07-11 11:16:22 --> Config Class Initialized
INFO - 2023-07-11 11:16:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:22 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:22 --> URI Class Initialized
INFO - 2023-07-11 11:16:22 --> Router Class Initialized
INFO - 2023-07-11 11:16:22 --> Output Class Initialized
INFO - 2023-07-11 11:16:22 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:22 --> Input Class Initialized
INFO - 2023-07-11 11:16:22 --> Language Class Initialized
ERROR - 2023-07-11 11:16:22 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:16:31 --> Config Class Initialized
INFO - 2023-07-11 11:16:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:31 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:31 --> URI Class Initialized
INFO - 2023-07-11 11:16:31 --> Router Class Initialized
INFO - 2023-07-11 11:16:31 --> Output Class Initialized
INFO - 2023-07-11 11:16:31 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:31 --> Input Class Initialized
INFO - 2023-07-11 11:16:31 --> Language Class Initialized
INFO - 2023-07-11 11:16:31 --> Loader Class Initialized
INFO - 2023-07-11 11:16:31 --> Helper loaded: url_helper
INFO - 2023-07-11 11:16:31 --> Database Driver Class Initialized
INFO - 2023-07-11 11:16:31 --> Controller Class Initialized
INFO - 2023-07-11 11:16:31 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:16:31 --> Final output sent to browser
DEBUG - 2023-07-11 11:16:31 --> Total execution time: 0.0538
INFO - 2023-07-11 11:16:31 --> Config Class Initialized
INFO - 2023-07-11 11:16:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:16:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:16:31 --> Utf8 Class Initialized
INFO - 2023-07-11 11:16:31 --> URI Class Initialized
INFO - 2023-07-11 11:16:31 --> Router Class Initialized
INFO - 2023-07-11 11:16:31 --> Output Class Initialized
INFO - 2023-07-11 11:16:31 --> Security Class Initialized
DEBUG - 2023-07-11 11:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:16:31 --> Input Class Initialized
INFO - 2023-07-11 11:16:31 --> Language Class Initialized
ERROR - 2023-07-11 11:16:31 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:18:46 --> Config Class Initialized
INFO - 2023-07-11 11:18:46 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:18:46 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:18:46 --> Utf8 Class Initialized
INFO - 2023-07-11 11:18:46 --> URI Class Initialized
INFO - 2023-07-11 11:18:46 --> Router Class Initialized
INFO - 2023-07-11 11:18:46 --> Output Class Initialized
INFO - 2023-07-11 11:18:46 --> Security Class Initialized
DEBUG - 2023-07-11 11:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:18:46 --> Input Class Initialized
INFO - 2023-07-11 11:18:46 --> Language Class Initialized
ERROR - 2023-07-11 11:18:46 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\code\application\controllers\registerctr.php 48
INFO - 2023-07-11 11:18:47 --> Config Class Initialized
INFO - 2023-07-11 11:18:47 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:18:47 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:18:47 --> Utf8 Class Initialized
INFO - 2023-07-11 11:18:47 --> URI Class Initialized
INFO - 2023-07-11 11:18:47 --> Router Class Initialized
INFO - 2023-07-11 11:18:47 --> Output Class Initialized
INFO - 2023-07-11 11:18:47 --> Security Class Initialized
DEBUG - 2023-07-11 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:18:47 --> Input Class Initialized
INFO - 2023-07-11 11:18:47 --> Language Class Initialized
ERROR - 2023-07-11 11:18:47 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\code\application\controllers\registerctr.php 48
INFO - 2023-07-11 11:19:27 --> Config Class Initialized
INFO - 2023-07-11 11:19:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:19:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:19:27 --> Utf8 Class Initialized
INFO - 2023-07-11 11:19:27 --> URI Class Initialized
INFO - 2023-07-11 11:19:27 --> Router Class Initialized
INFO - 2023-07-11 11:19:27 --> Output Class Initialized
INFO - 2023-07-11 11:19:27 --> Security Class Initialized
DEBUG - 2023-07-11 11:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:19:27 --> Input Class Initialized
INFO - 2023-07-11 11:19:27 --> Language Class Initialized
INFO - 2023-07-11 11:19:27 --> Loader Class Initialized
INFO - 2023-07-11 11:19:28 --> Helper loaded: url_helper
INFO - 2023-07-11 11:19:28 --> Database Driver Class Initialized
INFO - 2023-07-11 11:19:28 --> Controller Class Initialized
INFO - 2023-07-11 11:19:28 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:19:28 --> Final output sent to browser
DEBUG - 2023-07-11 11:19:28 --> Total execution time: 0.7403
INFO - 2023-07-11 11:19:28 --> Config Class Initialized
INFO - 2023-07-11 11:19:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:19:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:19:28 --> Utf8 Class Initialized
INFO - 2023-07-11 11:19:28 --> URI Class Initialized
INFO - 2023-07-11 11:19:28 --> Router Class Initialized
INFO - 2023-07-11 11:19:28 --> Output Class Initialized
INFO - 2023-07-11 11:19:29 --> Security Class Initialized
DEBUG - 2023-07-11 11:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:19:29 --> Input Class Initialized
INFO - 2023-07-11 11:19:29 --> Language Class Initialized
ERROR - 2023-07-11 11:19:29 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:19:42 --> Config Class Initialized
INFO - 2023-07-11 11:19:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:19:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:19:42 --> Utf8 Class Initialized
INFO - 2023-07-11 11:19:42 --> URI Class Initialized
INFO - 2023-07-11 11:19:42 --> Router Class Initialized
INFO - 2023-07-11 11:19:42 --> Output Class Initialized
INFO - 2023-07-11 11:19:42 --> Security Class Initialized
DEBUG - 2023-07-11 11:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:19:42 --> Input Class Initialized
INFO - 2023-07-11 11:19:42 --> Language Class Initialized
INFO - 2023-07-11 11:19:42 --> Loader Class Initialized
INFO - 2023-07-11 11:19:42 --> Helper loaded: url_helper
INFO - 2023-07-11 11:19:42 --> Database Driver Class Initialized
INFO - 2023-07-11 11:19:42 --> Controller Class Initialized
INFO - 2023-07-11 11:19:42 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:19:42 --> Final output sent to browser
DEBUG - 2023-07-11 11:19:42 --> Total execution time: 0.0545
INFO - 2023-07-11 11:19:42 --> Config Class Initialized
INFO - 2023-07-11 11:19:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:19:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:19:42 --> Utf8 Class Initialized
INFO - 2023-07-11 11:19:42 --> URI Class Initialized
INFO - 2023-07-11 11:19:42 --> Router Class Initialized
INFO - 2023-07-11 11:19:42 --> Output Class Initialized
INFO - 2023-07-11 11:19:42 --> Security Class Initialized
DEBUG - 2023-07-11 11:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:19:42 --> Input Class Initialized
INFO - 2023-07-11 11:19:42 --> Language Class Initialized
ERROR - 2023-07-11 11:19:42 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:20:27 --> Config Class Initialized
INFO - 2023-07-11 11:20:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:20:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:20:27 --> Utf8 Class Initialized
INFO - 2023-07-11 11:20:27 --> URI Class Initialized
INFO - 2023-07-11 11:20:27 --> Router Class Initialized
INFO - 2023-07-11 11:20:27 --> Output Class Initialized
INFO - 2023-07-11 11:20:27 --> Security Class Initialized
DEBUG - 2023-07-11 11:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:20:27 --> Input Class Initialized
INFO - 2023-07-11 11:20:27 --> Language Class Initialized
INFO - 2023-07-11 11:20:27 --> Loader Class Initialized
INFO - 2023-07-11 11:20:27 --> Helper loaded: url_helper
INFO - 2023-07-11 11:20:27 --> Database Driver Class Initialized
INFO - 2023-07-11 11:20:27 --> Controller Class Initialized
INFO - 2023-07-11 11:20:27 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:20:27 --> Final output sent to browser
DEBUG - 2023-07-11 11:20:27 --> Total execution time: 0.0556
INFO - 2023-07-11 11:20:27 --> Config Class Initialized
INFO - 2023-07-11 11:20:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:20:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:20:27 --> Utf8 Class Initialized
INFO - 2023-07-11 11:20:27 --> URI Class Initialized
INFO - 2023-07-11 11:20:27 --> Router Class Initialized
INFO - 2023-07-11 11:20:27 --> Output Class Initialized
INFO - 2023-07-11 11:20:27 --> Security Class Initialized
DEBUG - 2023-07-11 11:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:20:27 --> Input Class Initialized
INFO - 2023-07-11 11:20:27 --> Language Class Initialized
ERROR - 2023-07-11 11:20:27 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:21:42 --> Config Class Initialized
INFO - 2023-07-11 11:21:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:21:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:21:42 --> Utf8 Class Initialized
INFO - 2023-07-11 11:21:42 --> URI Class Initialized
INFO - 2023-07-11 11:21:42 --> Router Class Initialized
INFO - 2023-07-11 11:21:42 --> Output Class Initialized
INFO - 2023-07-11 11:21:42 --> Security Class Initialized
DEBUG - 2023-07-11 11:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:21:42 --> Input Class Initialized
INFO - 2023-07-11 11:21:42 --> Language Class Initialized
INFO - 2023-07-11 11:21:42 --> Loader Class Initialized
INFO - 2023-07-11 11:21:42 --> Helper loaded: url_helper
INFO - 2023-07-11 11:21:42 --> Database Driver Class Initialized
INFO - 2023-07-11 11:21:43 --> Controller Class Initialized
INFO - 2023-07-11 11:21:43 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:21:43 --> Final output sent to browser
DEBUG - 2023-07-11 11:21:43 --> Total execution time: 1.3263
INFO - 2023-07-11 11:21:43 --> Config Class Initialized
INFO - 2023-07-11 11:21:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:21:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:21:44 --> Utf8 Class Initialized
INFO - 2023-07-11 11:21:44 --> URI Class Initialized
INFO - 2023-07-11 11:21:44 --> Router Class Initialized
INFO - 2023-07-11 11:21:44 --> Output Class Initialized
INFO - 2023-07-11 11:21:44 --> Security Class Initialized
DEBUG - 2023-07-11 11:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:21:44 --> Input Class Initialized
INFO - 2023-07-11 11:21:44 --> Language Class Initialized
ERROR - 2023-07-11 11:21:44 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:22:50 --> Config Class Initialized
INFO - 2023-07-11 11:22:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:22:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:22:50 --> Utf8 Class Initialized
INFO - 2023-07-11 11:22:50 --> URI Class Initialized
INFO - 2023-07-11 11:22:50 --> Router Class Initialized
INFO - 2023-07-11 11:22:50 --> Output Class Initialized
INFO - 2023-07-11 11:22:50 --> Security Class Initialized
DEBUG - 2023-07-11 11:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:22:50 --> Input Class Initialized
INFO - 2023-07-11 11:22:50 --> Language Class Initialized
INFO - 2023-07-11 11:22:50 --> Loader Class Initialized
INFO - 2023-07-11 11:22:50 --> Helper loaded: url_helper
INFO - 2023-07-11 11:22:50 --> Database Driver Class Initialized
INFO - 2023-07-11 11:22:50 --> Controller Class Initialized
INFO - 2023-07-11 11:22:50 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:22:50 --> Final output sent to browser
DEBUG - 2023-07-11 11:22:50 --> Total execution time: 0.1250
INFO - 2023-07-11 11:22:50 --> Config Class Initialized
INFO - 2023-07-11 11:22:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:22:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:22:51 --> Utf8 Class Initialized
INFO - 2023-07-11 11:22:51 --> URI Class Initialized
INFO - 2023-07-11 11:22:51 --> Router Class Initialized
INFO - 2023-07-11 11:22:51 --> Output Class Initialized
INFO - 2023-07-11 11:22:51 --> Security Class Initialized
DEBUG - 2023-07-11 11:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:22:51 --> Input Class Initialized
INFO - 2023-07-11 11:22:51 --> Language Class Initialized
ERROR - 2023-07-11 11:22:51 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:23:03 --> Config Class Initialized
INFO - 2023-07-11 11:23:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:23:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:23:03 --> Utf8 Class Initialized
INFO - 2023-07-11 11:23:03 --> URI Class Initialized
INFO - 2023-07-11 11:23:03 --> Router Class Initialized
INFO - 2023-07-11 11:23:03 --> Output Class Initialized
INFO - 2023-07-11 11:23:03 --> Security Class Initialized
DEBUG - 2023-07-11 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:23:03 --> Input Class Initialized
INFO - 2023-07-11 11:23:03 --> Language Class Initialized
INFO - 2023-07-11 11:23:03 --> Loader Class Initialized
INFO - 2023-07-11 11:23:03 --> Helper loaded: url_helper
INFO - 2023-07-11 11:23:03 --> Database Driver Class Initialized
INFO - 2023-07-11 11:23:03 --> Controller Class Initialized
INFO - 2023-07-11 11:23:03 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:23:03 --> Final output sent to browser
DEBUG - 2023-07-11 11:23:03 --> Total execution time: 0.0619
INFO - 2023-07-11 11:23:03 --> Config Class Initialized
INFO - 2023-07-11 11:23:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:23:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:23:03 --> Utf8 Class Initialized
INFO - 2023-07-11 11:23:03 --> URI Class Initialized
INFO - 2023-07-11 11:23:03 --> Router Class Initialized
INFO - 2023-07-11 11:23:03 --> Output Class Initialized
INFO - 2023-07-11 11:23:03 --> Security Class Initialized
DEBUG - 2023-07-11 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:23:03 --> Input Class Initialized
INFO - 2023-07-11 11:23:03 --> Language Class Initialized
ERROR - 2023-07-11 11:23:03 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:23:55 --> Config Class Initialized
INFO - 2023-07-11 11:23:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:23:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:23:55 --> Utf8 Class Initialized
INFO - 2023-07-11 11:23:55 --> URI Class Initialized
INFO - 2023-07-11 11:23:55 --> Router Class Initialized
INFO - 2023-07-11 11:23:55 --> Output Class Initialized
INFO - 2023-07-11 11:23:55 --> Security Class Initialized
DEBUG - 2023-07-11 11:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:23:55 --> Input Class Initialized
INFO - 2023-07-11 11:23:55 --> Language Class Initialized
INFO - 2023-07-11 11:23:55 --> Loader Class Initialized
INFO - 2023-07-11 11:23:55 --> Helper loaded: url_helper
INFO - 2023-07-11 11:23:55 --> Database Driver Class Initialized
INFO - 2023-07-11 11:23:55 --> Controller Class Initialized
INFO - 2023-07-11 11:23:55 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:23:55 --> Final output sent to browser
DEBUG - 2023-07-11 11:23:55 --> Total execution time: 0.0546
INFO - 2023-07-11 11:23:55 --> Config Class Initialized
INFO - 2023-07-11 11:23:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:23:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:23:55 --> Utf8 Class Initialized
INFO - 2023-07-11 11:23:55 --> URI Class Initialized
INFO - 2023-07-11 11:23:55 --> Router Class Initialized
INFO - 2023-07-11 11:23:55 --> Output Class Initialized
INFO - 2023-07-11 11:23:55 --> Security Class Initialized
DEBUG - 2023-07-11 11:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:23:55 --> Input Class Initialized
INFO - 2023-07-11 11:23:55 --> Language Class Initialized
ERROR - 2023-07-11 11:23:55 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:24:01 --> Config Class Initialized
INFO - 2023-07-11 11:24:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:24:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:24:01 --> Utf8 Class Initialized
INFO - 2023-07-11 11:24:01 --> URI Class Initialized
INFO - 2023-07-11 11:24:01 --> Router Class Initialized
INFO - 2023-07-11 11:24:01 --> Output Class Initialized
INFO - 2023-07-11 11:24:01 --> Security Class Initialized
DEBUG - 2023-07-11 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:24:01 --> Input Class Initialized
INFO - 2023-07-11 11:24:01 --> Language Class Initialized
INFO - 2023-07-11 11:24:01 --> Loader Class Initialized
INFO - 2023-07-11 11:24:01 --> Helper loaded: url_helper
INFO - 2023-07-11 11:24:01 --> Database Driver Class Initialized
INFO - 2023-07-11 11:24:01 --> Controller Class Initialized
INFO - 2023-07-11 11:24:01 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:24:01 --> Final output sent to browser
DEBUG - 2023-07-11 11:24:01 --> Total execution time: 0.1080
INFO - 2023-07-11 11:24:01 --> Config Class Initialized
INFO - 2023-07-11 11:24:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:24:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:24:01 --> Utf8 Class Initialized
INFO - 2023-07-11 11:24:01 --> URI Class Initialized
INFO - 2023-07-11 11:24:01 --> Router Class Initialized
INFO - 2023-07-11 11:24:01 --> Output Class Initialized
INFO - 2023-07-11 11:24:01 --> Security Class Initialized
DEBUG - 2023-07-11 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:24:01 --> Input Class Initialized
INFO - 2023-07-11 11:24:01 --> Language Class Initialized
ERROR - 2023-07-11 11:24:01 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:24:07 --> Config Class Initialized
INFO - 2023-07-11 11:24:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:24:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:24:07 --> Utf8 Class Initialized
INFO - 2023-07-11 11:24:07 --> URI Class Initialized
INFO - 2023-07-11 11:24:07 --> Router Class Initialized
INFO - 2023-07-11 11:24:07 --> Output Class Initialized
INFO - 2023-07-11 11:24:07 --> Security Class Initialized
DEBUG - 2023-07-11 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:24:07 --> Input Class Initialized
INFO - 2023-07-11 11:24:07 --> Language Class Initialized
INFO - 2023-07-11 11:24:07 --> Loader Class Initialized
INFO - 2023-07-11 11:24:07 --> Helper loaded: url_helper
INFO - 2023-07-11 11:24:07 --> Database Driver Class Initialized
INFO - 2023-07-11 11:24:07 --> Controller Class Initialized
INFO - 2023-07-11 11:24:07 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:24:08 --> Final output sent to browser
DEBUG - 2023-07-11 11:24:08 --> Total execution time: 0.0565
INFO - 2023-07-11 11:24:08 --> Config Class Initialized
INFO - 2023-07-11 11:24:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:24:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:24:08 --> Utf8 Class Initialized
INFO - 2023-07-11 11:24:08 --> URI Class Initialized
INFO - 2023-07-11 11:24:08 --> Router Class Initialized
INFO - 2023-07-11 11:24:08 --> Output Class Initialized
INFO - 2023-07-11 11:24:08 --> Security Class Initialized
DEBUG - 2023-07-11 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:24:08 --> Input Class Initialized
INFO - 2023-07-11 11:24:08 --> Language Class Initialized
ERROR - 2023-07-11 11:24:08 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:31:12 --> Config Class Initialized
INFO - 2023-07-11 11:31:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:31:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:31:12 --> Utf8 Class Initialized
INFO - 2023-07-11 11:31:12 --> URI Class Initialized
INFO - 2023-07-11 11:31:12 --> Router Class Initialized
INFO - 2023-07-11 11:31:12 --> Output Class Initialized
INFO - 2023-07-11 11:31:12 --> Security Class Initialized
DEBUG - 2023-07-11 11:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:31:12 --> Input Class Initialized
INFO - 2023-07-11 11:31:12 --> Language Class Initialized
INFO - 2023-07-11 11:31:12 --> Loader Class Initialized
INFO - 2023-07-11 11:31:12 --> Helper loaded: url_helper
INFO - 2023-07-11 11:31:12 --> Database Driver Class Initialized
INFO - 2023-07-11 11:31:12 --> Controller Class Initialized
INFO - 2023-07-11 11:31:12 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:31:12 --> Final output sent to browser
DEBUG - 2023-07-11 11:31:12 --> Total execution time: 0.0684
INFO - 2023-07-11 11:31:12 --> Config Class Initialized
INFO - 2023-07-11 11:31:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:31:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:31:12 --> Utf8 Class Initialized
INFO - 2023-07-11 11:31:12 --> URI Class Initialized
INFO - 2023-07-11 11:31:12 --> Router Class Initialized
INFO - 2023-07-11 11:31:12 --> Output Class Initialized
INFO - 2023-07-11 11:31:12 --> Security Class Initialized
DEBUG - 2023-07-11 11:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:31:12 --> Input Class Initialized
INFO - 2023-07-11 11:31:12 --> Language Class Initialized
ERROR - 2023-07-11 11:31:12 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:31:20 --> Config Class Initialized
INFO - 2023-07-11 11:31:20 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:31:20 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:31:20 --> Utf8 Class Initialized
INFO - 2023-07-11 11:31:20 --> URI Class Initialized
INFO - 2023-07-11 11:31:20 --> Router Class Initialized
INFO - 2023-07-11 11:31:20 --> Output Class Initialized
INFO - 2023-07-11 11:31:20 --> Security Class Initialized
DEBUG - 2023-07-11 11:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:31:20 --> Input Class Initialized
INFO - 2023-07-11 11:31:20 --> Language Class Initialized
INFO - 2023-07-11 11:31:20 --> Loader Class Initialized
INFO - 2023-07-11 11:31:20 --> Helper loaded: url_helper
INFO - 2023-07-11 11:31:20 --> Database Driver Class Initialized
INFO - 2023-07-11 11:31:20 --> Controller Class Initialized
INFO - 2023-07-11 11:31:20 --> Final output sent to browser
DEBUG - 2023-07-11 11:31:20 --> Total execution time: 0.0536
INFO - 2023-07-11 11:31:48 --> Config Class Initialized
INFO - 2023-07-11 11:31:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:31:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:31:48 --> Utf8 Class Initialized
INFO - 2023-07-11 11:31:48 --> URI Class Initialized
INFO - 2023-07-11 11:31:48 --> Router Class Initialized
INFO - 2023-07-11 11:31:48 --> Output Class Initialized
INFO - 2023-07-11 11:31:48 --> Security Class Initialized
DEBUG - 2023-07-11 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:31:48 --> Input Class Initialized
INFO - 2023-07-11 11:31:48 --> Language Class Initialized
INFO - 2023-07-11 11:31:48 --> Loader Class Initialized
INFO - 2023-07-11 11:31:48 --> Helper loaded: url_helper
INFO - 2023-07-11 11:31:48 --> Database Driver Class Initialized
INFO - 2023-07-11 11:31:48 --> Controller Class Initialized
INFO - 2023-07-11 11:31:48 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:31:48 --> Final output sent to browser
DEBUG - 2023-07-11 11:31:48 --> Total execution time: 0.0524
INFO - 2023-07-11 11:31:48 --> Config Class Initialized
INFO - 2023-07-11 11:31:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:31:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:31:48 --> Utf8 Class Initialized
INFO - 2023-07-11 11:31:48 --> URI Class Initialized
INFO - 2023-07-11 11:31:48 --> Router Class Initialized
INFO - 2023-07-11 11:31:48 --> Output Class Initialized
INFO - 2023-07-11 11:31:48 --> Security Class Initialized
DEBUG - 2023-07-11 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:31:48 --> Input Class Initialized
INFO - 2023-07-11 11:31:48 --> Language Class Initialized
ERROR - 2023-07-11 11:31:48 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:32:04 --> Config Class Initialized
INFO - 2023-07-11 11:32:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:32:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:32:04 --> Utf8 Class Initialized
INFO - 2023-07-11 11:32:04 --> URI Class Initialized
INFO - 2023-07-11 11:32:04 --> Router Class Initialized
INFO - 2023-07-11 11:32:04 --> Output Class Initialized
INFO - 2023-07-11 11:32:04 --> Security Class Initialized
DEBUG - 2023-07-11 11:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:32:04 --> Input Class Initialized
INFO - 2023-07-11 11:32:04 --> Language Class Initialized
INFO - 2023-07-11 11:32:04 --> Loader Class Initialized
INFO - 2023-07-11 11:32:04 --> Helper loaded: url_helper
INFO - 2023-07-11 11:32:04 --> Database Driver Class Initialized
INFO - 2023-07-11 11:32:04 --> Controller Class Initialized
INFO - 2023-07-11 11:32:04 --> Final output sent to browser
DEBUG - 2023-07-11 11:32:04 --> Total execution time: 0.0523
INFO - 2023-07-11 11:33:44 --> Config Class Initialized
INFO - 2023-07-11 11:33:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:33:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:33:44 --> Utf8 Class Initialized
INFO - 2023-07-11 11:33:44 --> URI Class Initialized
INFO - 2023-07-11 11:33:44 --> Router Class Initialized
INFO - 2023-07-11 11:33:44 --> Output Class Initialized
INFO - 2023-07-11 11:33:44 --> Security Class Initialized
DEBUG - 2023-07-11 11:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:33:44 --> Input Class Initialized
INFO - 2023-07-11 11:33:44 --> Language Class Initialized
INFO - 2023-07-11 11:33:44 --> Loader Class Initialized
INFO - 2023-07-11 11:33:44 --> Helper loaded: url_helper
INFO - 2023-07-11 11:33:44 --> Database Driver Class Initialized
INFO - 2023-07-11 11:33:44 --> Controller Class Initialized
INFO - 2023-07-11 11:33:44 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:33:44 --> Final output sent to browser
DEBUG - 2023-07-11 11:33:44 --> Total execution time: 0.0525
INFO - 2023-07-11 11:33:44 --> Config Class Initialized
INFO - 2023-07-11 11:33:44 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:33:44 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:33:44 --> Utf8 Class Initialized
INFO - 2023-07-11 11:33:44 --> URI Class Initialized
INFO - 2023-07-11 11:33:44 --> Router Class Initialized
INFO - 2023-07-11 11:33:44 --> Output Class Initialized
INFO - 2023-07-11 11:33:44 --> Security Class Initialized
DEBUG - 2023-07-11 11:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:33:44 --> Input Class Initialized
INFO - 2023-07-11 11:33:44 --> Language Class Initialized
ERROR - 2023-07-11 11:33:44 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:33:50 --> Config Class Initialized
INFO - 2023-07-11 11:33:50 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:33:50 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:33:50 --> Utf8 Class Initialized
INFO - 2023-07-11 11:33:50 --> URI Class Initialized
INFO - 2023-07-11 11:33:50 --> Router Class Initialized
INFO - 2023-07-11 11:33:50 --> Output Class Initialized
INFO - 2023-07-11 11:33:50 --> Security Class Initialized
DEBUG - 2023-07-11 11:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:33:50 --> Input Class Initialized
INFO - 2023-07-11 11:33:50 --> Language Class Initialized
INFO - 2023-07-11 11:33:50 --> Loader Class Initialized
INFO - 2023-07-11 11:33:50 --> Helper loaded: url_helper
INFO - 2023-07-11 11:33:50 --> Database Driver Class Initialized
INFO - 2023-07-11 11:33:50 --> Controller Class Initialized
INFO - 2023-07-11 11:33:51 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:33:51 --> Final output sent to browser
DEBUG - 2023-07-11 11:33:51 --> Total execution time: 0.6775
INFO - 2023-07-11 11:33:51 --> Config Class Initialized
INFO - 2023-07-11 11:33:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:33:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:33:51 --> Utf8 Class Initialized
INFO - 2023-07-11 11:33:51 --> URI Class Initialized
INFO - 2023-07-11 11:33:51 --> Router Class Initialized
INFO - 2023-07-11 11:33:51 --> Output Class Initialized
INFO - 2023-07-11 11:33:51 --> Security Class Initialized
DEBUG - 2023-07-11 11:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:33:51 --> Input Class Initialized
INFO - 2023-07-11 11:33:51 --> Language Class Initialized
ERROR - 2023-07-11 11:33:51 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:34:15 --> Config Class Initialized
INFO - 2023-07-11 11:34:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:34:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:34:15 --> Utf8 Class Initialized
INFO - 2023-07-11 11:34:15 --> URI Class Initialized
INFO - 2023-07-11 11:34:15 --> Router Class Initialized
INFO - 2023-07-11 11:34:15 --> Output Class Initialized
INFO - 2023-07-11 11:34:15 --> Security Class Initialized
DEBUG - 2023-07-11 11:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:34:15 --> Input Class Initialized
INFO - 2023-07-11 11:34:15 --> Language Class Initialized
INFO - 2023-07-11 11:34:15 --> Loader Class Initialized
INFO - 2023-07-11 11:34:15 --> Helper loaded: url_helper
INFO - 2023-07-11 11:34:15 --> Database Driver Class Initialized
INFO - 2023-07-11 11:34:15 --> Controller Class Initialized
INFO - 2023-07-11 11:34:15 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:34:15 --> Final output sent to browser
DEBUG - 2023-07-11 11:34:15 --> Total execution time: 0.0537
INFO - 2023-07-11 11:34:56 --> Config Class Initialized
INFO - 2023-07-11 11:34:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:34:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:34:56 --> Utf8 Class Initialized
INFO - 2023-07-11 11:34:56 --> URI Class Initialized
INFO - 2023-07-11 11:34:56 --> Router Class Initialized
INFO - 2023-07-11 11:34:56 --> Output Class Initialized
INFO - 2023-07-11 11:34:56 --> Security Class Initialized
DEBUG - 2023-07-11 11:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:34:56 --> Input Class Initialized
INFO - 2023-07-11 11:34:56 --> Language Class Initialized
INFO - 2023-07-11 11:34:56 --> Loader Class Initialized
INFO - 2023-07-11 11:34:56 --> Helper loaded: url_helper
INFO - 2023-07-11 11:34:56 --> Database Driver Class Initialized
INFO - 2023-07-11 11:34:56 --> Controller Class Initialized
INFO - 2023-07-11 11:34:56 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:34:56 --> Final output sent to browser
DEBUG - 2023-07-11 11:34:56 --> Total execution time: 0.0605
INFO - 2023-07-11 11:35:18 --> Config Class Initialized
INFO - 2023-07-11 11:35:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:35:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:35:18 --> Utf8 Class Initialized
INFO - 2023-07-11 11:35:18 --> URI Class Initialized
INFO - 2023-07-11 11:35:18 --> Router Class Initialized
INFO - 2023-07-11 11:35:18 --> Output Class Initialized
INFO - 2023-07-11 11:35:18 --> Security Class Initialized
DEBUG - 2023-07-11 11:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:35:18 --> Input Class Initialized
INFO - 2023-07-11 11:35:18 --> Language Class Initialized
INFO - 2023-07-11 11:35:18 --> Loader Class Initialized
INFO - 2023-07-11 11:35:18 --> Helper loaded: url_helper
INFO - 2023-07-11 11:35:18 --> Database Driver Class Initialized
INFO - 2023-07-11 11:35:18 --> Controller Class Initialized
INFO - 2023-07-11 11:35:18 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:35:18 --> Final output sent to browser
DEBUG - 2023-07-11 11:35:18 --> Total execution time: 0.0801
INFO - 2023-07-11 11:35:18 --> Config Class Initialized
INFO - 2023-07-11 11:35:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:35:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:35:18 --> Utf8 Class Initialized
INFO - 2023-07-11 11:35:18 --> URI Class Initialized
INFO - 2023-07-11 11:35:18 --> Router Class Initialized
INFO - 2023-07-11 11:35:18 --> Output Class Initialized
INFO - 2023-07-11 11:35:18 --> Security Class Initialized
DEBUG - 2023-07-11 11:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:35:18 --> Input Class Initialized
INFO - 2023-07-11 11:35:18 --> Language Class Initialized
ERROR - 2023-07-11 11:35:18 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:35:27 --> Config Class Initialized
INFO - 2023-07-11 11:35:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:35:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:35:27 --> Utf8 Class Initialized
INFO - 2023-07-11 11:35:27 --> URI Class Initialized
INFO - 2023-07-11 11:35:27 --> Router Class Initialized
INFO - 2023-07-11 11:35:27 --> Output Class Initialized
INFO - 2023-07-11 11:35:27 --> Security Class Initialized
DEBUG - 2023-07-11 11:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:35:27 --> Input Class Initialized
INFO - 2023-07-11 11:35:27 --> Language Class Initialized
INFO - 2023-07-11 11:35:27 --> Loader Class Initialized
INFO - 2023-07-11 11:35:27 --> Helper loaded: url_helper
INFO - 2023-07-11 11:35:27 --> Database Driver Class Initialized
INFO - 2023-07-11 11:35:27 --> Controller Class Initialized
INFO - 2023-07-11 11:35:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:35:27 --> Final output sent to browser
DEBUG - 2023-07-11 11:35:27 --> Total execution time: 0.0621
INFO - 2023-07-11 11:36:52 --> Config Class Initialized
INFO - 2023-07-11 11:36:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:36:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:36:52 --> Utf8 Class Initialized
INFO - 2023-07-11 11:36:52 --> URI Class Initialized
INFO - 2023-07-11 11:36:52 --> Router Class Initialized
INFO - 2023-07-11 11:36:52 --> Output Class Initialized
INFO - 2023-07-11 11:36:52 --> Security Class Initialized
DEBUG - 2023-07-11 11:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:36:52 --> Input Class Initialized
INFO - 2023-07-11 11:36:52 --> Language Class Initialized
INFO - 2023-07-11 11:36:52 --> Loader Class Initialized
INFO - 2023-07-11 11:36:52 --> Helper loaded: url_helper
INFO - 2023-07-11 11:36:52 --> Database Driver Class Initialized
INFO - 2023-07-11 11:36:52 --> Controller Class Initialized
INFO - 2023-07-11 11:36:52 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:36:52 --> Final output sent to browser
DEBUG - 2023-07-11 11:36:52 --> Total execution time: 0.0783
INFO - 2023-07-11 11:36:52 --> Config Class Initialized
INFO - 2023-07-11 11:36:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:36:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:36:52 --> Utf8 Class Initialized
INFO - 2023-07-11 11:36:52 --> URI Class Initialized
INFO - 2023-07-11 11:36:52 --> Router Class Initialized
INFO - 2023-07-11 11:36:52 --> Output Class Initialized
INFO - 2023-07-11 11:36:52 --> Security Class Initialized
DEBUG - 2023-07-11 11:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:36:52 --> Input Class Initialized
INFO - 2023-07-11 11:36:52 --> Language Class Initialized
ERROR - 2023-07-11 11:36:52 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 11:36:59 --> Config Class Initialized
INFO - 2023-07-11 11:36:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:36:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:36:59 --> Utf8 Class Initialized
INFO - 2023-07-11 11:36:59 --> URI Class Initialized
INFO - 2023-07-11 11:36:59 --> Router Class Initialized
INFO - 2023-07-11 11:36:59 --> Output Class Initialized
INFO - 2023-07-11 11:36:59 --> Security Class Initialized
DEBUG - 2023-07-11 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:36:59 --> Input Class Initialized
INFO - 2023-07-11 11:36:59 --> Language Class Initialized
INFO - 2023-07-11 11:36:59 --> Loader Class Initialized
INFO - 2023-07-11 11:36:59 --> Helper loaded: url_helper
INFO - 2023-07-11 11:36:59 --> Database Driver Class Initialized
INFO - 2023-07-11 11:36:59 --> Controller Class Initialized
INFO - 2023-07-11 11:36:59 --> File loaded: C:\xampp\htdocs\code\application\views\/home.php
INFO - 2023-07-11 11:36:59 --> Final output sent to browser
DEBUG - 2023-07-11 11:36:59 --> Total execution time: 0.0873
INFO - 2023-07-11 11:39:13 --> Config Class Initialized
INFO - 2023-07-11 11:39:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:13 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:13 --> URI Class Initialized
INFO - 2023-07-11 11:39:13 --> Router Class Initialized
INFO - 2023-07-11 11:39:13 --> Output Class Initialized
INFO - 2023-07-11 11:39:13 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:13 --> Input Class Initialized
INFO - 2023-07-11 11:39:13 --> Language Class Initialized
INFO - 2023-07-11 11:39:13 --> Loader Class Initialized
INFO - 2023-07-11 11:39:13 --> Helper loaded: url_helper
INFO - 2023-07-11 11:39:13 --> Database Driver Class Initialized
INFO - 2023-07-11 11:39:13 --> Controller Class Initialized
INFO - 2023-07-11 11:39:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:39:13 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:39:13 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:39:13 --> Final output sent to browser
DEBUG - 2023-07-11 11:39:13 --> Total execution time: 0.0599
INFO - 2023-07-11 11:39:13 --> Config Class Initialized
INFO - 2023-07-11 11:39:13 --> Hooks Class Initialized
INFO - 2023-07-11 11:39:13 --> Config Class Initialized
INFO - 2023-07-11 11:39:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:13 --> Utf8 Class Initialized
DEBUG - 2023-07-11 11:39:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:13 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:13 --> URI Class Initialized
INFO - 2023-07-11 11:39:13 --> URI Class Initialized
INFO - 2023-07-11 11:39:13 --> Router Class Initialized
INFO - 2023-07-11 11:39:13 --> Router Class Initialized
INFO - 2023-07-11 11:39:13 --> Output Class Initialized
INFO - 2023-07-11 11:39:13 --> Output Class Initialized
INFO - 2023-07-11 11:39:13 --> Security Class Initialized
INFO - 2023-07-11 11:39:13 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:13 --> Input Class Initialized
INFO - 2023-07-11 11:39:13 --> Input Class Initialized
INFO - 2023-07-11 11:39:13 --> Language Class Initialized
INFO - 2023-07-11 11:39:13 --> Language Class Initialized
ERROR - 2023-07-11 11:39:13 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 11:39:13 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 11:39:13 --> Config Class Initialized
INFO - 2023-07-11 11:39:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:13 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:13 --> URI Class Initialized
INFO - 2023-07-11 11:39:13 --> Router Class Initialized
INFO - 2023-07-11 11:39:13 --> Output Class Initialized
INFO - 2023-07-11 11:39:13 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:13 --> Input Class Initialized
INFO - 2023-07-11 11:39:13 --> Language Class Initialized
ERROR - 2023-07-11 11:39:13 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 11:39:42 --> Config Class Initialized
INFO - 2023-07-11 11:39:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:42 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:42 --> URI Class Initialized
INFO - 2023-07-11 11:39:42 --> Router Class Initialized
INFO - 2023-07-11 11:39:42 --> Output Class Initialized
INFO - 2023-07-11 11:39:42 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:42 --> Input Class Initialized
INFO - 2023-07-11 11:39:42 --> Language Class Initialized
INFO - 2023-07-11 11:39:42 --> Loader Class Initialized
INFO - 2023-07-11 11:39:42 --> Helper loaded: url_helper
INFO - 2023-07-11 11:39:42 --> Database Driver Class Initialized
INFO - 2023-07-11 11:39:42 --> Controller Class Initialized
INFO - 2023-07-11 11:39:42 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:39:42 --> Final output sent to browser
DEBUG - 2023-07-11 11:39:42 --> Total execution time: 0.0887
INFO - 2023-07-11 11:39:42 --> Config Class Initialized
INFO - 2023-07-11 11:39:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:42 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:42 --> URI Class Initialized
INFO - 2023-07-11 11:39:42 --> Router Class Initialized
INFO - 2023-07-11 11:39:42 --> Output Class Initialized
INFO - 2023-07-11 11:39:42 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:42 --> Input Class Initialized
INFO - 2023-07-11 11:39:42 --> Language Class Initialized
ERROR - 2023-07-11 11:39:42 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:39:49 --> Config Class Initialized
INFO - 2023-07-11 11:39:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:49 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:49 --> URI Class Initialized
INFO - 2023-07-11 11:39:49 --> Router Class Initialized
INFO - 2023-07-11 11:39:49 --> Output Class Initialized
INFO - 2023-07-11 11:39:49 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:49 --> Input Class Initialized
INFO - 2023-07-11 11:39:49 --> Language Class Initialized
INFO - 2023-07-11 11:39:49 --> Loader Class Initialized
INFO - 2023-07-11 11:39:49 --> Helper loaded: url_helper
INFO - 2023-07-11 11:39:49 --> Database Driver Class Initialized
INFO - 2023-07-11 11:39:49 --> Controller Class Initialized
INFO - 2023-07-11 11:39:49 --> Config Class Initialized
INFO - 2023-07-11 11:39:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:49 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:49 --> URI Class Initialized
INFO - 2023-07-11 11:39:49 --> Router Class Initialized
INFO - 2023-07-11 11:39:49 --> Output Class Initialized
INFO - 2023-07-11 11:39:49 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:49 --> Input Class Initialized
INFO - 2023-07-11 11:39:49 --> Language Class Initialized
INFO - 2023-07-11 11:39:49 --> Loader Class Initialized
INFO - 2023-07-11 11:39:49 --> Helper loaded: url_helper
INFO - 2023-07-11 11:39:49 --> Database Driver Class Initialized
INFO - 2023-07-11 11:39:49 --> Controller Class Initialized
INFO - 2023-07-11 11:39:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:39:49 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:39:49 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:39:49 --> Final output sent to browser
DEBUG - 2023-07-11 11:39:49 --> Total execution time: 0.0546
INFO - 2023-07-11 11:39:49 --> Config Class Initialized
INFO - 2023-07-11 11:39:49 --> Config Class Initialized
INFO - 2023-07-11 11:39:49 --> Hooks Class Initialized
INFO - 2023-07-11 11:39:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:49 --> Utf8 Class Initialized
DEBUG - 2023-07-11 11:39:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:49 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:49 --> URI Class Initialized
INFO - 2023-07-11 11:39:49 --> URI Class Initialized
INFO - 2023-07-11 11:39:49 --> Router Class Initialized
INFO - 2023-07-11 11:39:49 --> Router Class Initialized
INFO - 2023-07-11 11:39:49 --> Output Class Initialized
INFO - 2023-07-11 11:39:49 --> Output Class Initialized
INFO - 2023-07-11 11:39:49 --> Security Class Initialized
INFO - 2023-07-11 11:39:49 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:49 --> Input Class Initialized
INFO - 2023-07-11 11:39:49 --> Language Class Initialized
DEBUG - 2023-07-11 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:49 --> Input Class Initialized
ERROR - 2023-07-11 11:39:49 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 11:39:49 --> Language Class Initialized
ERROR - 2023-07-11 11:39:49 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 11:39:49 --> Config Class Initialized
INFO - 2023-07-11 11:39:49 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:39:49 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:39:49 --> Utf8 Class Initialized
INFO - 2023-07-11 11:39:49 --> URI Class Initialized
INFO - 2023-07-11 11:39:49 --> Router Class Initialized
INFO - 2023-07-11 11:39:49 --> Output Class Initialized
INFO - 2023-07-11 11:39:49 --> Security Class Initialized
DEBUG - 2023-07-11 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:39:49 --> Input Class Initialized
INFO - 2023-07-11 11:39:49 --> Language Class Initialized
ERROR - 2023-07-11 11:39:49 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 11:40:29 --> Config Class Initialized
INFO - 2023-07-11 11:40:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:40:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:40:29 --> Utf8 Class Initialized
INFO - 2023-07-11 11:40:29 --> URI Class Initialized
INFO - 2023-07-11 11:40:29 --> Router Class Initialized
INFO - 2023-07-11 11:40:29 --> Output Class Initialized
INFO - 2023-07-11 11:40:29 --> Security Class Initialized
DEBUG - 2023-07-11 11:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:40:29 --> Input Class Initialized
INFO - 2023-07-11 11:40:29 --> Language Class Initialized
INFO - 2023-07-11 11:40:29 --> Loader Class Initialized
INFO - 2023-07-11 11:40:29 --> Helper loaded: url_helper
INFO - 2023-07-11 11:40:29 --> Database Driver Class Initialized
INFO - 2023-07-11 11:40:29 --> Controller Class Initialized
INFO - 2023-07-11 11:40:29 --> File loaded: C:\xampp\htdocs\code\application\views\register.php
INFO - 2023-07-11 11:40:29 --> Final output sent to browser
DEBUG - 2023-07-11 11:40:29 --> Total execution time: 0.1269
INFO - 2023-07-11 11:40:29 --> Config Class Initialized
INFO - 2023-07-11 11:40:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:40:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:40:29 --> Utf8 Class Initialized
INFO - 2023-07-11 11:40:29 --> URI Class Initialized
INFO - 2023-07-11 11:40:29 --> Router Class Initialized
INFO - 2023-07-11 11:40:29 --> Output Class Initialized
INFO - 2023-07-11 11:40:29 --> Security Class Initialized
DEBUG - 2023-07-11 11:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:40:29 --> Input Class Initialized
INFO - 2023-07-11 11:40:29 --> Language Class Initialized
ERROR - 2023-07-11 11:40:29 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:40:48 --> Config Class Initialized
INFO - 2023-07-11 11:40:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:40:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:40:48 --> Utf8 Class Initialized
INFO - 2023-07-11 11:40:48 --> URI Class Initialized
INFO - 2023-07-11 11:40:48 --> Router Class Initialized
INFO - 2023-07-11 11:40:48 --> Output Class Initialized
INFO - 2023-07-11 11:40:48 --> Security Class Initialized
DEBUG - 2023-07-11 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:40:48 --> Input Class Initialized
INFO - 2023-07-11 11:40:48 --> Language Class Initialized
INFO - 2023-07-11 11:40:48 --> Loader Class Initialized
INFO - 2023-07-11 11:40:48 --> Helper loaded: url_helper
INFO - 2023-07-11 11:40:48 --> Database Driver Class Initialized
INFO - 2023-07-11 11:40:48 --> Controller Class Initialized
INFO - 2023-07-11 11:40:48 --> Config Class Initialized
INFO - 2023-07-11 11:40:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:40:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:40:48 --> Utf8 Class Initialized
INFO - 2023-07-11 11:40:48 --> URI Class Initialized
INFO - 2023-07-11 11:40:48 --> Router Class Initialized
INFO - 2023-07-11 11:40:48 --> Output Class Initialized
INFO - 2023-07-11 11:40:48 --> Security Class Initialized
DEBUG - 2023-07-11 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:40:48 --> Input Class Initialized
INFO - 2023-07-11 11:40:48 --> Language Class Initialized
INFO - 2023-07-11 11:40:48 --> Loader Class Initialized
INFO - 2023-07-11 11:40:48 --> Helper loaded: url_helper
INFO - 2023-07-11 11:40:48 --> Database Driver Class Initialized
INFO - 2023-07-11 11:40:48 --> Controller Class Initialized
INFO - 2023-07-11 11:40:48 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:40:48 --> Final output sent to browser
DEBUG - 2023-07-11 11:40:48 --> Total execution time: 0.0509
INFO - 2023-07-11 11:40:48 --> Config Class Initialized
INFO - 2023-07-11 11:40:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:40:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:40:48 --> Utf8 Class Initialized
INFO - 2023-07-11 11:40:48 --> URI Class Initialized
INFO - 2023-07-11 11:40:48 --> Router Class Initialized
INFO - 2023-07-11 11:40:48 --> Output Class Initialized
INFO - 2023-07-11 11:40:48 --> Security Class Initialized
DEBUG - 2023-07-11 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:40:48 --> Input Class Initialized
INFO - 2023-07-11 11:40:48 --> Language Class Initialized
ERROR - 2023-07-11 11:40:48 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:41:00 --> Config Class Initialized
INFO - 2023-07-11 11:41:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:00 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:00 --> URI Class Initialized
INFO - 2023-07-11 11:41:00 --> Router Class Initialized
INFO - 2023-07-11 11:41:00 --> Output Class Initialized
INFO - 2023-07-11 11:41:00 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:00 --> Input Class Initialized
INFO - 2023-07-11 11:41:00 --> Language Class Initialized
INFO - 2023-07-11 11:41:00 --> Loader Class Initialized
INFO - 2023-07-11 11:41:00 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:00 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:00 --> Controller Class Initialized
INFO - 2023-07-11 11:41:00 --> Config Class Initialized
INFO - 2023-07-11 11:41:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:00 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:00 --> URI Class Initialized
INFO - 2023-07-11 11:41:00 --> Router Class Initialized
INFO - 2023-07-11 11:41:00 --> Output Class Initialized
INFO - 2023-07-11 11:41:00 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:00 --> Input Class Initialized
INFO - 2023-07-11 11:41:00 --> Language Class Initialized
INFO - 2023-07-11 11:41:00 --> Loader Class Initialized
INFO - 2023-07-11 11:41:00 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:00 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:00 --> Controller Class Initialized
INFO - 2023-07-11 11:41:00 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:41:00 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:41:00 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:41:00 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:00 --> Total execution time: 0.0619
INFO - 2023-07-11 11:41:00 --> Config Class Initialized
INFO - 2023-07-11 11:41:00 --> Hooks Class Initialized
INFO - 2023-07-11 11:41:00 --> Config Class Initialized
INFO - 2023-07-11 11:41:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:00 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:00 --> URI Class Initialized
DEBUG - 2023-07-11 11:41:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:00 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:00 --> Router Class Initialized
INFO - 2023-07-11 11:41:00 --> URI Class Initialized
INFO - 2023-07-11 11:41:00 --> Router Class Initialized
INFO - 2023-07-11 11:41:00 --> Output Class Initialized
INFO - 2023-07-11 11:41:00 --> Output Class Initialized
INFO - 2023-07-11 11:41:00 --> Security Class Initialized
INFO - 2023-07-11 11:41:00 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:00 --> Input Class Initialized
DEBUG - 2023-07-11 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:00 --> Language Class Initialized
INFO - 2023-07-11 11:41:00 --> Input Class Initialized
INFO - 2023-07-11 11:41:00 --> Language Class Initialized
ERROR - 2023-07-11 11:41:00 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 11:41:00 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 11:41:00 --> Config Class Initialized
INFO - 2023-07-11 11:41:00 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:00 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:00 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:00 --> URI Class Initialized
INFO - 2023-07-11 11:41:00 --> Router Class Initialized
INFO - 2023-07-11 11:41:00 --> Output Class Initialized
INFO - 2023-07-11 11:41:00 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:00 --> Input Class Initialized
INFO - 2023-07-11 11:41:00 --> Language Class Initialized
ERROR - 2023-07-11 11:41:00 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 11:41:04 --> Config Class Initialized
INFO - 2023-07-11 11:41:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:04 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:04 --> URI Class Initialized
INFO - 2023-07-11 11:41:04 --> Router Class Initialized
INFO - 2023-07-11 11:41:04 --> Output Class Initialized
INFO - 2023-07-11 11:41:04 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:05 --> Input Class Initialized
INFO - 2023-07-11 11:41:05 --> Language Class Initialized
INFO - 2023-07-11 11:41:05 --> Loader Class Initialized
INFO - 2023-07-11 11:41:05 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:05 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:05 --> Controller Class Initialized
INFO - 2023-07-11 11:41:05 --> File loaded: C:\xampp\htdocs\code\application\views\register.php
INFO - 2023-07-11 11:41:05 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:05 --> Total execution time: 0.0542
INFO - 2023-07-11 11:41:05 --> Config Class Initialized
INFO - 2023-07-11 11:41:05 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:05 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:05 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:05 --> URI Class Initialized
INFO - 2023-07-11 11:41:05 --> Router Class Initialized
INFO - 2023-07-11 11:41:05 --> Output Class Initialized
INFO - 2023-07-11 11:41:05 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:05 --> Input Class Initialized
INFO - 2023-07-11 11:41:05 --> Language Class Initialized
ERROR - 2023-07-11 11:41:05 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:41:21 --> Config Class Initialized
INFO - 2023-07-11 11:41:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:21 --> URI Class Initialized
INFO - 2023-07-11 11:41:21 --> Router Class Initialized
INFO - 2023-07-11 11:41:21 --> Output Class Initialized
INFO - 2023-07-11 11:41:21 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:21 --> Input Class Initialized
INFO - 2023-07-11 11:41:21 --> Language Class Initialized
INFO - 2023-07-11 11:41:21 --> Config Class Initialized
INFO - 2023-07-11 11:41:21 --> Hooks Class Initialized
INFO - 2023-07-11 11:41:21 --> Config Class Initialized
INFO - 2023-07-11 11:41:21 --> Config Class Initialized
INFO - 2023-07-11 11:41:21 --> Hooks Class Initialized
INFO - 2023-07-11 11:41:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:21 --> Utf8 Class Initialized
DEBUG - 2023-07-11 11:41:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:21 --> URI Class Initialized
DEBUG - 2023-07-11 11:41:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:21 --> Router Class Initialized
INFO - 2023-07-11 11:41:21 --> URI Class Initialized
INFO - 2023-07-11 11:41:21 --> URI Class Initialized
INFO - 2023-07-11 11:41:21 --> Router Class Initialized
INFO - 2023-07-11 11:41:21 --> Output Class Initialized
INFO - 2023-07-11 11:41:21 --> Router Class Initialized
INFO - 2023-07-11 11:41:21 --> Output Class Initialized
INFO - 2023-07-11 11:41:21 --> Loader Class Initialized
INFO - 2023-07-11 11:41:21 --> Security Class Initialized
INFO - 2023-07-11 11:41:21 --> Output Class Initialized
DEBUG - 2023-07-11 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:21 --> Security Class Initialized
INFO - 2023-07-11 11:41:21 --> Input Class Initialized
INFO - 2023-07-11 11:41:21 --> Language Class Initialized
DEBUG - 2023-07-11 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:21 --> Input Class Initialized
INFO - 2023-07-11 11:41:21 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:21 --> Language Class Initialized
INFO - 2023-07-11 11:41:21 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:21 --> Input Class Initialized
INFO - 2023-07-11 11:41:21 --> Language Class Initialized
ERROR - 2023-07-11 11:41:21 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 11:41:21 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:21 --> Loader Class Initialized
INFO - 2023-07-11 11:41:21 --> Loader Class Initialized
INFO - 2023-07-11 11:41:21 --> Controller Class Initialized
INFO - 2023-07-11 11:41:21 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:21 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:21 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:21 --> Controller Class Initialized
INFO - 2023-07-11 11:41:21 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:21 --> Controller Class Initialized
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:41:21 --> Config Class Initialized
INFO - 2023-07-11 11:41:21 --> Hooks Class Initialized
INFO - 2023-07-11 11:41:21 --> Config Class Initialized
INFO - 2023-07-11 11:41:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:21 --> Utf8 Class Initialized
DEBUG - 2023-07-11 11:41:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:21 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:21 --> URI Class Initialized
INFO - 2023-07-11 11:41:21 --> Router Class Initialized
INFO - 2023-07-11 11:41:21 --> URI Class Initialized
INFO - 2023-07-11 11:41:21 --> Router Class Initialized
INFO - 2023-07-11 11:41:21 --> Output Class Initialized
INFO - 2023-07-11 11:41:21 --> Output Class Initialized
INFO - 2023-07-11 11:41:21 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:21 --> Input Class Initialized
INFO - 2023-07-11 11:41:21 --> Security Class Initialized
INFO - 2023-07-11 11:41:21 --> Language Class Initialized
DEBUG - 2023-07-11 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:21 --> Input Class Initialized
INFO - 2023-07-11 11:41:21 --> Language Class Initialized
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
INFO - 2023-07-11 11:41:21 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:21 --> Total execution time: 0.5947
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
ERROR - 2023-07-11 11:41:21 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:41:21 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:41:21 --> Final output sent to browser
INFO - 2023-07-11 11:41:21 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:21 --> Total execution time: 0.6010
DEBUG - 2023-07-11 11:41:21 --> Total execution time: 0.6735
INFO - 2023-07-11 11:41:22 --> Loader Class Initialized
INFO - 2023-07-11 11:41:22 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:22 --> Loader Class Initialized
INFO - 2023-07-11 11:41:22 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:22 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:22 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:22 --> Controller Class Initialized
INFO - 2023-07-11 11:41:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
INFO - 2023-07-11 11:41:22 --> Controller Class Initialized
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 11:41:22 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 11:41:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:41:22 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:22 --> Total execution time: 0.5140
INFO - 2023-07-11 11:41:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\code\application\views\editPage.php 87
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\code\application\views\editPage.php 93
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\code\application\views\editPage.php 99
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'current_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 119
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'permanent_address' of non-object C:\xampp\htdocs\code\application\views\editPage.php 124
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'linkdin' of non-object C:\xampp\htdocs\code\application\views\editPage.php 140
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'git' of non-object C:\xampp\htdocs\code\application\views\editPage.php 145
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'facebook' of non-object C:\xampp\htdocs\code\application\views\editPage.php 150
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'company' of non-object C:\xampp\htdocs\code\application\views\editPage.php 171
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'department' of non-object C:\xampp\htdocs\code\application\views\editPage.php 175
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'years' of non-object C:\xampp\htdocs\code\application\views\editPage.php 179
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\code\application\views\editPage.php 197
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'whatsapp' of non-object C:\xampp\htdocs\code\application\views\editPage.php 202
ERROR - 2023-07-11 11:41:22 --> Severity: Notice --> Trying to get property 'about' of non-object C:\xampp\htdocs\code\application\views\editPage.php 223
INFO - 2023-07-11 11:41:22 --> File loaded: C:\xampp\htdocs\code\application\views\editPage.php
INFO - 2023-07-11 11:41:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:41:22 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:22 --> Total execution time: 0.6421
INFO - 2023-07-11 11:41:41 --> Config Class Initialized
INFO - 2023-07-11 11:41:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:41 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:41 --> URI Class Initialized
INFO - 2023-07-11 11:41:41 --> Router Class Initialized
INFO - 2023-07-11 11:41:41 --> Output Class Initialized
INFO - 2023-07-11 11:41:41 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:41 --> Input Class Initialized
INFO - 2023-07-11 11:41:41 --> Language Class Initialized
INFO - 2023-07-11 11:41:41 --> Loader Class Initialized
INFO - 2023-07-11 11:41:41 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:41 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:41 --> Controller Class Initialized
INFO - 2023-07-11 11:41:42 --> Config Class Initialized
INFO - 2023-07-11 11:41:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:42 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:42 --> URI Class Initialized
INFO - 2023-07-11 11:41:42 --> Router Class Initialized
INFO - 2023-07-11 11:41:42 --> Output Class Initialized
INFO - 2023-07-11 11:41:42 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:42 --> Input Class Initialized
INFO - 2023-07-11 11:41:42 --> Language Class Initialized
INFO - 2023-07-11 11:41:42 --> Loader Class Initialized
INFO - 2023-07-11 11:41:42 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:42 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:42 --> Controller Class Initialized
INFO - 2023-07-11 11:41:42 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 11:41:42 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:42 --> Total execution time: 0.0542
INFO - 2023-07-11 11:41:42 --> Config Class Initialized
INFO - 2023-07-11 11:41:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:42 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:42 --> URI Class Initialized
INFO - 2023-07-11 11:41:42 --> Router Class Initialized
INFO - 2023-07-11 11:41:42 --> Output Class Initialized
INFO - 2023-07-11 11:41:42 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:42 --> Input Class Initialized
INFO - 2023-07-11 11:41:42 --> Language Class Initialized
ERROR - 2023-07-11 11:41:42 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 11:41:54 --> Config Class Initialized
INFO - 2023-07-11 11:41:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:54 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:54 --> URI Class Initialized
INFO - 2023-07-11 11:41:54 --> Router Class Initialized
INFO - 2023-07-11 11:41:54 --> Output Class Initialized
INFO - 2023-07-11 11:41:54 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:54 --> Input Class Initialized
INFO - 2023-07-11 11:41:54 --> Language Class Initialized
INFO - 2023-07-11 11:41:54 --> Loader Class Initialized
INFO - 2023-07-11 11:41:54 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:54 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:54 --> Controller Class Initialized
INFO - 2023-07-11 11:41:54 --> Config Class Initialized
INFO - 2023-07-11 11:41:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:54 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:54 --> URI Class Initialized
INFO - 2023-07-11 11:41:54 --> Router Class Initialized
INFO - 2023-07-11 11:41:54 --> Output Class Initialized
INFO - 2023-07-11 11:41:54 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:54 --> Input Class Initialized
INFO - 2023-07-11 11:41:54 --> Language Class Initialized
INFO - 2023-07-11 11:41:54 --> Loader Class Initialized
INFO - 2023-07-11 11:41:54 --> Helper loaded: url_helper
INFO - 2023-07-11 11:41:54 --> Database Driver Class Initialized
INFO - 2023-07-11 11:41:54 --> Controller Class Initialized
INFO - 2023-07-11 11:41:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 11:41:54 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 11:41:54 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 11:41:54 --> Final output sent to browser
DEBUG - 2023-07-11 11:41:54 --> Total execution time: 0.0566
INFO - 2023-07-11 11:41:54 --> Config Class Initialized
INFO - 2023-07-11 11:41:54 --> Hooks Class Initialized
INFO - 2023-07-11 11:41:54 --> Config Class Initialized
INFO - 2023-07-11 11:41:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:54 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:54 --> URI Class Initialized
DEBUG - 2023-07-11 11:41:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:54 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:54 --> Router Class Initialized
INFO - 2023-07-11 11:41:54 --> URI Class Initialized
INFO - 2023-07-11 11:41:54 --> Output Class Initialized
INFO - 2023-07-11 11:41:54 --> Router Class Initialized
INFO - 2023-07-11 11:41:54 --> Security Class Initialized
INFO - 2023-07-11 11:41:54 --> Output Class Initialized
DEBUG - 2023-07-11 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:54 --> Input Class Initialized
INFO - 2023-07-11 11:41:54 --> Security Class Initialized
INFO - 2023-07-11 11:41:54 --> Language Class Initialized
DEBUG - 2023-07-11 11:41:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-07-11 11:41:54 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 11:41:54 --> Input Class Initialized
INFO - 2023-07-11 11:41:54 --> Language Class Initialized
ERROR - 2023-07-11 11:41:54 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 11:41:54 --> Config Class Initialized
INFO - 2023-07-11 11:41:54 --> Hooks Class Initialized
DEBUG - 2023-07-11 11:41:54 --> UTF-8 Support Enabled
INFO - 2023-07-11 11:41:54 --> Utf8 Class Initialized
INFO - 2023-07-11 11:41:54 --> URI Class Initialized
INFO - 2023-07-11 11:41:54 --> Router Class Initialized
INFO - 2023-07-11 11:41:54 --> Output Class Initialized
INFO - 2023-07-11 11:41:54 --> Security Class Initialized
DEBUG - 2023-07-11 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 11:41:54 --> Input Class Initialized
INFO - 2023-07-11 11:41:54 --> Language Class Initialized
ERROR - 2023-07-11 11:41:54 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 12:00:20 --> Config Class Initialized
INFO - 2023-07-11 12:00:20 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:00:20 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:00:20 --> Utf8 Class Initialized
INFO - 2023-07-11 12:00:20 --> URI Class Initialized
INFO - 2023-07-11 12:00:20 --> Router Class Initialized
INFO - 2023-07-11 12:00:20 --> Output Class Initialized
INFO - 2023-07-11 12:00:21 --> Security Class Initialized
DEBUG - 2023-07-11 12:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:00:21 --> Input Class Initialized
INFO - 2023-07-11 12:00:21 --> Language Class Initialized
INFO - 2023-07-11 12:00:21 --> Loader Class Initialized
INFO - 2023-07-11 12:00:21 --> Helper loaded: url_helper
INFO - 2023-07-11 12:00:21 --> Database Driver Class Initialized
INFO - 2023-07-11 12:00:22 --> Controller Class Initialized
INFO - 2023-07-11 12:00:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 12:00:22 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 12:00:22 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 12:00:22 --> Final output sent to browser
DEBUG - 2023-07-11 12:00:22 --> Total execution time: 2.0509
INFO - 2023-07-11 12:00:22 --> Config Class Initialized
INFO - 2023-07-11 12:00:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:00:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:00:22 --> Utf8 Class Initialized
INFO - 2023-07-11 12:00:22 --> URI Class Initialized
INFO - 2023-07-11 12:00:22 --> Router Class Initialized
INFO - 2023-07-11 12:00:22 --> Output Class Initialized
INFO - 2023-07-11 12:00:22 --> Security Class Initialized
DEBUG - 2023-07-11 12:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:00:22 --> Input Class Initialized
INFO - 2023-07-11 12:00:22 --> Language Class Initialized
INFO - 2023-07-11 12:00:22 --> Config Class Initialized
INFO - 2023-07-11 12:00:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:00:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:00:22 --> Utf8 Class Initialized
INFO - 2023-07-11 12:00:22 --> URI Class Initialized
INFO - 2023-07-11 12:00:22 --> Router Class Initialized
INFO - 2023-07-11 12:00:22 --> Output Class Initialized
INFO - 2023-07-11 12:00:22 --> Security Class Initialized
DEBUG - 2023-07-11 12:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:00:22 --> Input Class Initialized
INFO - 2023-07-11 12:00:22 --> Language Class Initialized
ERROR - 2023-07-11 12:00:22 --> 404 Page Not Found: Indexcss/index
ERROR - 2023-07-11 12:00:22 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 12:00:22 --> Config Class Initialized
INFO - 2023-07-11 12:00:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:00:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:00:22 --> Utf8 Class Initialized
INFO - 2023-07-11 12:00:22 --> URI Class Initialized
INFO - 2023-07-11 12:00:22 --> Router Class Initialized
INFO - 2023-07-11 12:00:22 --> Output Class Initialized
INFO - 2023-07-11 12:00:22 --> Security Class Initialized
DEBUG - 2023-07-11 12:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:00:22 --> Input Class Initialized
INFO - 2023-07-11 12:00:22 --> Language Class Initialized
ERROR - 2023-07-11 12:00:22 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 12:00:23 --> Config Class Initialized
INFO - 2023-07-11 12:00:23 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:00:23 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:00:23 --> Utf8 Class Initialized
INFO - 2023-07-11 12:00:23 --> URI Class Initialized
INFO - 2023-07-11 12:00:23 --> Router Class Initialized
INFO - 2023-07-11 12:00:23 --> Output Class Initialized
INFO - 2023-07-11 12:00:23 --> Security Class Initialized
DEBUG - 2023-07-11 12:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:00:23 --> Input Class Initialized
INFO - 2023-07-11 12:00:23 --> Language Class Initialized
INFO - 2023-07-11 12:00:24 --> Loader Class Initialized
INFO - 2023-07-11 12:00:24 --> Helper loaded: url_helper
INFO - 2023-07-11 12:00:24 --> Database Driver Class Initialized
INFO - 2023-07-11 12:00:24 --> Controller Class Initialized
INFO - 2023-07-11 12:00:24 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 12:00:24 --> Final output sent to browser
DEBUG - 2023-07-11 12:00:24 --> Total execution time: 0.2635
INFO - 2023-07-11 12:00:24 --> Config Class Initialized
INFO - 2023-07-11 12:00:24 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:00:24 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:00:24 --> Utf8 Class Initialized
INFO - 2023-07-11 12:00:24 --> URI Class Initialized
INFO - 2023-07-11 12:00:24 --> Router Class Initialized
INFO - 2023-07-11 12:00:24 --> Output Class Initialized
INFO - 2023-07-11 12:00:24 --> Security Class Initialized
DEBUG - 2023-07-11 12:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:00:24 --> Input Class Initialized
INFO - 2023-07-11 12:00:24 --> Language Class Initialized
ERROR - 2023-07-11 12:00:24 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 12:00:33 --> Config Class Initialized
INFO - 2023-07-11 12:00:33 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:00:33 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:00:33 --> Utf8 Class Initialized
INFO - 2023-07-11 12:00:33 --> URI Class Initialized
INFO - 2023-07-11 12:00:33 --> Router Class Initialized
INFO - 2023-07-11 12:00:33 --> Output Class Initialized
INFO - 2023-07-11 12:00:33 --> Security Class Initialized
DEBUG - 2023-07-11 12:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:00:33 --> Input Class Initialized
INFO - 2023-07-11 12:00:33 --> Language Class Initialized
INFO - 2023-07-11 12:00:33 --> Loader Class Initialized
INFO - 2023-07-11 12:00:33 --> Helper loaded: url_helper
INFO - 2023-07-11 12:00:33 --> Database Driver Class Initialized
INFO - 2023-07-11 12:00:33 --> Controller Class Initialized
ERROR - 2023-07-11 12:00:33 --> Severity: Notice --> Undefined property: registerctr::$session C:\xampp\htdocs\code\application\controllers\registerctr.php 41
ERROR - 2023-07-11 12:00:33 --> Severity: error --> Exception: Call to a member function set_userdata() on null C:\xampp\htdocs\code\application\controllers\registerctr.php 41
INFO - 2023-07-11 12:01:01 --> Config Class Initialized
INFO - 2023-07-11 12:01:01 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:01:01 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:01:01 --> Utf8 Class Initialized
INFO - 2023-07-11 12:01:01 --> URI Class Initialized
INFO - 2023-07-11 12:01:01 --> Router Class Initialized
INFO - 2023-07-11 12:01:01 --> Output Class Initialized
INFO - 2023-07-11 12:01:01 --> Security Class Initialized
DEBUG - 2023-07-11 12:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:01:01 --> Input Class Initialized
INFO - 2023-07-11 12:01:01 --> Language Class Initialized
INFO - 2023-07-11 12:01:02 --> Loader Class Initialized
INFO - 2023-07-11 12:01:02 --> Helper loaded: url_helper
INFO - 2023-07-11 12:01:02 --> Database Driver Class Initialized
INFO - 2023-07-11 12:01:02 --> Controller Class Initialized
INFO - 2023-07-11 12:01:02 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 12:01:02 --> Final output sent to browser
DEBUG - 2023-07-11 12:01:02 --> Total execution time: 0.0786
INFO - 2023-07-11 12:01:02 --> Config Class Initialized
INFO - 2023-07-11 12:01:02 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:01:02 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:01:02 --> Utf8 Class Initialized
INFO - 2023-07-11 12:01:02 --> URI Class Initialized
INFO - 2023-07-11 12:01:02 --> Router Class Initialized
INFO - 2023-07-11 12:01:02 --> Output Class Initialized
INFO - 2023-07-11 12:01:02 --> Security Class Initialized
DEBUG - 2023-07-11 12:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:01:02 --> Input Class Initialized
INFO - 2023-07-11 12:01:02 --> Language Class Initialized
ERROR - 2023-07-11 12:01:02 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 12:14:51 --> Config Class Initialized
INFO - 2023-07-11 12:14:51 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:14:51 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:14:51 --> Utf8 Class Initialized
INFO - 2023-07-11 12:14:51 --> URI Class Initialized
INFO - 2023-07-11 12:14:51 --> Router Class Initialized
INFO - 2023-07-11 12:14:51 --> Output Class Initialized
INFO - 2023-07-11 12:14:51 --> Security Class Initialized
DEBUG - 2023-07-11 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:14:51 --> Input Class Initialized
INFO - 2023-07-11 12:14:51 --> Language Class Initialized
INFO - 2023-07-11 12:14:51 --> Loader Class Initialized
INFO - 2023-07-11 12:14:51 --> Helper loaded: url_helper
INFO - 2023-07-11 12:14:51 --> Database Driver Class Initialized
INFO - 2023-07-11 12:14:51 --> Controller Class Initialized
INFO - 2023-07-11 12:14:52 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 12:14:52 --> Final output sent to browser
DEBUG - 2023-07-11 12:14:52 --> Total execution time: 0.8193
INFO - 2023-07-11 12:14:52 --> Config Class Initialized
INFO - 2023-07-11 12:14:52 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:14:52 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:14:52 --> Utf8 Class Initialized
INFO - 2023-07-11 12:14:52 --> URI Class Initialized
INFO - 2023-07-11 12:14:52 --> Router Class Initialized
INFO - 2023-07-11 12:14:52 --> Output Class Initialized
INFO - 2023-07-11 12:14:52 --> Security Class Initialized
DEBUG - 2023-07-11 12:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:14:52 --> Input Class Initialized
INFO - 2023-07-11 12:14:52 --> Language Class Initialized
ERROR - 2023-07-11 12:14:52 --> 404 Page Not Found: Registerctr/style.css
INFO - 2023-07-11 12:15:03 --> Config Class Initialized
INFO - 2023-07-11 12:15:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:15:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:03 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:03 --> URI Class Initialized
INFO - 2023-07-11 12:15:03 --> Router Class Initialized
INFO - 2023-07-11 12:15:03 --> Output Class Initialized
INFO - 2023-07-11 12:15:03 --> Security Class Initialized
DEBUG - 2023-07-11 12:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:03 --> Input Class Initialized
INFO - 2023-07-11 12:15:03 --> Language Class Initialized
INFO - 2023-07-11 12:15:03 --> Loader Class Initialized
INFO - 2023-07-11 12:15:03 --> Helper loaded: url_helper
INFO - 2023-07-11 12:15:03 --> Database Driver Class Initialized
INFO - 2023-07-11 12:15:03 --> Controller Class Initialized
INFO - 2023-07-11 12:15:03 --> Config Class Initialized
INFO - 2023-07-11 12:15:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:15:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:03 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:03 --> URI Class Initialized
INFO - 2023-07-11 12:15:03 --> Router Class Initialized
INFO - 2023-07-11 12:15:03 --> Output Class Initialized
INFO - 2023-07-11 12:15:03 --> Security Class Initialized
DEBUG - 2023-07-11 12:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:03 --> Input Class Initialized
INFO - 2023-07-11 12:15:03 --> Language Class Initialized
INFO - 2023-07-11 12:15:03 --> Loader Class Initialized
INFO - 2023-07-11 12:15:03 --> Helper loaded: url_helper
INFO - 2023-07-11 12:15:03 --> Database Driver Class Initialized
INFO - 2023-07-11 12:15:03 --> Controller Class Initialized
INFO - 2023-07-11 12:15:03 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 12:15:03 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 12:15:03 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 12:15:03 --> Final output sent to browser
DEBUG - 2023-07-11 12:15:03 --> Total execution time: 0.0798
INFO - 2023-07-11 12:15:04 --> Config Class Initialized
INFO - 2023-07-11 12:15:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:15:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:04 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:04 --> URI Class Initialized
INFO - 2023-07-11 12:15:04 --> Router Class Initialized
INFO - 2023-07-11 12:15:04 --> Config Class Initialized
INFO - 2023-07-11 12:15:04 --> Hooks Class Initialized
INFO - 2023-07-11 12:15:04 --> Output Class Initialized
DEBUG - 2023-07-11 12:15:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:04 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:04 --> Security Class Initialized
INFO - 2023-07-11 12:15:04 --> URI Class Initialized
DEBUG - 2023-07-11 12:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:04 --> Input Class Initialized
INFO - 2023-07-11 12:15:04 --> Language Class Initialized
INFO - 2023-07-11 12:15:04 --> Router Class Initialized
ERROR - 2023-07-11 12:15:04 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 12:15:04 --> Output Class Initialized
INFO - 2023-07-11 12:15:04 --> Security Class Initialized
DEBUG - 2023-07-11 12:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:04 --> Input Class Initialized
INFO - 2023-07-11 12:15:04 --> Language Class Initialized
ERROR - 2023-07-11 12:15:04 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 12:15:04 --> Config Class Initialized
INFO - 2023-07-11 12:15:04 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:15:04 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:04 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:04 --> URI Class Initialized
INFO - 2023-07-11 12:15:04 --> Router Class Initialized
INFO - 2023-07-11 12:15:04 --> Output Class Initialized
INFO - 2023-07-11 12:15:04 --> Security Class Initialized
DEBUG - 2023-07-11 12:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:04 --> Input Class Initialized
INFO - 2023-07-11 12:15:04 --> Language Class Initialized
ERROR - 2023-07-11 12:15:04 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 12:15:11 --> Config Class Initialized
INFO - 2023-07-11 12:15:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:15:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:11 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:11 --> URI Class Initialized
INFO - 2023-07-11 12:15:11 --> Router Class Initialized
INFO - 2023-07-11 12:15:11 --> Output Class Initialized
INFO - 2023-07-11 12:15:11 --> Security Class Initialized
DEBUG - 2023-07-11 12:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:11 --> Input Class Initialized
INFO - 2023-07-11 12:15:12 --> Language Class Initialized
INFO - 2023-07-11 12:15:12 --> Loader Class Initialized
INFO - 2023-07-11 12:15:12 --> Helper loaded: url_helper
INFO - 2023-07-11 12:15:12 --> Database Driver Class Initialized
INFO - 2023-07-11 12:15:12 --> Controller Class Initialized
INFO - 2023-07-11 12:15:12 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 12:15:12 --> Final output sent to browser
DEBUG - 2023-07-11 12:15:12 --> Total execution time: 0.0514
INFO - 2023-07-11 12:15:12 --> Config Class Initialized
INFO - 2023-07-11 12:15:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:15:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:12 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:12 --> URI Class Initialized
INFO - 2023-07-11 12:15:12 --> Router Class Initialized
INFO - 2023-07-11 12:15:12 --> Output Class Initialized
INFO - 2023-07-11 12:15:12 --> Security Class Initialized
DEBUG - 2023-07-11 12:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:12 --> Input Class Initialized
INFO - 2023-07-11 12:15:12 --> Language Class Initialized
ERROR - 2023-07-11 12:15:12 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 12:15:33 --> Config Class Initialized
INFO - 2023-07-11 12:15:33 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:15:33 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:15:33 --> Utf8 Class Initialized
INFO - 2023-07-11 12:15:33 --> URI Class Initialized
INFO - 2023-07-11 12:15:33 --> Router Class Initialized
INFO - 2023-07-11 12:15:33 --> Output Class Initialized
INFO - 2023-07-11 12:15:33 --> Security Class Initialized
DEBUG - 2023-07-11 12:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:15:33 --> Input Class Initialized
INFO - 2023-07-11 12:15:33 --> Language Class Initialized
ERROR - 2023-07-11 12:15:33 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 12:16:18 --> Config Class Initialized
INFO - 2023-07-11 12:16:18 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:16:18 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:16:18 --> Utf8 Class Initialized
INFO - 2023-07-11 12:16:18 --> URI Class Initialized
INFO - 2023-07-11 12:16:18 --> Router Class Initialized
INFO - 2023-07-11 12:16:19 --> Output Class Initialized
INFO - 2023-07-11 12:16:19 --> Security Class Initialized
DEBUG - 2023-07-11 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:16:19 --> Input Class Initialized
INFO - 2023-07-11 12:16:19 --> Language Class Initialized
INFO - 2023-07-11 12:16:19 --> Loader Class Initialized
INFO - 2023-07-11 12:16:19 --> Helper loaded: url_helper
INFO - 2023-07-11 12:16:19 --> Database Driver Class Initialized
INFO - 2023-07-11 12:16:19 --> Controller Class Initialized
INFO - 2023-07-11 12:16:19 --> Config Class Initialized
INFO - 2023-07-11 12:16:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:16:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:16:19 --> Utf8 Class Initialized
INFO - 2023-07-11 12:16:19 --> URI Class Initialized
INFO - 2023-07-11 12:16:19 --> Router Class Initialized
INFO - 2023-07-11 12:16:19 --> Output Class Initialized
INFO - 2023-07-11 12:16:19 --> Security Class Initialized
DEBUG - 2023-07-11 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:16:19 --> Input Class Initialized
INFO - 2023-07-11 12:16:19 --> Language Class Initialized
INFO - 2023-07-11 12:16:19 --> Loader Class Initialized
INFO - 2023-07-11 12:16:19 --> Helper loaded: url_helper
INFO - 2023-07-11 12:16:19 --> Database Driver Class Initialized
INFO - 2023-07-11 12:16:19 --> Controller Class Initialized
INFO - 2023-07-11 12:16:19 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 12:16:19 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 12:16:19 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 12:16:19 --> Final output sent to browser
DEBUG - 2023-07-11 12:16:19 --> Total execution time: 0.0567
INFO - 2023-07-11 12:16:19 --> Config Class Initialized
INFO - 2023-07-11 12:16:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:16:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:16:19 --> Utf8 Class Initialized
INFO - 2023-07-11 12:16:19 --> URI Class Initialized
INFO - 2023-07-11 12:16:19 --> Router Class Initialized
INFO - 2023-07-11 12:16:19 --> Output Class Initialized
INFO - 2023-07-11 12:16:19 --> Security Class Initialized
INFO - 2023-07-11 12:16:19 --> Config Class Initialized
INFO - 2023-07-11 12:16:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:16:19 --> Input Class Initialized
INFO - 2023-07-11 12:16:19 --> Language Class Initialized
ERROR - 2023-07-11 12:16:19 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 12:16:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:16:19 --> Utf8 Class Initialized
INFO - 2023-07-11 12:16:19 --> URI Class Initialized
INFO - 2023-07-11 12:16:19 --> Router Class Initialized
INFO - 2023-07-11 12:16:19 --> Output Class Initialized
INFO - 2023-07-11 12:16:19 --> Security Class Initialized
DEBUG - 2023-07-11 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:16:19 --> Input Class Initialized
INFO - 2023-07-11 12:16:19 --> Language Class Initialized
ERROR - 2023-07-11 12:16:19 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 12:16:19 --> Config Class Initialized
INFO - 2023-07-11 12:16:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:16:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:16:19 --> Utf8 Class Initialized
INFO - 2023-07-11 12:16:19 --> URI Class Initialized
INFO - 2023-07-11 12:16:19 --> Router Class Initialized
INFO - 2023-07-11 12:16:19 --> Output Class Initialized
INFO - 2023-07-11 12:16:19 --> Security Class Initialized
DEBUG - 2023-07-11 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:16:19 --> Input Class Initialized
INFO - 2023-07-11 12:16:19 --> Language Class Initialized
ERROR - 2023-07-11 12:16:19 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 12:20:41 --> Config Class Initialized
INFO - 2023-07-11 12:20:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:20:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:20:41 --> Utf8 Class Initialized
INFO - 2023-07-11 12:20:41 --> URI Class Initialized
INFO - 2023-07-11 12:20:41 --> Router Class Initialized
INFO - 2023-07-11 12:20:41 --> Output Class Initialized
INFO - 2023-07-11 12:20:41 --> Security Class Initialized
DEBUG - 2023-07-11 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:20:41 --> Input Class Initialized
INFO - 2023-07-11 12:20:41 --> Language Class Initialized
INFO - 2023-07-11 12:20:41 --> Loader Class Initialized
INFO - 2023-07-11 12:20:41 --> Helper loaded: url_helper
INFO - 2023-07-11 12:20:41 --> Database Driver Class Initialized
INFO - 2023-07-11 12:20:41 --> Controller Class Initialized
INFO - 2023-07-11 12:20:41 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 12:20:41 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 12:20:41 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 12:20:41 --> Final output sent to browser
DEBUG - 2023-07-11 12:20:41 --> Total execution time: 0.6313
INFO - 2023-07-11 12:20:41 --> Config Class Initialized
INFO - 2023-07-11 12:20:41 --> Config Class Initialized
INFO - 2023-07-11 12:20:41 --> Hooks Class Initialized
INFO - 2023-07-11 12:20:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:20:42 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 12:20:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:20:42 --> Utf8 Class Initialized
INFO - 2023-07-11 12:20:42 --> Utf8 Class Initialized
INFO - 2023-07-11 12:20:42 --> URI Class Initialized
INFO - 2023-07-11 12:20:42 --> URI Class Initialized
INFO - 2023-07-11 12:20:42 --> Router Class Initialized
INFO - 2023-07-11 12:20:42 --> Output Class Initialized
INFO - 2023-07-11 12:20:42 --> Router Class Initialized
INFO - 2023-07-11 12:20:42 --> Security Class Initialized
INFO - 2023-07-11 12:20:42 --> Output Class Initialized
INFO - 2023-07-11 12:20:42 --> Security Class Initialized
DEBUG - 2023-07-11 12:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:20:42 --> Input Class Initialized
DEBUG - 2023-07-11 12:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:20:42 --> Input Class Initialized
INFO - 2023-07-11 12:20:42 --> Language Class Initialized
ERROR - 2023-07-11 12:20:42 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 12:20:42 --> Language Class Initialized
ERROR - 2023-07-11 12:20:42 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 12:20:42 --> Config Class Initialized
INFO - 2023-07-11 12:20:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:20:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:20:42 --> Utf8 Class Initialized
INFO - 2023-07-11 12:20:42 --> URI Class Initialized
INFO - 2023-07-11 12:20:42 --> Router Class Initialized
INFO - 2023-07-11 12:20:43 --> Output Class Initialized
INFO - 2023-07-11 12:20:43 --> Security Class Initialized
DEBUG - 2023-07-11 12:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:20:43 --> Input Class Initialized
INFO - 2023-07-11 12:20:43 --> Language Class Initialized
ERROR - 2023-07-11 12:20:43 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 12:20:56 --> Config Class Initialized
INFO - 2023-07-11 12:20:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:20:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:20:56 --> Utf8 Class Initialized
INFO - 2023-07-11 12:20:56 --> URI Class Initialized
INFO - 2023-07-11 12:20:56 --> Router Class Initialized
INFO - 2023-07-11 12:20:56 --> Output Class Initialized
INFO - 2023-07-11 12:20:56 --> Security Class Initialized
DEBUG - 2023-07-11 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:20:56 --> Input Class Initialized
INFO - 2023-07-11 12:20:56 --> Language Class Initialized
INFO - 2023-07-11 12:20:56 --> Loader Class Initialized
INFO - 2023-07-11 12:20:56 --> Helper loaded: url_helper
INFO - 2023-07-11 12:20:56 --> Database Driver Class Initialized
INFO - 2023-07-11 12:20:56 --> Controller Class Initialized
INFO - 2023-07-11 12:20:56 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 12:20:56 --> Final output sent to browser
DEBUG - 2023-07-11 12:20:56 --> Total execution time: 0.0534
INFO - 2023-07-11 12:20:56 --> Config Class Initialized
INFO - 2023-07-11 12:20:56 --> Hooks Class Initialized
DEBUG - 2023-07-11 12:20:56 --> UTF-8 Support Enabled
INFO - 2023-07-11 12:20:56 --> Utf8 Class Initialized
INFO - 2023-07-11 12:20:56 --> URI Class Initialized
INFO - 2023-07-11 12:20:56 --> Router Class Initialized
INFO - 2023-07-11 12:20:56 --> Output Class Initialized
INFO - 2023-07-11 12:20:56 --> Security Class Initialized
DEBUG - 2023-07-11 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 12:20:56 --> Input Class Initialized
INFO - 2023-07-11 12:20:56 --> Language Class Initialized
ERROR - 2023-07-11 12:20:56 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 13:08:40 --> Config Class Initialized
INFO - 2023-07-11 13:08:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:08:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:08:40 --> Utf8 Class Initialized
INFO - 2023-07-11 13:08:40 --> URI Class Initialized
INFO - 2023-07-11 13:08:40 --> Router Class Initialized
INFO - 2023-07-11 13:08:40 --> Output Class Initialized
INFO - 2023-07-11 13:08:40 --> Security Class Initialized
DEBUG - 2023-07-11 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:08:40 --> Input Class Initialized
INFO - 2023-07-11 13:08:40 --> Language Class Initialized
INFO - 2023-07-11 13:08:40 --> Loader Class Initialized
INFO - 2023-07-11 13:08:40 --> Helper loaded: url_helper
INFO - 2023-07-11 13:08:40 --> Database Driver Class Initialized
INFO - 2023-07-11 13:08:40 --> Controller Class Initialized
INFO - 2023-07-11 13:08:40 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 13:08:40 --> Final output sent to browser
DEBUG - 2023-07-11 13:08:40 --> Total execution time: 0.3705
INFO - 2023-07-11 13:08:40 --> Config Class Initialized
INFO - 2023-07-11 13:08:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:08:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:08:40 --> Utf8 Class Initialized
INFO - 2023-07-11 13:08:40 --> URI Class Initialized
INFO - 2023-07-11 13:08:40 --> Router Class Initialized
INFO - 2023-07-11 13:08:40 --> Output Class Initialized
INFO - 2023-07-11 13:08:40 --> Security Class Initialized
DEBUG - 2023-07-11 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:08:40 --> Input Class Initialized
INFO - 2023-07-11 13:08:40 --> Language Class Initialized
ERROR - 2023-07-11 13:08:40 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 13:08:48 --> Config Class Initialized
INFO - 2023-07-11 13:08:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:08:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:08:48 --> Utf8 Class Initialized
INFO - 2023-07-11 13:08:48 --> URI Class Initialized
INFO - 2023-07-11 13:08:48 --> Router Class Initialized
INFO - 2023-07-11 13:08:48 --> Output Class Initialized
INFO - 2023-07-11 13:08:48 --> Security Class Initialized
DEBUG - 2023-07-11 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:08:48 --> Input Class Initialized
INFO - 2023-07-11 13:08:48 --> Language Class Initialized
INFO - 2023-07-11 13:08:48 --> Loader Class Initialized
INFO - 2023-07-11 13:08:48 --> Helper loaded: url_helper
INFO - 2023-07-11 13:08:48 --> Database Driver Class Initialized
INFO - 2023-07-11 13:08:48 --> Controller Class Initialized
ERROR - 2023-07-11 13:08:48 --> Severity: Notice --> Undefined property: registerctr::$session C:\xampp\htdocs\code\application\controllers\registerctr.php 41
ERROR - 2023-07-11 13:08:48 --> Severity: error --> Exception: Call to a member function set_userdata() on null C:\xampp\htdocs\code\application\controllers\registerctr.php 41
INFO - 2023-07-11 13:09:07 --> Config Class Initialized
INFO - 2023-07-11 13:09:07 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:09:07 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:09:07 --> Utf8 Class Initialized
INFO - 2023-07-11 13:09:07 --> URI Class Initialized
INFO - 2023-07-11 13:09:07 --> Router Class Initialized
INFO - 2023-07-11 13:09:07 --> Output Class Initialized
INFO - 2023-07-11 13:09:07 --> Security Class Initialized
DEBUG - 2023-07-11 13:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:09:07 --> Input Class Initialized
INFO - 2023-07-11 13:09:07 --> Language Class Initialized
INFO - 2023-07-11 13:09:08 --> Loader Class Initialized
INFO - 2023-07-11 13:09:08 --> Helper loaded: url_helper
INFO - 2023-07-11 13:09:08 --> Database Driver Class Initialized
INFO - 2023-07-11 13:09:08 --> Controller Class Initialized
INFO - 2023-07-11 13:09:08 --> Config Class Initialized
INFO - 2023-07-11 13:09:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:09:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:09:08 --> Utf8 Class Initialized
INFO - 2023-07-11 13:09:08 --> URI Class Initialized
INFO - 2023-07-11 13:09:08 --> Router Class Initialized
INFO - 2023-07-11 13:09:08 --> Output Class Initialized
INFO - 2023-07-11 13:09:08 --> Security Class Initialized
DEBUG - 2023-07-11 13:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:09:08 --> Input Class Initialized
INFO - 2023-07-11 13:09:08 --> Language Class Initialized
INFO - 2023-07-11 13:09:08 --> Loader Class Initialized
INFO - 2023-07-11 13:09:08 --> Helper loaded: url_helper
INFO - 2023-07-11 13:09:08 --> Database Driver Class Initialized
INFO - 2023-07-11 13:09:08 --> Controller Class Initialized
INFO - 2023-07-11 13:09:08 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 13:09:08 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 13:09:08 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 13:09:08 --> Final output sent to browser
DEBUG - 2023-07-11 13:09:08 --> Total execution time: 0.0917
INFO - 2023-07-11 13:09:08 --> Config Class Initialized
INFO - 2023-07-11 13:09:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:09:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:09:08 --> Utf8 Class Initialized
INFO - 2023-07-11 13:09:08 --> URI Class Initialized
INFO - 2023-07-11 13:09:08 --> Router Class Initialized
INFO - 2023-07-11 13:09:08 --> Output Class Initialized
INFO - 2023-07-11 13:09:08 --> Security Class Initialized
DEBUG - 2023-07-11 13:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:09:08 --> Input Class Initialized
INFO - 2023-07-11 13:09:08 --> Language Class Initialized
ERROR - 2023-07-11 13:09:08 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 13:09:08 --> Config Class Initialized
INFO - 2023-07-11 13:09:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:09:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:09:08 --> Utf8 Class Initialized
INFO - 2023-07-11 13:09:08 --> URI Class Initialized
INFO - 2023-07-11 13:09:08 --> Router Class Initialized
INFO - 2023-07-11 13:09:08 --> Output Class Initialized
INFO - 2023-07-11 13:09:08 --> Security Class Initialized
DEBUG - 2023-07-11 13:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:09:08 --> Input Class Initialized
INFO - 2023-07-11 13:09:08 --> Language Class Initialized
ERROR - 2023-07-11 13:09:08 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 13:09:08 --> Config Class Initialized
INFO - 2023-07-11 13:09:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:09:08 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:09:08 --> Utf8 Class Initialized
INFO - 2023-07-11 13:09:08 --> URI Class Initialized
INFO - 2023-07-11 13:09:08 --> Router Class Initialized
INFO - 2023-07-11 13:09:08 --> Output Class Initialized
INFO - 2023-07-11 13:09:08 --> Security Class Initialized
DEBUG - 2023-07-11 13:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:09:08 --> Input Class Initialized
INFO - 2023-07-11 13:09:08 --> Language Class Initialized
ERROR - 2023-07-11 13:09:08 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 13:53:08 --> Config Class Initialized
INFO - 2023-07-11 13:53:08 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:09 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:09 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:09 --> URI Class Initialized
INFO - 2023-07-11 13:53:09 --> Router Class Initialized
INFO - 2023-07-11 13:53:09 --> Output Class Initialized
INFO - 2023-07-11 13:53:09 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:09 --> Input Class Initialized
INFO - 2023-07-11 13:53:09 --> Language Class Initialized
ERROR - 2023-07-11 13:53:09 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 13:53:11 --> Config Class Initialized
INFO - 2023-07-11 13:53:11 --> Config Class Initialized
INFO - 2023-07-11 13:53:11 --> Hooks Class Initialized
INFO - 2023-07-11 13:53:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:11 --> Utf8 Class Initialized
DEBUG - 2023-07-11 13:53:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:11 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:11 --> URI Class Initialized
INFO - 2023-07-11 13:53:11 --> URI Class Initialized
INFO - 2023-07-11 13:53:11 --> Router Class Initialized
INFO - 2023-07-11 13:53:11 --> Router Class Initialized
INFO - 2023-07-11 13:53:11 --> Output Class Initialized
INFO - 2023-07-11 13:53:11 --> Output Class Initialized
INFO - 2023-07-11 13:53:11 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:11 --> Input Class Initialized
INFO - 2023-07-11 13:53:11 --> Security Class Initialized
INFO - 2023-07-11 13:53:11 --> Language Class Initialized
DEBUG - 2023-07-11 13:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:11 --> Input Class Initialized
ERROR - 2023-07-11 13:53:11 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 13:53:11 --> Language Class Initialized
ERROR - 2023-07-11 13:53:11 --> 404 Page Not Found: Indexjs/index
INFO - 2023-07-11 13:53:12 --> Config Class Initialized
INFO - 2023-07-11 13:53:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:12 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:12 --> URI Class Initialized
INFO - 2023-07-11 13:53:12 --> Router Class Initialized
INFO - 2023-07-11 13:53:12 --> Output Class Initialized
INFO - 2023-07-11 13:53:12 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:12 --> Input Class Initialized
INFO - 2023-07-11 13:53:12 --> Language Class Initialized
ERROR - 2023-07-11 13:53:12 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 13:53:12 --> Config Class Initialized
INFO - 2023-07-11 13:53:12 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:12 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:12 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:12 --> URI Class Initialized
INFO - 2023-07-11 13:53:12 --> Router Class Initialized
INFO - 2023-07-11 13:53:12 --> Output Class Initialized
INFO - 2023-07-11 13:53:12 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:12 --> Input Class Initialized
INFO - 2023-07-11 13:53:12 --> Language Class Initialized
INFO - 2023-07-11 13:53:13 --> Loader Class Initialized
INFO - 2023-07-11 13:53:13 --> Helper loaded: url_helper
INFO - 2023-07-11 13:53:13 --> Database Driver Class Initialized
DEBUG - 2023-07-11 13:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 13:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 13:53:14 --> Controller Class Initialized
INFO - 2023-07-11 13:53:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 13:53:14 --> File loaded: C:\xampp\htdocs\code\application\views\userList.php
INFO - 2023-07-11 13:53:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 13:53:14 --> Final output sent to browser
DEBUG - 2023-07-11 13:53:14 --> Total execution time: 1.8824
INFO - 2023-07-11 13:53:14 --> Config Class Initialized
INFO - 2023-07-11 13:53:14 --> Config Class Initialized
INFO - 2023-07-11 13:53:14 --> Hooks Class Initialized
INFO - 2023-07-11 13:53:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2023-07-11 13:53:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:14 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:14 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:14 --> URI Class Initialized
INFO - 2023-07-11 13:53:14 --> URI Class Initialized
INFO - 2023-07-11 13:53:14 --> Router Class Initialized
INFO - 2023-07-11 13:53:14 --> Router Class Initialized
INFO - 2023-07-11 13:53:14 --> Output Class Initialized
INFO - 2023-07-11 13:53:14 --> Output Class Initialized
INFO - 2023-07-11 13:53:14 --> Security Class Initialized
INFO - 2023-07-11 13:53:14 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-07-11 13:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:14 --> Input Class Initialized
INFO - 2023-07-11 13:53:14 --> Input Class Initialized
INFO - 2023-07-11 13:53:14 --> Language Class Initialized
INFO - 2023-07-11 13:53:14 --> Language Class Initialized
ERROR - 2023-07-11 13:53:14 --> 404 Page Not Found: Assest/fonts
ERROR - 2023-07-11 13:53:14 --> 404 Page Not Found: Indexcss/index
INFO - 2023-07-11 13:53:15 --> Config Class Initialized
INFO - 2023-07-11 13:53:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:15 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:15 --> URI Class Initialized
INFO - 2023-07-11 13:53:15 --> Router Class Initialized
INFO - 2023-07-11 13:53:15 --> Output Class Initialized
INFO - 2023-07-11 13:53:15 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:15 --> Input Class Initialized
INFO - 2023-07-11 13:53:15 --> Language Class Initialized
ERROR - 2023-07-11 13:53:15 --> 404 Page Not Found: Assest/font
INFO - 2023-07-11 13:53:16 --> Config Class Initialized
INFO - 2023-07-11 13:53:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:16 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:16 --> URI Class Initialized
INFO - 2023-07-11 13:53:16 --> Router Class Initialized
INFO - 2023-07-11 13:53:16 --> Output Class Initialized
INFO - 2023-07-11 13:53:16 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:16 --> Input Class Initialized
INFO - 2023-07-11 13:53:16 --> Language Class Initialized
INFO - 2023-07-11 13:53:16 --> Loader Class Initialized
INFO - 2023-07-11 13:53:16 --> Helper loaded: url_helper
INFO - 2023-07-11 13:53:16 --> Database Driver Class Initialized
DEBUG - 2023-07-11 13:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 13:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 13:53:16 --> Controller Class Initialized
INFO - 2023-07-11 13:53:16 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 13:53:16 --> Final output sent to browser
DEBUG - 2023-07-11 13:53:16 --> Total execution time: 0.0861
INFO - 2023-07-11 13:53:16 --> Config Class Initialized
INFO - 2023-07-11 13:53:16 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:53:16 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:53:16 --> Utf8 Class Initialized
INFO - 2023-07-11 13:53:16 --> URI Class Initialized
INFO - 2023-07-11 13:53:16 --> Router Class Initialized
INFO - 2023-07-11 13:53:16 --> Output Class Initialized
INFO - 2023-07-11 13:53:16 --> Security Class Initialized
DEBUG - 2023-07-11 13:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:53:16 --> Input Class Initialized
INFO - 2023-07-11 13:53:16 --> Language Class Initialized
ERROR - 2023-07-11 13:53:16 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 13:54:48 --> Config Class Initialized
INFO - 2023-07-11 13:54:48 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:54:48 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:54:48 --> Utf8 Class Initialized
INFO - 2023-07-11 13:54:48 --> URI Class Initialized
INFO - 2023-07-11 13:54:48 --> Router Class Initialized
INFO - 2023-07-11 13:54:48 --> Output Class Initialized
INFO - 2023-07-11 13:54:48 --> Security Class Initialized
DEBUG - 2023-07-11 13:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:54:48 --> Input Class Initialized
INFO - 2023-07-11 13:54:48 --> Language Class Initialized
INFO - 2023-07-11 13:54:48 --> Loader Class Initialized
INFO - 2023-07-11 13:54:48 --> Helper loaded: url_helper
INFO - 2023-07-11 13:54:48 --> Database Driver Class Initialized
DEBUG - 2023-07-11 13:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 13:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 13:54:48 --> Controller Class Initialized
INFO - 2023-07-11 13:54:48 --> Helper loaded: form_helper
INFO - 2023-07-11 13:54:48 --> Form Validation Class Initialized
INFO - 2023-07-11 13:55:39 --> Config Class Initialized
INFO - 2023-07-11 13:55:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:55:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:55:39 --> Utf8 Class Initialized
INFO - 2023-07-11 13:55:39 --> URI Class Initialized
INFO - 2023-07-11 13:55:39 --> Router Class Initialized
INFO - 2023-07-11 13:55:39 --> Output Class Initialized
INFO - 2023-07-11 13:55:39 --> Security Class Initialized
DEBUG - 2023-07-11 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:55:39 --> Input Class Initialized
INFO - 2023-07-11 13:55:39 --> Language Class Initialized
INFO - 2023-07-11 13:55:39 --> Loader Class Initialized
INFO - 2023-07-11 13:55:39 --> Helper loaded: url_helper
INFO - 2023-07-11 13:55:39 --> Database Driver Class Initialized
DEBUG - 2023-07-11 13:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 13:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 13:55:39 --> Controller Class Initialized
INFO - 2023-07-11 13:55:39 --> File loaded: C:\xampp\htdocs\code\application\views\login.php
INFO - 2023-07-11 13:55:39 --> Final output sent to browser
DEBUG - 2023-07-11 13:55:39 --> Total execution time: 0.1620
INFO - 2023-07-11 13:55:39 --> Config Class Initialized
INFO - 2023-07-11 13:55:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:55:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:55:39 --> Utf8 Class Initialized
INFO - 2023-07-11 13:55:39 --> URI Class Initialized
INFO - 2023-07-11 13:55:39 --> Router Class Initialized
INFO - 2023-07-11 13:55:39 --> Output Class Initialized
INFO - 2023-07-11 13:55:39 --> Security Class Initialized
DEBUG - 2023-07-11 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:55:39 --> Input Class Initialized
INFO - 2023-07-11 13:55:39 --> Language Class Initialized
ERROR - 2023-07-11 13:55:39 --> 404 Page Not Found: Stylecss/index
INFO - 2023-07-11 13:56:14 --> Config Class Initialized
INFO - 2023-07-11 13:56:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:56:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:56:14 --> Utf8 Class Initialized
INFO - 2023-07-11 13:56:14 --> URI Class Initialized
INFO - 2023-07-11 13:56:14 --> Router Class Initialized
INFO - 2023-07-11 13:56:14 --> Output Class Initialized
INFO - 2023-07-11 13:56:14 --> Security Class Initialized
DEBUG - 2023-07-11 13:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:56:14 --> Input Class Initialized
INFO - 2023-07-11 13:56:14 --> Language Class Initialized
INFO - 2023-07-11 13:56:14 --> Loader Class Initialized
INFO - 2023-07-11 13:56:14 --> Helper loaded: url_helper
INFO - 2023-07-11 13:56:14 --> Database Driver Class Initialized
DEBUG - 2023-07-11 13:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 13:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 13:56:14 --> Controller Class Initialized
INFO - 2023-07-11 13:56:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/header.php
INFO - 2023-07-11 13:56:14 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-11 13:56:14 --> File loaded: C:\xampp\htdocs\code\application\views\/templates/footer.php
INFO - 2023-07-11 13:56:14 --> Final output sent to browser
DEBUG - 2023-07-11 13:56:14 --> Total execution time: 0.0686
INFO - 2023-07-11 13:56:14 --> Config Class Initialized
INFO - 2023-07-11 13:56:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:56:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:56:14 --> Utf8 Class Initialized
INFO - 2023-07-11 13:56:14 --> URI Class Initialized
INFO - 2023-07-11 13:56:14 --> Router Class Initialized
INFO - 2023-07-11 13:56:14 --> Output Class Initialized
INFO - 2023-07-11 13:56:14 --> Security Class Initialized
INFO - 2023-07-11 13:56:14 --> Config Class Initialized
INFO - 2023-07-11 13:56:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:56:14 --> Input Class Initialized
INFO - 2023-07-11 13:56:14 --> Language Class Initialized
ERROR - 2023-07-11 13:56:14 --> 404 Page Not Found: Indexcss/index
DEBUG - 2023-07-11 13:56:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:56:14 --> Utf8 Class Initialized
INFO - 2023-07-11 13:56:15 --> URI Class Initialized
INFO - 2023-07-11 13:56:15 --> Router Class Initialized
INFO - 2023-07-11 13:56:15 --> Output Class Initialized
INFO - 2023-07-11 13:56:15 --> Security Class Initialized
DEBUG - 2023-07-11 13:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:56:15 --> Input Class Initialized
INFO - 2023-07-11 13:56:15 --> Language Class Initialized
ERROR - 2023-07-11 13:56:15 --> 404 Page Not Found: Assest/fonts
INFO - 2023-07-11 13:56:15 --> Config Class Initialized
INFO - 2023-07-11 13:56:15 --> Hooks Class Initialized
DEBUG - 2023-07-11 13:56:15 --> UTF-8 Support Enabled
INFO - 2023-07-11 13:56:15 --> Utf8 Class Initialized
INFO - 2023-07-11 13:56:15 --> URI Class Initialized
INFO - 2023-07-11 13:56:15 --> Router Class Initialized
INFO - 2023-07-11 13:56:15 --> Output Class Initialized
INFO - 2023-07-11 13:56:15 --> Security Class Initialized
DEBUG - 2023-07-11 13:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 13:56:15 --> Input Class Initialized
INFO - 2023-07-11 13:56:15 --> Language Class Initialized
ERROR - 2023-07-11 13:56:15 --> 404 Page Not Found: Assest/font
