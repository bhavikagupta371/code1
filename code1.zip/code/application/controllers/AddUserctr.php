<?php
class AddUserctr extends CI_Controller {

	public function index()
	{

		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			
			$postDatas = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password'),
				'current_address' => $this->input->post('current_address'),
				'permanent_address' => $this->input->post('permanent_address'),
				'linkdin' => $this->input->post('linkdin'),
				'git' => $this->input->post('git'),
				'facebook' => $this->input->post('facebook'),
				'company' => $this->input->post('company'),
				'department' => $this->input->post('department'),
				'years' => $this->input->post('years'),
				'phone' => $this->input->post('phone'),
				'whatsapp' => $this->input->post('whatsapp'),
				'about' => $this->input->post('about'),

			);
             
		 	$isInserted = $this->db->insert('employee', $postDatas);
			if($isInserted !=false){
				echo 'Record added successfully.';
			}else{
				echo 'Error!!! Try again.';
			}
			redirect('/Userlist');

		}else{
			$this->load->view('/templates/header');
			$this->load->view('/addUser');
			$this->load->view('/templates/footer');
		}
	}


	// $this->load->view('templates/header', $data);
}


// public function index()
// 	{

// 		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			
// 			$postDatas = array(
// 				'name' => $this->input->post('name'),
// 				'email' => $this->input->post('email'),
// 				'password' => $this->input->post('password'),
// 				'current_address' => $this->input->post('current_address'),
// 				'permanent_address' => $this->input->post('permanent_address'),
// 				'linkdin' => $this->input->post('linkdin'),
// 				'git' => $this->input->post('git'),
// 				'facebook' => $this->input->post('facebook'),
// 				'company' => $this->input->post('company'),
// 				'department' => $this->input->post('department'),
// 				'years' => $this->input->post('years'),
// 				'phone' => $this->input->post('phone'),
// 				'whatsapp' => $this->input->post('whatsapp'),
// 				'about' => $this->input->post('about'),

// 			);
             
// 		 	$isInserted = $this->db->insert('employee', $postDatas);
// 			if($isInserted !=false){
// 				echo 'Record added successfully.';
// 			}else{
// 				echo 'Error!!! Try again.';
// 			}
// 			redirect('/Student/listing');

// 		}else{
// 			$this->load->view('/templates/header');
// 			$this->load->view('/Student/add');
// 			$this->load->view('/templates/footer');
// 		}
// 	}

