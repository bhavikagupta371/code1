
        <!-- <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-
            scale=1">

        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

        <title>CRUD FROM API</title>

        <link href="index.css" rel="stylesheet">
    </head>
    <body>

    <nav class="navbar navbar-dark bg-mynav">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">User List</a>
        </div>
        </nav> -->
    <div class=hight></div>
    <div class="container">
        <div class="d-flex bd-highlight mb-3">
            <div class="me-auto p-2 bd-highlight"><h2>Employee</div>
            <div class="p-2 bd-highlight">
            </div>
        </div>
    <div class="table-responsive">
        <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Phone No</th>
            <th scope="col">Linkdin</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody id="mytable">
        <?php 
foreach ($tableDatas as $key => $data) {
   ?>
    <tr>
    <td><?php echo $data['id'];?></td>
        <td><?php echo $data['name'];?></td>
        <td><?php echo $data['email'];?></td>
        <td><?php echo $data['phone'];?></td>
        <td><?php echo $data['linkdin'];?></td>
        <td><a href="<?php echo  base_url();?>UserListctr/edit/<?php echo $data['id']?>">Update</a></td>

       <td> <form method="post" action="<?php echo  base_url();?>UserListctr/delete/<?php echo $data['id']?>">
  <input type="hidden" name="id" value="<?php echo $data['id']?>" /> 
  <a onclick="this.parentNode.submit();">Delete</a>
</form></td>
      </tr>
   <?php
}
 ?>
         </tbody>
       </table>
     </div>
    </div>

    <!-- <script src="index.js"></script>                        
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2
       @11.0.16/dist/sweetalert2.all.min.js"></script>       
    <script src="https://cdn.jsdelivr.net/npm/bootstrap
      @5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-
     gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" 
     crossorigin="anonymous"><
   /script> -->
<style>
.hight{
  margin-top:30px;
}
</style>