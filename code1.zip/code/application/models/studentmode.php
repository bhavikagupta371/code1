<?php
class studentmode extends CI_Model 
{
  /*View*/
    function listing()
  {
    $query=$this->db->get("neron");
    return $query->result();
  }
	
} 