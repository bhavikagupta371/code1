<?php
class UserListctr extends CI_Controller {

        public function index()
	// {
	// 	$this->load->view('/templates/header');
	// 	$this->load->view('userList');
	// 	$this->load->view('/templates/footer')
	// 	;
	// }
	// $this->load->view('templates/header', $data);

	{
		$this->db->select('employee.*');
		$this->db->from('employee');
		$this->db->order_by('id', 'incr');
		$data['tableDatas'] = $this->db->get()->result_array();

		 $this->load->view('/templates/header');
		 $this->load->view('userList', $data);
		 $this->load->view('/templates/footer') ;
	}

	public function edit($id=null)
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$postDatas = array(

				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password'),
				'current_address' => $this->input->post('current_address'),
				'permanent_address' => $this->input->post('permanent_address'),
				'linkdin' => $this->input->post('linkdin'),
				'git' => $this->input->post('git'),
				'facebook' => $this->input->post('facebook'),
				'company' => $this->input->post('company'),
				'department' => $this->input->post('department'),
				'years' => $this->input->post('years'),
				'phone' => $this->input->post('phone'),
				'whatsapp' => $this->input->post('whatsapp'),
				'about' => $this->input->post('about'),

			);

			$this->db->where('id', $id);
			$this->db->update('employee', $postDatas);
			$isInserted = $this->db->affected_rows();
			if($isInserted !=false){
				echo 'Record updated successfully.';
			}else{
				echo 'Error!!! Try again.';
			}
			redirect('Userlist');
		}else{

			$this->db->select('employee.*');
			$this->db->from('employee');
			$this->db->where('id', $id);
			$data['tableData'] = $this->db->get()->row();

			$data['rowId'] =$id;

			$this->load->view('/templates/header');
			$this->load->view('editPage', $data);
			$this->load->view('/templates/footer') ;
		}
		
	}

	public function delete($id=null)
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$this->db->where('id', $id);
			$this->db->delete('employee');
			$isInserted = $this->db->affected_rows();
			if($isInserted !=false){
				echo 'Record updated successfully.';
			}else{
				echo 'Error!!! Try again.';
			}
			redirect('Userlist');
		}
		
	}

}

