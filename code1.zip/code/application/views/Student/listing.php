<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<h3>Student Lists</h3>


<table class="table">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>

    <?php 
foreach ($tableDatas as $key => $data) {
   ?>
    <tr>
        <td><?php echo $data['name'];?></td>
        <td><?php echo $data['email'];?></td>
        <td><?php echo $data['address'];?></td>
        <td><a href="<?php echo  base_url();?>student/edit/<?php echo $data['id']?>">Update</a></td>
        <!-- <td><a href="<?php echo  base_url();?>student/delete/<?php echo $data['id']?>">delete</a></td> -->


       <td> <form method="post" action="<?php echo  base_url();?>student/delete/<?php echo $data['id']?>">
  <input type="hidden" name="id" value="<?php echo $data['id']?>" /> 
  <a onclick="this.parentNode.submit();">Delete</a>
</form></td>
      </tr>
   <?php
}
 ?>
      
    
    </tbody>
  </table>
</body>
</html>
