<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-07 14:32:13 --> Config Class Initialized
INFO - 2023-07-07 14:32:13 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:32:13 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:32:13 --> Utf8 Class Initialized
INFO - 2023-07-07 14:32:13 --> URI Class Initialized
INFO - 2023-07-07 14:32:13 --> Router Class Initialized
INFO - 2023-07-07 14:32:13 --> Output Class Initialized
INFO - 2023-07-07 14:32:13 --> Security Class Initialized
DEBUG - 2023-07-07 14:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:32:13 --> Input Class Initialized
INFO - 2023-07-07 14:32:13 --> Language Class Initialized
INFO - 2023-07-07 14:32:13 --> Loader Class Initialized
INFO - 2023-07-07 14:32:13 --> Controller Class Initialized
INFO - 2023-07-07 14:32:13 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:32:13 --> Final output sent to browser
DEBUG - 2023-07-07 14:32:13 --> Total execution time: 0.2960
INFO - 2023-07-07 14:43:33 --> Config Class Initialized
INFO - 2023-07-07 14:43:33 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:43:33 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:43:33 --> Utf8 Class Initialized
INFO - 2023-07-07 14:43:33 --> URI Class Initialized
INFO - 2023-07-07 14:43:33 --> Router Class Initialized
INFO - 2023-07-07 14:43:33 --> Output Class Initialized
INFO - 2023-07-07 14:43:33 --> Security Class Initialized
DEBUG - 2023-07-07 14:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:43:33 --> Input Class Initialized
INFO - 2023-07-07 14:43:33 --> Language Class Initialized
INFO - 2023-07-07 14:43:33 --> Loader Class Initialized
INFO - 2023-07-07 14:43:33 --> Controller Class Initialized
INFO - 2023-07-07 14:43:33 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:43:33 --> Final output sent to browser
DEBUG - 2023-07-07 14:43:33 --> Total execution time: 0.0368
INFO - 2023-07-07 14:45:07 --> Config Class Initialized
INFO - 2023-07-07 14:45:07 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:45:07 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:45:07 --> Utf8 Class Initialized
INFO - 2023-07-07 14:45:07 --> URI Class Initialized
INFO - 2023-07-07 14:45:07 --> Router Class Initialized
INFO - 2023-07-07 14:45:07 --> Output Class Initialized
INFO - 2023-07-07 14:45:07 --> Security Class Initialized
DEBUG - 2023-07-07 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:45:07 --> Input Class Initialized
INFO - 2023-07-07 14:45:07 --> Language Class Initialized
INFO - 2023-07-07 14:45:07 --> Loader Class Initialized
INFO - 2023-07-07 14:45:07 --> Controller Class Initialized
INFO - 2023-07-07 14:45:07 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:45:07 --> Final output sent to browser
DEBUG - 2023-07-07 14:45:07 --> Total execution time: 0.0405
INFO - 2023-07-07 14:46:21 --> Config Class Initialized
INFO - 2023-07-07 14:46:21 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:46:21 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:46:21 --> Utf8 Class Initialized
INFO - 2023-07-07 14:46:21 --> URI Class Initialized
INFO - 2023-07-07 14:46:21 --> Router Class Initialized
INFO - 2023-07-07 14:46:21 --> Output Class Initialized
INFO - 2023-07-07 14:46:21 --> Security Class Initialized
DEBUG - 2023-07-07 14:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:46:21 --> Input Class Initialized
INFO - 2023-07-07 14:46:21 --> Language Class Initialized
INFO - 2023-07-07 14:46:21 --> Loader Class Initialized
INFO - 2023-07-07 14:46:21 --> Controller Class Initialized
INFO - 2023-07-07 14:46:21 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:46:21 --> Final output sent to browser
DEBUG - 2023-07-07 14:46:21 --> Total execution time: 0.0391
INFO - 2023-07-07 14:46:54 --> Config Class Initialized
INFO - 2023-07-07 14:46:54 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:46:54 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:46:54 --> Utf8 Class Initialized
INFO - 2023-07-07 14:46:54 --> URI Class Initialized
INFO - 2023-07-07 14:46:54 --> Router Class Initialized
INFO - 2023-07-07 14:46:54 --> Output Class Initialized
INFO - 2023-07-07 14:46:54 --> Security Class Initialized
DEBUG - 2023-07-07 14:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:46:54 --> Input Class Initialized
INFO - 2023-07-07 14:46:54 --> Language Class Initialized
INFO - 2023-07-07 14:46:54 --> Loader Class Initialized
INFO - 2023-07-07 14:46:54 --> Controller Class Initialized
INFO - 2023-07-07 14:46:54 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:46:54 --> Final output sent to browser
DEBUG - 2023-07-07 14:46:54 --> Total execution time: 0.0347
INFO - 2023-07-07 14:50:24 --> Config Class Initialized
INFO - 2023-07-07 14:50:24 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:24 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:24 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:24 --> URI Class Initialized
INFO - 2023-07-07 14:50:24 --> Router Class Initialized
INFO - 2023-07-07 14:50:24 --> Output Class Initialized
INFO - 2023-07-07 14:50:24 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:24 --> Input Class Initialized
INFO - 2023-07-07 14:50:24 --> Language Class Initialized
INFO - 2023-07-07 14:50:24 --> Loader Class Initialized
INFO - 2023-07-07 14:50:24 --> Controller Class Initialized
INFO - 2023-07-07 14:50:24 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:24 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:24 --> Total execution time: 0.0387
INFO - 2023-07-07 14:50:24 --> Config Class Initialized
INFO - 2023-07-07 14:50:24 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:24 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:24 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:24 --> URI Class Initialized
INFO - 2023-07-07 14:50:24 --> Router Class Initialized
INFO - 2023-07-07 14:50:24 --> Output Class Initialized
INFO - 2023-07-07 14:50:24 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:24 --> Input Class Initialized
INFO - 2023-07-07 14:50:24 --> Language Class Initialized
INFO - 2023-07-07 14:50:24 --> Loader Class Initialized
INFO - 2023-07-07 14:50:24 --> Controller Class Initialized
INFO - 2023-07-07 14:50:24 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:24 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:24 --> Total execution time: 0.0385
INFO - 2023-07-07 14:50:25 --> Config Class Initialized
INFO - 2023-07-07 14:50:25 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:25 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:25 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:25 --> URI Class Initialized
INFO - 2023-07-07 14:50:25 --> Router Class Initialized
INFO - 2023-07-07 14:50:25 --> Output Class Initialized
INFO - 2023-07-07 14:50:25 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:25 --> Input Class Initialized
INFO - 2023-07-07 14:50:25 --> Language Class Initialized
INFO - 2023-07-07 14:50:25 --> Loader Class Initialized
INFO - 2023-07-07 14:50:25 --> Controller Class Initialized
INFO - 2023-07-07 14:50:25 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:25 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:25 --> Total execution time: 0.0396
INFO - 2023-07-07 14:50:25 --> Config Class Initialized
INFO - 2023-07-07 14:50:25 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:25 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:25 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:25 --> URI Class Initialized
INFO - 2023-07-07 14:50:25 --> Router Class Initialized
INFO - 2023-07-07 14:50:25 --> Output Class Initialized
INFO - 2023-07-07 14:50:25 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:25 --> Input Class Initialized
INFO - 2023-07-07 14:50:25 --> Language Class Initialized
INFO - 2023-07-07 14:50:25 --> Loader Class Initialized
INFO - 2023-07-07 14:50:25 --> Controller Class Initialized
INFO - 2023-07-07 14:50:25 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:25 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:25 --> Total execution time: 0.0398
INFO - 2023-07-07 14:50:25 --> Config Class Initialized
INFO - 2023-07-07 14:50:25 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:25 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:25 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:25 --> URI Class Initialized
INFO - 2023-07-07 14:50:25 --> Router Class Initialized
INFO - 2023-07-07 14:50:25 --> Output Class Initialized
INFO - 2023-07-07 14:50:25 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:25 --> Input Class Initialized
INFO - 2023-07-07 14:50:25 --> Language Class Initialized
INFO - 2023-07-07 14:50:25 --> Loader Class Initialized
INFO - 2023-07-07 14:50:25 --> Controller Class Initialized
INFO - 2023-07-07 14:50:25 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:25 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:25 --> Total execution time: 0.0420
INFO - 2023-07-07 14:50:25 --> Config Class Initialized
INFO - 2023-07-07 14:50:25 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:25 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:25 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:25 --> URI Class Initialized
INFO - 2023-07-07 14:50:25 --> Router Class Initialized
INFO - 2023-07-07 14:50:25 --> Output Class Initialized
INFO - 2023-07-07 14:50:25 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:25 --> Input Class Initialized
INFO - 2023-07-07 14:50:25 --> Language Class Initialized
INFO - 2023-07-07 14:50:25 --> Loader Class Initialized
INFO - 2023-07-07 14:50:25 --> Controller Class Initialized
INFO - 2023-07-07 14:50:25 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:25 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:25 --> Total execution time: 0.0404
INFO - 2023-07-07 14:50:25 --> Config Class Initialized
INFO - 2023-07-07 14:50:25 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:25 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:25 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:25 --> URI Class Initialized
INFO - 2023-07-07 14:50:25 --> Router Class Initialized
INFO - 2023-07-07 14:50:25 --> Output Class Initialized
INFO - 2023-07-07 14:50:25 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:25 --> Input Class Initialized
INFO - 2023-07-07 14:50:25 --> Language Class Initialized
INFO - 2023-07-07 14:50:25 --> Loader Class Initialized
INFO - 2023-07-07 14:50:25 --> Controller Class Initialized
INFO - 2023-07-07 14:50:25 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:25 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:25 --> Total execution time: 0.0389
INFO - 2023-07-07 14:50:25 --> Config Class Initialized
INFO - 2023-07-07 14:50:25 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:25 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:25 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:25 --> URI Class Initialized
INFO - 2023-07-07 14:50:25 --> Router Class Initialized
INFO - 2023-07-07 14:50:25 --> Output Class Initialized
INFO - 2023-07-07 14:50:25 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:25 --> Input Class Initialized
INFO - 2023-07-07 14:50:25 --> Language Class Initialized
INFO - 2023-07-07 14:50:25 --> Loader Class Initialized
INFO - 2023-07-07 14:50:25 --> Controller Class Initialized
INFO - 2023-07-07 14:50:25 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:25 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:25 --> Total execution time: 0.0409
INFO - 2023-07-07 14:50:26 --> Config Class Initialized
INFO - 2023-07-07 14:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:26 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:26 --> URI Class Initialized
INFO - 2023-07-07 14:50:26 --> Router Class Initialized
INFO - 2023-07-07 14:50:26 --> Output Class Initialized
INFO - 2023-07-07 14:50:26 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:26 --> Input Class Initialized
INFO - 2023-07-07 14:50:26 --> Language Class Initialized
INFO - 2023-07-07 14:50:26 --> Loader Class Initialized
INFO - 2023-07-07 14:50:26 --> Controller Class Initialized
INFO - 2023-07-07 14:50:26 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:26 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:26 --> Total execution time: 0.0416
INFO - 2023-07-07 14:50:26 --> Config Class Initialized
INFO - 2023-07-07 14:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:26 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:26 --> URI Class Initialized
INFO - 2023-07-07 14:50:26 --> Router Class Initialized
INFO - 2023-07-07 14:50:26 --> Output Class Initialized
INFO - 2023-07-07 14:50:26 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:26 --> Input Class Initialized
INFO - 2023-07-07 14:50:26 --> Language Class Initialized
INFO - 2023-07-07 14:50:26 --> Loader Class Initialized
INFO - 2023-07-07 14:50:26 --> Controller Class Initialized
INFO - 2023-07-07 14:50:26 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:26 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:26 --> Total execution time: 0.0378
INFO - 2023-07-07 14:50:26 --> Config Class Initialized
INFO - 2023-07-07 14:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:26 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:26 --> URI Class Initialized
INFO - 2023-07-07 14:50:26 --> Router Class Initialized
INFO - 2023-07-07 14:50:26 --> Output Class Initialized
INFO - 2023-07-07 14:50:26 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:26 --> Input Class Initialized
INFO - 2023-07-07 14:50:26 --> Language Class Initialized
INFO - 2023-07-07 14:50:26 --> Loader Class Initialized
INFO - 2023-07-07 14:50:26 --> Controller Class Initialized
INFO - 2023-07-07 14:50:26 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:26 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:26 --> Total execution time: 0.0418
INFO - 2023-07-07 14:50:26 --> Config Class Initialized
INFO - 2023-07-07 14:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:26 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:26 --> URI Class Initialized
INFO - 2023-07-07 14:50:26 --> Router Class Initialized
INFO - 2023-07-07 14:50:26 --> Output Class Initialized
INFO - 2023-07-07 14:50:26 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:26 --> Input Class Initialized
INFO - 2023-07-07 14:50:26 --> Language Class Initialized
INFO - 2023-07-07 14:50:26 --> Loader Class Initialized
INFO - 2023-07-07 14:50:26 --> Controller Class Initialized
INFO - 2023-07-07 14:50:26 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:26 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:26 --> Total execution time: 0.0379
INFO - 2023-07-07 14:50:26 --> Config Class Initialized
INFO - 2023-07-07 14:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:26 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:26 --> URI Class Initialized
INFO - 2023-07-07 14:50:26 --> Router Class Initialized
INFO - 2023-07-07 14:50:26 --> Output Class Initialized
INFO - 2023-07-07 14:50:26 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:26 --> Input Class Initialized
INFO - 2023-07-07 14:50:26 --> Language Class Initialized
INFO - 2023-07-07 14:50:26 --> Loader Class Initialized
INFO - 2023-07-07 14:50:26 --> Controller Class Initialized
INFO - 2023-07-07 14:50:26 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:26 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:26 --> Total execution time: 0.0373
INFO - 2023-07-07 14:50:26 --> Config Class Initialized
INFO - 2023-07-07 14:50:26 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:26 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:26 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:26 --> URI Class Initialized
INFO - 2023-07-07 14:50:26 --> Router Class Initialized
INFO - 2023-07-07 14:50:26 --> Output Class Initialized
INFO - 2023-07-07 14:50:26 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:26 --> Input Class Initialized
INFO - 2023-07-07 14:50:26 --> Language Class Initialized
INFO - 2023-07-07 14:50:26 --> Loader Class Initialized
INFO - 2023-07-07 14:50:26 --> Controller Class Initialized
INFO - 2023-07-07 14:50:26 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:26 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:26 --> Total execution time: 0.0401
INFO - 2023-07-07 14:50:27 --> Config Class Initialized
INFO - 2023-07-07 14:50:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:27 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:27 --> URI Class Initialized
INFO - 2023-07-07 14:50:27 --> Router Class Initialized
INFO - 2023-07-07 14:50:27 --> Output Class Initialized
INFO - 2023-07-07 14:50:27 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:27 --> Input Class Initialized
INFO - 2023-07-07 14:50:27 --> Language Class Initialized
INFO - 2023-07-07 14:50:27 --> Loader Class Initialized
INFO - 2023-07-07 14:50:27 --> Controller Class Initialized
INFO - 2023-07-07 14:50:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:27 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:27 --> Total execution time: 0.0382
INFO - 2023-07-07 14:50:27 --> Config Class Initialized
INFO - 2023-07-07 14:50:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:27 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:27 --> URI Class Initialized
INFO - 2023-07-07 14:50:27 --> Router Class Initialized
INFO - 2023-07-07 14:50:27 --> Output Class Initialized
INFO - 2023-07-07 14:50:27 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:27 --> Input Class Initialized
INFO - 2023-07-07 14:50:27 --> Language Class Initialized
INFO - 2023-07-07 14:50:27 --> Loader Class Initialized
INFO - 2023-07-07 14:50:27 --> Controller Class Initialized
INFO - 2023-07-07 14:50:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:27 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:27 --> Total execution time: 0.0357
INFO - 2023-07-07 14:50:27 --> Config Class Initialized
INFO - 2023-07-07 14:50:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:27 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:27 --> URI Class Initialized
INFO - 2023-07-07 14:50:27 --> Router Class Initialized
INFO - 2023-07-07 14:50:27 --> Output Class Initialized
INFO - 2023-07-07 14:50:27 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:27 --> Input Class Initialized
INFO - 2023-07-07 14:50:27 --> Language Class Initialized
INFO - 2023-07-07 14:50:27 --> Loader Class Initialized
INFO - 2023-07-07 14:50:27 --> Controller Class Initialized
INFO - 2023-07-07 14:50:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:27 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:27 --> Total execution time: 0.0389
INFO - 2023-07-07 14:50:27 --> Config Class Initialized
INFO - 2023-07-07 14:50:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:27 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:27 --> URI Class Initialized
INFO - 2023-07-07 14:50:27 --> Router Class Initialized
INFO - 2023-07-07 14:50:27 --> Output Class Initialized
INFO - 2023-07-07 14:50:27 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:27 --> Input Class Initialized
INFO - 2023-07-07 14:50:27 --> Language Class Initialized
INFO - 2023-07-07 14:50:27 --> Loader Class Initialized
INFO - 2023-07-07 14:50:27 --> Controller Class Initialized
INFO - 2023-07-07 14:50:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:27 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:27 --> Total execution time: 0.0371
INFO - 2023-07-07 14:50:27 --> Config Class Initialized
INFO - 2023-07-07 14:50:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:27 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:27 --> URI Class Initialized
INFO - 2023-07-07 14:50:27 --> Router Class Initialized
INFO - 2023-07-07 14:50:27 --> Output Class Initialized
INFO - 2023-07-07 14:50:27 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:27 --> Input Class Initialized
INFO - 2023-07-07 14:50:27 --> Language Class Initialized
INFO - 2023-07-07 14:50:27 --> Loader Class Initialized
INFO - 2023-07-07 14:50:27 --> Controller Class Initialized
INFO - 2023-07-07 14:50:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:27 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:27 --> Total execution time: 0.0355
INFO - 2023-07-07 14:50:27 --> Config Class Initialized
INFO - 2023-07-07 14:50:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:27 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:27 --> URI Class Initialized
INFO - 2023-07-07 14:50:27 --> Router Class Initialized
INFO - 2023-07-07 14:50:27 --> Output Class Initialized
INFO - 2023-07-07 14:50:27 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:27 --> Input Class Initialized
INFO - 2023-07-07 14:50:27 --> Language Class Initialized
INFO - 2023-07-07 14:50:27 --> Loader Class Initialized
INFO - 2023-07-07 14:50:27 --> Controller Class Initialized
INFO - 2023-07-07 14:50:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:27 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:27 --> Total execution time: 0.0373
INFO - 2023-07-07 14:50:27 --> Config Class Initialized
INFO - 2023-07-07 14:50:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:50:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:50:27 --> Utf8 Class Initialized
INFO - 2023-07-07 14:50:27 --> URI Class Initialized
INFO - 2023-07-07 14:50:27 --> Router Class Initialized
INFO - 2023-07-07 14:50:27 --> Output Class Initialized
INFO - 2023-07-07 14:50:27 --> Security Class Initialized
DEBUG - 2023-07-07 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:50:27 --> Input Class Initialized
INFO - 2023-07-07 14:50:27 --> Language Class Initialized
INFO - 2023-07-07 14:50:27 --> Loader Class Initialized
INFO - 2023-07-07 14:50:27 --> Controller Class Initialized
INFO - 2023-07-07 14:50:27 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:50:27 --> Final output sent to browser
DEBUG - 2023-07-07 14:50:27 --> Total execution time: 0.0383
INFO - 2023-07-07 14:54:44 --> Config Class Initialized
INFO - 2023-07-07 14:54:44 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:54:44 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:54:44 --> Utf8 Class Initialized
INFO - 2023-07-07 14:54:44 --> URI Class Initialized
DEBUG - 2023-07-07 14:54:44 --> No URI present. Default controller set.
INFO - 2023-07-07 14:54:44 --> Router Class Initialized
INFO - 2023-07-07 14:54:44 --> Output Class Initialized
INFO - 2023-07-07 14:54:44 --> Security Class Initialized
DEBUG - 2023-07-07 14:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:54:44 --> Input Class Initialized
INFO - 2023-07-07 14:54:44 --> Language Class Initialized
INFO - 2023-07-07 14:54:44 --> Loader Class Initialized
INFO - 2023-07-07 14:54:44 --> Controller Class Initialized
INFO - 2023-07-07 14:54:44 --> File loaded: C:\xampp\htdocs\code\application\views\welcome_message.php
INFO - 2023-07-07 14:54:44 --> Final output sent to browser
DEBUG - 2023-07-07 14:54:44 --> Total execution time: 0.0354
INFO - 2023-07-07 14:54:56 --> Config Class Initialized
INFO - 2023-07-07 14:54:56 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:54:56 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:54:56 --> Utf8 Class Initialized
INFO - 2023-07-07 14:54:56 --> URI Class Initialized
DEBUG - 2023-07-07 14:54:56 --> No URI present. Default controller set.
INFO - 2023-07-07 14:54:56 --> Router Class Initialized
INFO - 2023-07-07 14:54:56 --> Output Class Initialized
INFO - 2023-07-07 14:54:56 --> Security Class Initialized
DEBUG - 2023-07-07 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:54:56 --> Input Class Initialized
INFO - 2023-07-07 14:54:56 --> Language Class Initialized
INFO - 2023-07-07 14:54:56 --> Loader Class Initialized
INFO - 2023-07-07 14:54:56 --> Controller Class Initialized
INFO - 2023-07-07 14:54:56 --> File loaded: C:\xampp\htdocs\code\application\views\welcome_message.php
INFO - 2023-07-07 14:54:56 --> Final output sent to browser
DEBUG - 2023-07-07 14:54:56 --> Total execution time: 0.0373
INFO - 2023-07-07 14:56:07 --> Config Class Initialized
INFO - 2023-07-07 14:56:07 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:56:07 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:56:07 --> Utf8 Class Initialized
INFO - 2023-07-07 14:56:07 --> URI Class Initialized
DEBUG - 2023-07-07 14:56:07 --> No URI present. Default controller set.
INFO - 2023-07-07 14:56:07 --> Router Class Initialized
INFO - 2023-07-07 14:56:07 --> Output Class Initialized
INFO - 2023-07-07 14:56:07 --> Security Class Initialized
DEBUG - 2023-07-07 14:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:56:07 --> Input Class Initialized
INFO - 2023-07-07 14:56:07 --> Language Class Initialized
INFO - 2023-07-07 14:56:07 --> Loader Class Initialized
INFO - 2023-07-07 14:56:07 --> Controller Class Initialized
INFO - 2023-07-07 14:56:07 --> File loaded: C:\xampp\htdocs\code\application\views\welcome_message.php
INFO - 2023-07-07 14:56:07 --> Final output sent to browser
DEBUG - 2023-07-07 14:56:07 --> Total execution time: 0.0355
INFO - 2023-07-07 14:56:19 --> Config Class Initialized
INFO - 2023-07-07 14:56:19 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:56:19 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:56:19 --> Utf8 Class Initialized
INFO - 2023-07-07 14:56:19 --> URI Class Initialized
INFO - 2023-07-07 14:56:19 --> Router Class Initialized
INFO - 2023-07-07 14:56:19 --> Output Class Initialized
INFO - 2023-07-07 14:56:19 --> Security Class Initialized
DEBUG - 2023-07-07 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:56:19 --> Input Class Initialized
INFO - 2023-07-07 14:56:19 --> Language Class Initialized
INFO - 2023-07-07 14:56:19 --> Loader Class Initialized
INFO - 2023-07-07 14:56:19 --> Controller Class Initialized
INFO - 2023-07-07 14:56:19 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:56:19 --> Final output sent to browser
DEBUG - 2023-07-07 14:56:19 --> Total execution time: 0.0394
INFO - 2023-07-07 14:56:49 --> Config Class Initialized
INFO - 2023-07-07 14:56:49 --> Hooks Class Initialized
DEBUG - 2023-07-07 14:56:49 --> UTF-8 Support Enabled
INFO - 2023-07-07 14:56:49 --> Utf8 Class Initialized
INFO - 2023-07-07 14:56:49 --> URI Class Initialized
INFO - 2023-07-07 14:56:49 --> Router Class Initialized
INFO - 2023-07-07 14:56:49 --> Output Class Initialized
INFO - 2023-07-07 14:56:49 --> Security Class Initialized
DEBUG - 2023-07-07 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 14:56:49 --> Input Class Initialized
INFO - 2023-07-07 14:56:49 --> Language Class Initialized
INFO - 2023-07-07 14:56:49 --> Loader Class Initialized
INFO - 2023-07-07 14:56:49 --> Controller Class Initialized
INFO - 2023-07-07 14:56:49 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 14:56:49 --> Final output sent to browser
DEBUG - 2023-07-07 14:56:49 --> Total execution time: 0.0394
INFO - 2023-07-07 15:01:43 --> Config Class Initialized
INFO - 2023-07-07 15:01:43 --> Hooks Class Initialized
DEBUG - 2023-07-07 15:01:43 --> UTF-8 Support Enabled
INFO - 2023-07-07 15:01:43 --> Utf8 Class Initialized
INFO - 2023-07-07 15:01:43 --> URI Class Initialized
INFO - 2023-07-07 15:01:43 --> Router Class Initialized
INFO - 2023-07-07 15:01:43 --> Output Class Initialized
INFO - 2023-07-07 15:01:43 --> Security Class Initialized
DEBUG - 2023-07-07 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 15:01:43 --> Input Class Initialized
INFO - 2023-07-07 15:01:43 --> Language Class Initialized
INFO - 2023-07-07 15:01:43 --> Loader Class Initialized
INFO - 2023-07-07 15:01:43 --> Controller Class Initialized
INFO - 2023-07-07 15:01:43 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 15:01:43 --> Final output sent to browser
DEBUG - 2023-07-07 15:01:43 --> Total execution time: 0.0352
INFO - 2023-07-07 15:03:12 --> Config Class Initialized
INFO - 2023-07-07 15:03:12 --> Hooks Class Initialized
DEBUG - 2023-07-07 15:03:12 --> UTF-8 Support Enabled
INFO - 2023-07-07 15:03:12 --> Utf8 Class Initialized
INFO - 2023-07-07 15:03:12 --> URI Class Initialized
INFO - 2023-07-07 15:03:12 --> Router Class Initialized
INFO - 2023-07-07 15:03:12 --> Output Class Initialized
INFO - 2023-07-07 15:03:12 --> Security Class Initialized
DEBUG - 2023-07-07 15:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 15:03:12 --> Input Class Initialized
INFO - 2023-07-07 15:03:12 --> Language Class Initialized
INFO - 2023-07-07 15:03:12 --> Loader Class Initialized
INFO - 2023-07-07 15:03:12 --> Controller Class Initialized
INFO - 2023-07-07 15:03:12 --> File loaded: C:\xampp\htdocs\code\application\views\home.php
INFO - 2023-07-07 15:03:12 --> Final output sent to browser
DEBUG - 2023-07-07 15:03:12 --> Total execution time: 0.0379
