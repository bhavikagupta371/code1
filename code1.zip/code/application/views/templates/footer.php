<style>
.footer {
    position: fixed; 
    z-index: 9;
    bottom: 0;
    width: 100%;
    /* position: fixed; */
   /* bottom: 0;
   width: 100%; */
   height: 55px; 
}
</style>
<section class="footer">
            
            <div class="bottom-footer">
                <div class="container">
                    <div class="col-12">
                        <div class="col-6 mb-6" style="color:#606873">
                            <div class="footer-menu" style="vertical-align:middle;">
                                <div class="col-3 footer-menu-box-link">Home</div>
                                 <div class="col-3 footer-menu-box-link">About  </div>
                                <div class="col-3 footer-menu-box-link">Login</div>
                                <div class="col-3 footer-menu-box-link">Register</div>
                               
                             </div>
                        </div>
                <div class="col-6 mb-6 social right"><div class="col-3"><i class="quickweb-icon-facebook"></i></div><div class="col-3"><i class="quickweb-icon-twitter"></i></div><div class="col-3"><i class="quickweb-icon-youtube"></i></div><div class="col-3"><i class="quickweb-icon-gplus-1"></i></div></div>
                    </div>
              <div class="col-12 creator" style="padding-top:25px;">
                <div class="col-6 copyright">© 2016 All Rights Reserved by Neron. </div>
                <div class="col-6 design-by">
                    <div class="col-8" style="color: #E5E5E5;font-weight: 100;font-size: 15px;">Made With <i class="quickweb-icon-heart" style="color:rgb(216, 24, 24);font-size:20px;"></i>By Bhavika Gupta</div>
                    
             </div>
            </div>
            </div>
        </section>

        </div>
    <script type="text/javascript">
        thumb_slider({

            thumbs_to_show: 1,
            thumbs_to_move: 1,
            thumbs_width: 0,
            thumbs_count: 0,
            timeout: 10000,
            parent_id: "main_slider",
            container_class: "thumb_slider",
            thumb_class: "thumbs",
            spacing: 0,
            processing: false,
            hover: false,
            next_class: "next",
            prev_class: "prev",
            timer: setTimeout(function () { })

        });
    </script>
</body>
</html>
