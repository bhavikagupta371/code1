<!DOCTYPE html>
<html>
<head>
<title>Update Data</title>
</head>
 
<body>

<form action="<?php echo base_url();?>/Student/edit/<?php echo $rowId;?>" method="Post">
  <div class="form-group">
    <label for="name">Name:</label>
    <input type="text" class="form-control" name="name" value="<?php echo $tableData->name; ?>">
  </div>

  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="text" class="form-control" value="<?php echo $tableData->email; ?>" name="email">
  </div>

  <div class="form-group">
    <label for="address">Address:</label>
    <input type="text" class="form-control" value="<?php echo $tableData->address; ?>" name="address">
  </div>


  <button type="submit" class="btn btn-default">Submit</button>
</form>

</body>
</html>