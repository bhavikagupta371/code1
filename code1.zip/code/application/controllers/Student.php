<?php
class Student extends CI_Controller {

    public function listing()

	{
		$this->db->select('students.*');
		$this->db->from('students');
		$this->db->order_by('id', 'desc');
		$data['tableDatas'] = $this->db->get()->result_array();

		 $this->load->view('/templates/header');
		 $this->load->view('/Student/listing', $data);
		 $this->load->view('/templates/footer') ;
	}


	public function add()
	{

		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			
			$postDatas = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'address' => $this->input->post('address'),
			);
             
		 	$isInserted = $this->db->insert('students', $postDatas);
			if($isInserted !=false){
				echo 'Record added successfully.';
			}else{
				echo 'Error!!! Try again.';
			}
			redirect('/Student/listing');

		}else{
			$this->load->view('/templates/header');
			$this->load->view('/Student/add');
			$this->load->view('/templates/footer');
		}
	}


	public function edit($id=null)
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$postDatas = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'address' => $this->input->post('address'),
			);

			$this->db->where('id', $id);
			$this->db->update('students', $postDatas);
			$isInserted = $this->db->affected_rows();
			if($isInserted !=false){
				echo 'Record updated successfully.';
			}else{
				echo 'Error!!! Try again.';
			}
			redirect('/Student/listing');
		}else{

			$this->db->select('students.*');
			$this->db->from('students');
			$this->db->where('id', $id);
			$data['tableData'] = $this->db->get()->row();

			$data['rowId'] =$id;

			$this->load->view('/templates/header');
			$this->load->view('/student/edit', $data);
			$this->load->view('/templates/footer') ;
		}
		
	}

	public function delete($id=null)
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$this->db->where('id', $id);
			$this->db->delete('students');
			$isInserted = $this->db->affected_rows();
			if($isInserted !=false){
				echo 'Record updated successfully.';
			}else{
				echo 'Error!!! Try again.';
			}
			redirect('/Student/listing');
		}
		
	}
}
// $this->db->where('request_id', $request_id);
			//$this->db->delete('tbl_device_info');