<form action="<?php echo base_url();?>/Student/add" method="Post">
  <div class="form-group">
    <label for="name">Name:</label>
    <input type="text" class="form-control" name="name">
  </div>

  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="text" class="form-control" name="email">
  </div>

  <div class="form-group">
    <label for="address">A   ddress:</label>
    <input type="text" class="form-control" name="address">
  </div>


  <button type="submit" class="btn btn-default">Submit</button>
</form>